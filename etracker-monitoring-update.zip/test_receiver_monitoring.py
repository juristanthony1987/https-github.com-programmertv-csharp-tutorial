"""Receiving/releasing regressions. Uses temporary SQLite databases only.
Run separately: python -m unittest test_receiver_monitoring -v
"""
import csv
import hashlib
import io
import json
import os
import secrets
import tempfile
import unittest
from datetime import date
from pathlib import Path
from unittest.mock import patch


class ReceivingMonitoringTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.environment = patch.dict(os.environ, {
            'ETRACKER_DATABASE_URL':'', 'ETRACKER_DB':str(Path(cls.temp.name)/'main.db'),
            'COE_DB':str(Path(cls.temp.name)/'coe.db'), 'ETRACKER_SECRET_KEY':secrets.token_urlsafe(32),
            'ETRACKER_ADMIN_PASSWORD':secrets.token_urlsafe(24)})
        cls.environment.start()
        import app
        cls.tracker = app
        app.local_today = lambda: date(2026,10,19)
        app.app.config['TESTING'] = True
        app.init_db()
        from werkzeug.security import generate_password_hash
        with app.conn() as db:
            for username,role in [('edbermelad','receiver'),('other-receiver','receiver'),('test-verifier','first_verifier')]:
                db.execute('INSERT INTO users(username,password_hash,role) VALUES (?,?,?)',
                           (username,generate_password_hash(secrets.token_urlsafe(20)),role))
                db.execute('INSERT INTO ro_account_profiles(username,display_name,created_by) VALUES (?,?,?)',
                           (username,username,'admin'))
        cls.sequence = 0

    @classmethod
    def tearDownClass(cls):
        cls.environment.stop()
        cls.temp.cleanup()

    def client(self, username='edbermelad'):
        client = self.tracker.app.test_client()
        with client.session_transaction() as s:
            s.update(username=username,csrf='test-token')
        return client

    def record(self, system='spels', **changes):
        type(self).sequence += 1
        ref = f'TEST-{system}-{self.sequence}'
        if system == 'spels':
            values = dict(reference=ref,applicant=ref,category='Other',subtype='BOE',source='Walk-In',
                          received_on='2026-09-30',received_ro_on='2026-09-30',receiver_account='other-receiver',
                          received_ro_by='other-receiver',first_processor='First Tester',first_date='2026-10-01',
                          second_processor='Second Tester',second_date='2026-10-02',action='Approved')
        else:
            values = dict(reference=ref,transaction_no=ref,eligible_name=ref,source='Walk-In',
                          received_on='2026-09-30',received_ro_on='2026-09-30',receiver_account='other-receiver',
                          received_ro_by='other-receiver',first_verifier='First Tester',first_verified_on='2026-10-01',
                          second_verifier='Second Tester',second_verified_on='2026-10-02',status='For Release')
        values.update(changes)
        from coe_monitor import connect
        db = self.tracker.conn() if system=='spels' else connect(self.tracker.app.config['COE_DB'])
        table = 'transactions' if system=='spels' else 'coe_transactions'
        with db:
            ident = db.execute(f'INSERT INTO {table} ('+','.join(values)+') VALUES ('+','.join('?' for _ in values)+')',tuple(values.values())).lastrowid
        return ident,ref

    def row(self, ident, system='spels'):
        from coe_monitor import connect
        db = self.tracker.conn() if system=='spels' else connect(self.tracker.app.config['COE_DB'])
        with db:
            return dict(db.execute('SELECT * FROM '+('transactions' if system=='spels' else 'coe_transactions')+' WHERE id=?',(ident,)).fetchone())

    def payload(self, ident, system='spels', **extra):
        from receiver_monitoring import record_version
        return {'_csrf':'test-token','version':record_version(self.row(ident,system)),
                'released_client_on':'2026-10-19',**extra}

    def test_monitoring_covers_all_ro_receivers_but_not_unreceived_fo(self):
        _,seen = self.record(applicant='SharedRO visible',source='ISAFO')
        _,hidden = self.record(applicant='SharedRO not received',source='QFO',received_ro_on=None)
        html = self.client().get('/monitoring/spels?q=SharedRO').get_data(as_text=True)
        self.assertIn(seen,html)
        self.assertNotIn(hidden,html)
        self.assertIn('other-receiver',html)
        self.assertIn('Total Acted Applications',html)
        self.assertNotIn('Switch Workspace',html)

    def test_separate_coe_and_spels_dashboards_and_landing(self):
        _,spels = self.record()
        _,coe = self.record('coe')
        client=self.client()
        html=client.get('/monitoring/coe').get_data(as_text=True)
        self.assertIn(coe,html);self.assertNotIn(spels,html)
        html=client.get('/monitoring/spels').get_data(as_text=True)
        self.assertIn(spels,html);self.assertNotIn(coe,html)
        self.assertIn('/monitoring/spels',client.get('/').location)
        self.assertIn('/monitoring/coe',client.get('/coe').location)
        from html.parser import HTMLParser
        class Links(HTMLParser):
            def __init__(self):
                super().__init__()
                self.links=[]
            def handle_starttag(self, tag, attrs):
                if tag=='a':self.links.append(dict(attrs).get('href',''))
        for system,other in [('spels','coe'),('coe','spels')]:
            for view in ('received','for_release','released'):
                html=client.get(f'/monitoring/{system}?view={view}').get_data(as_text=True)
                self.assertIn(f'>{system.upper()} Monitoring</a>',html)
                self.assertNotIn('aria-label="Monitoring system"',html)
                self.assertNotIn('aria-label="Releasing system"',html)
                links=Links();links.feed(html)
                for href in links.links:
                    self.assertFalse(any(href.startswith(f'/{area}/{other}')
                                         for area in ('monitoring','releasing','work')),href)

    def test_other_accounts_cannot_release_or_open_monitoring(self):
        ident,_=self.record()
        for username in ('other-receiver','test-verifier','admin'):
            client=self.client(username)
            self.assertEqual(client.get('/monitoring/spels').status_code,403)
            self.assertEqual(client.post(f'/releasing/spels/{ident}',data=self.payload(ident)).status_code,403)
        self.assertIsNone(self.row(ident)['released_client_on'])

    def test_release_is_audited_and_receipt_and_verification_are_preserved(self):
        ident,_=self.record()
        before=self.row(ident)
        import re
        client=self.client()
        html=client.get(f'/releasing/spels/{ident}').get_data(as_text=True)
        payload=self.payload(ident)
        payload['version']=re.search(r'name="version" value="([a-f0-9]+)"',html)[1]
        response=client.post(f'/releasing/spels/{ident}',data=payload)
        self.assertEqual(response.status_code,302)
        after=self.row(ident)
        self.assertEqual(after['released_client_on'],'2026-10-19')
        for key in ('received_on','received_ro_on','receiver_account','first_processor','first_date','second_processor','second_date','acted_on','action','reference'):
            self.assertEqual(after[key],before[key],key)
        with self.tracker.conn() as db:
            entry=db.execute("SELECT username,event FROM audit WHERE transaction_id=? AND event LIKE 'Client release recorded:%'",(ident,)).fetchone()
        self.assertEqual(entry['username'],'edbermelad')
        self.assertIn('2026-10-19',entry['event'])
        payload=self.payload(ident)
        payload['released_client_on']='2026-10-18'
        self.assertEqual(self.client().post(f'/releasing/spels/{ident}',data=payload).status_code,409)
        self.assertEqual(self.row(ident)['released_client_on'],'2026-10-19')

    def test_verified_action_is_used_without_allowing_arbitrary_decision(self):
        ident,_=self.record(action='On Process',verifier_state='verified',second_action='Approved')
        self.assertEqual(self.client().post(f'/releasing/spels/{ident}',data=self.payload(ident)).status_code,302)
        self.assertEqual(self.row(ident)['action'],'Approved')
        legacy,_=self.record(action='Released')
        self.assertEqual(self.client().post(f'/releasing/spels/{legacy}',data=self.payload(legacy)).status_code,302)
        self.assertEqual(self.row(legacy)['action'],'Released')
        blocked,_=self.record(action='Pending',pending_status='For Compliance',verifier_state='verified',second_action='Approved')
        self.assertEqual(self.client().post(f'/releasing/spels/{blocked}',data=self.payload(blocked)).status_code,409)

    def test_dates_csrf_and_unexpected_fields_are_rejected(self):
        ident,_=self.record()
        client=self.client()
        for day in ('','2026-99-01','2026-10-20','2026-10-01'):
            payload=self.payload(ident,released_client_on=day)
            self.assertEqual(client.post(f'/releasing/spels/{ident}',data=payload).status_code,400,day)
        self.assertEqual(client.post(f'/releasing/spels/{ident}',data=self.payload(ident,_csrf='wrong')).status_code,400)
        self.assertEqual(client.post(f'/releasing/spels/{ident}',data=self.payload(ident,action='Disapproved')).status_code,403)
        self.assertIsNone(self.row(ident)['released_client_on'])
        self.assertEqual(self.row(ident)['action'],'Approved')

    def test_stale_edits_missing_verification_and_unconfirmed_handoffs_are_blocked(self):
        ident,_=self.record()
        old=self.payload(ident)
        with self.tracker.conn() as db:
            db.execute("UPDATE transactions SET remarks='Changed by another user' WHERE id=?",(ident,))
        self.assertEqual(self.client().post(f'/releasing/spels/{ident}',data=old).status_code,409)
        for extra in ({'second_processor':''},{'second_date':None},{'ro_transmitted_fo':'Yes','received_back_ro_on':None}):
            ident,_=self.record(**extra)
            self.assertEqual(self.client().post(f'/releasing/spels/{ident}',data=self.payload(ident)).status_code,409)
            self.assertIsNone(self.row(ident)['released_client_on'])

    def test_coe_release_and_hold(self):
        ident,_=self.record('coe')
        self.assertEqual(self.client().post(f'/releasing/coe/{ident}',data=self.payload(ident,'coe')).status_code,302)
        after=self.row(ident,'coe')
        self.assertEqual(after['status'],'Released')
        self.assertEqual(after['released_client_on'],'2026-10-19')
        self.assertEqual(after['updated_by'],'edbermelad')
        self.assertEqual(after['received_ro_by'],'other-receiver')
        blocked,_=self.record('coe',status='COPI')
        self.assertEqual(self.client().post(f'/releasing/coe/{blocked}',data=self.payload(blocked,'coe')).status_code,409)
        from coe_monitor import connect
        with connect(self.tracker.app.config['COE_DB']) as db:
            audit=db.execute("SELECT username,new_json FROM coe_audit WHERE transaction_id=? AND event='Client release recorded'",(ident,)).fetchone()
        self.assertEqual(audit['username'],'edbermelad')
        self.assertEqual(json.loads(audit['new_json'])['released_client_on'],'2026-10-19')

    def monitoring_context(self, path, username='edbermelad'):
        from flask import template_rendered
        captured=[]
        def capture(sender, template, context, **extra):
            captured.append(context)
        template_rendered.connect(capture,self.tracker.app)
        try:
            response=self.client(username).get(path)
            self.assertEqual(response.status_code,200,path)
            return response,captured[-1]
        finally:
            template_rendered.disconnect(capture,self.tracker.app)

    def test_performance_days_pending_and_action_period_match_admin(self):
        prefix='Performance-fixture'
        within,_=self.record(applicant=prefix+' within',category='HGE',subtype='',quantity=3,
                             received_on='2026-09-01',received_ro_on='2026-09-01',first_date='2026-09-01',second_date='2026-09-28')
        beyond,_=self.record(applicant=prefix+' beyond',received_on='2026-09-01',received_ro_on='2026-09-01',
                             first_date='2026-09-01',second_date='2026-09-29')
        older,_=self.record(applicant=prefix+' old receipt acted in month',received_on='2026-08-01',received_ro_on='2026-08-01',
                            first_date='2026-08-01',second_date='2026-09-01')
        for action in ('Received','On Process','Pending'):
            self.record(applicant=prefix+' unresolved '+action,action=action,second_date=None)
        response,context=self.monitoring_context('/monitoring/spels?year=2026&month=9&q='+prefix)
        self.assertEqual(context['totals']['within'],3)
        self.assertEqual(context['totals']['beyond'],2)
        self.assertEqual(context['totals']['acted'],5)
        self.assertEqual(context['totals']['pending'],3)
        self.assertEqual(context['totals']['received'],7)
        self.assertEqual(context['totals']['opening'],1)
        with self.tracker.conn() as db:
            rows=db.execute('SELECT * FROM transactions WHERE applicant LIKE ?',(prefix+'%',)).fetchall()
        with self.tracker.app.test_request_context('/'):
            expected=self.tracker.report_activity(rows,set(),'2026-09-01','2026-09-30')
        self.assertEqual(context['totals']['pending'],sum(r['quantity'] for r in expected['pending']))
        _,listing=self.monitoring_context('/monitoring/spels?year=2026&month=9&q='+prefix+'&view=beyond')
        self.assertEqual({r['id'] for r in listing['rows']},{beyond,older})
        html=response.get_data(as_text=True)
        self.assertIn('pending-count-alert',html)
        self.assertRegex(html,r'data-summary-metric="pending" class="attention"')
        self.assertIn('Acted within 20 working days',html)
        self.assertIn('Acted beyond 20 working days',html)
        self.assertNotIn('Search this list',html)
        self.assertIn('placeholder="Reference, applicant, or office"',html)

    def test_holidays_copi_and_chief_adjustments_follow_admin_rules(self):
        prefix='Adjusted-performance'
        ident,_=self.record(applicant=prefix+' holiday',received_on='2026-09-01',received_ro_on='2026-09-01',
                            first_date='2026-09-01',second_date='2026-09-29')
        with self.tracker.conn() as db:
            db.execute("INSERT INTO holidays(day,label) VALUES ('2026-09-28','Synthetic holiday')")
        try:
            _,context=self.monitoring_context('/monitoring/spels?year=2026&month=9&q='+prefix)
            self.assertEqual(context['totals']['within'],1)
            self.assertEqual(context['totals']['beyond'],0)
        finally:
            with self.tracker.conn() as db:db.execute("DELETE FROM holidays WHERE day='2026-09-28'")
        with self.tracker.conn() as db:
            db.execute('INSERT INTO copi_pauses(transaction_id,started_on,resumed_on) VALUES (?,?,?)',(ident,'2026-09-02','2026-09-04'))
        _,context=self.monitoring_context('/monitoring/spels?year=2026&month=9&q='+prefix+'&view=within')
        self.assertEqual(context['rows'][0]['days'],20)
        self.assertEqual(context['rows'][0]['copi_pause_days'],1)
        with self.tracker.conn() as db:
            db.execute('UPDATE transactions SET reckoning_on=? WHERE id=?',('2026-09-15',ident))
        _,context=self.monitoring_context('/monitoring/spels?year=2026&month=9&q='+prefix+'&view=within')
        self.assertTrue(context['rows'][0]['reckoning_applied'])
        self.assertEqual(context['rows'][0]['days'],11)

    def test_admin_columns_pagination_and_preserved_filters(self):
        prefix='Paging-fixture'
        for number in range(27):
            self.record(applicant=prefix+str(number),verifier_state='submitted',second_action='Pending',second_pending_status='For COPI',action='Pending',pending_status='For COPI',second_date=None)
        response,context=self.monitoring_context('/monitoring/spels?year=2026&view=pending&q='+prefix+'&page=2')
        self.assertEqual(context['page'],2)
        self.assertEqual(len(context['rows']),2)
        html=response.get_data(as_text=True)
        self.assertIn('aria-current="page">2',html)
        self.assertIn('← Previous',html)
        self.assertIn('Next →',html)
        self.assertIn('view=pending',html)
        self.assertIn('q=Paging-fixture',html)
        admin=self.client('admin')
        for path in ['/transactions?q='+prefix+'&year=','/dashboard/records/pending?scope=year&year=2026&q='+prefix]:
            response=admin.get(path)
            self.assertEqual(response.status_code,200,path)
            html=response.get_data(as_text=True)
            for label in ('Received by','Verification Stage','Client Release'):
                self.assertIn(label,html)
            self.assertIn('other-receiver',html)
            self.assertIn('Second Verifier',html)
            self.assertIn('For COPI',html)
            self.assertIn('Not yet released',html)
            self.assertIn('record-pagination',html)
        html=admin.get('/').get_data(as_text=True)
        self.assertIn('RECEIVED APPLICATIONS',html)
        self.assertNotIn('NEW APPLICATIONS',html)
        _,context=self.monitoring_context('/monitoring/spels?year=2027&q='+prefix)
        self.assertEqual(context['totals']['pending'],0)

    def test_acted_labels_in_all_report_periods_and_workflow_guides(self):
        client=self.client('admin')
        for query in ('scope=year&year=2026','scope=month&year=2026&month=10','scope=day&day=2026-10-19'):
            html=client.get('/?'+query).get_data(as_text=True)
            self.assertIn('Total Acted Applications',html)
            self.assertIn('ACTED WITHIN 20 WORKING DAYS',html)
            self.assertNotIn('DECIDED',html)
            self.assertNotIn('Final decisions',html)
            rows=list(csv.reader(io.StringIO(client.get('/report.csv?'+query).get_data(as_text=True))))
            header=next(r for r in rows if r and r[0]=='Category')
            self.assertTrue(any('Total Acted Applications' in value for value in header))
        html=self.client('test-verifier').get('/work/spels').get_data(as_text=True)
        self.assertIn('<b>Acted and release:</b>',html)
        self.assertNotIn('Final decision and release',html)

    def test_releasing_is_focused_searchable_and_independent_of_report_period(self):
        for system, name in [('spels','applicant'), ('coe','eligible_name')]:
            prefix='Release-search-'+system
            ready,reference=self.record(system,**{name:prefix+' ready', 'received_on':'2025-01-02',
                'received_ro_on':'2025-01-02'})
            released,_=self.record(system,**{name:prefix+' released','released_client_on':'2026-10-15'})
            self.record(system,**{name:prefix+' held', **({'action':'Pending','pending_status':'For Compliance'}
                if system=='spels' else {'status':'For Compliance'})})
            response,context=self.monitoring_context(f'/monitoring/{system}?view=for_release&year=2027&month=12&q={prefix}')
            html=response.get_data(as_text=True)
            self.assertEqual([r['id'] for r in context['rows']],[ready])
            self.assertEqual(context['totals']['released'],1)
            self.assertIn('Search applications',html)
            self.assertIn('Clear filters',html)
            for absent in ('Applications at a glance','Total Acted Applications','Report period:',
                           'name="year"','name="month"','Pending action alerts'):
                self.assertNotIn(absent,html)
            self.assertNotIn('year=',html)
            for query in (reference, prefix+' ready', 'Walk-In'):
                _,searched=self.monitoring_context(f'/monitoring/{system}?view=for_release&q={query}')
                self.assertIn(ready,[r['id'] for r in searched['rows']])
            _,searched=self.monitoring_context(f'/monitoring/{system}?view=released&q={prefix}')
            self.assertEqual([r['id'] for r in searched['rows']],[released])
            empty=self.client().get(f'/monitoring/{system}?view=for_release&q=NoMatchingRelease999').get_data(as_text=True)
            self.assertIn('No applications match this view.',empty)
            detail=self.client().get(f'/releasing/{system}/{ready}').get_data(as_text=True)
            self.assertIn('Back to releasing',detail)

    def test_processing_status_and_office_filters_update_counts_and_preserve_pagination(self):
        prefix='Combined-monitoring-filters'
        for number in range(27):
            extra = dict(category='HGE',subtype='',quantity=3) if number==0 else {}
            self.record(applicant=prefix+str(number),source='ISAFO',**extra)
        self.record(applicant=prefix+' different office',source='Walk-In')
        self.record(applicant=prefix+' different status',source='ISAFO',action='Pending',second_date=None)
        self.record(applicant=prefix+' unreceived FO',source='ISAFO',received_ro_on=None)
        query=f'year=2026&month=10&view=acted&q={prefix}&status=Approved&office=ISAFO'
        response,context=self.monitoring_context('/monitoring/spels?'+query+'&page=2')
        self.assertEqual(context['total'],27)
        self.assertEqual(context['totals']['acted'],29)
        self.assertEqual(context['totals']['pending'],0)
        self.assertEqual(len(context['rows']),2)
        self.assertTrue(all(r['source']=='ISAFO' and r['action']=='Approved' for r in context['rows']))
        html=response.get_data(as_text=True)
        self.assertIn('Apply Filters',html)
        self.assertNotIn('Update monitoring',html)
        self.assertNotIn('Search this list',html)
        for preserved in ('office=ISAFO','status=Approved','month=10','view=acted','q='+prefix):
            self.assertIn(preserved,html)
        for view in ('for_release','released'):
            _,release=self.monitoring_context('/monitoring/spels?'+query.replace('view=acted','view='+view))
            self.assertEqual(release['status'],'Approved')
            self.assertEqual(release['office'],'ISAFO')
            self.assertTrue(release['releasing'])
        _,empty=self.monitoring_context('/monitoring/spels?year=2026&view=acted&q='+prefix+'&status=Disapproved&office=ISAFO')
        self.assertEqual(empty['total'],0)
        _,cleared=self.monitoring_context('/monitoring/spels')
        self.assertEqual((cleared['status'],cleared['office'],cleared['q']),('','',''))
        for invalid in ('status=UnknownAction','office=UnknownOffice'):
            self.assertEqual(self.client().get('/monitoring/spels?'+invalid).status_code,400)

    def test_coe_filters_and_unrecorded_spels_action(self):
        prefix='COE-filter-fixture'
        ident,_=self.record('coe',eligible_name=prefix,source='QFO',status='For Release')
        self.record('coe',eligible_name=prefix,source='ISAFO',status='For Release')
        self.record('coe',eligible_name=prefix,source='QFO',status='COPI')
        for view in ('received','for_release'):
            _,context=self.monitoring_context('/monitoring/coe?view='+view+'&q='+prefix+'&status=For+Release&office=QFO')
            self.assertEqual([r['id'] for r in context['rows']],[ident])
            self.assertEqual(context['totals']['received'],1)
            self.assertEqual(context['totals']['for_release'],1)
        blank,_=self.record(applicant='No-action-filter-fixture',action='',second_date=None)
        _,context=self.monitoring_context('/monitoring/spels?q=No-action-filter-fixture&status=__none__')
        self.assertEqual([r['id'] for r in context['rows']],[blank])

    def test_live_pending_alerts_use_15_day_boundary_and_exclude_active_copi(self):
        prefix='Alert-boundary'
        ids={}
        for label,received in [('fourteen','2026-09-30'),('fifteen','2026-09-29'),
                               ('twenty','2026-09-22'),('overdue','2026-09-21')]:
            ids[label],_=self.record(applicant=prefix+' '+label,received_on=received,received_ro_on=received,
                                     action='On Process',second_date=None)
        paused,_=self.record(applicant=prefix+' paused',received_on='2026-08-01',received_ro_on='2026-08-01',
                             action='Pending',pending_status='For COPI',second_date=None)
        resumed,_=self.record(applicant=prefix+' resumed',received_on='2026-08-01',received_ro_on='2026-08-01',
                              action='On Process',second_date=None)
        self.record(applicant=prefix+' completed',received_on='2026-08-01',received_ro_on='2026-08-01')
        with self.tracker.conn() as db:
            db.execute('UPDATE copi_pauses SET started_on=? WHERE transaction_id=?',('2026-09-01',paused))
            db.execute('INSERT INTO copi_pauses(transaction_id,started_on,resumed_on) VALUES (?,?,?)',
                       (resumed,'2026-08-03','2026-10-01'))
        response,context=self.monitoring_context('/monitoring/spels?year=2025&view=needs_action&q='+prefix)
        self.assertEqual({r['id'] for r in context['rows']},{ids['fifteen'],ids['twenty'],ids['overdue']})
        self.assertEqual(context['alert_due_soon'],2)
        self.assertEqual(context['alert_overdue'],1)
        self.assertEqual([r['days'] for r in context['rows']],[21,20,15])
        html=response.get_data(as_text=True)
        self.assertIn('pending-action-alert is-overdue',html)
        self.assertIn('3 pending application(s) need action',html)
        self.assertIn('Active COPI pauses are excluded',html)
        with self.tracker.conn() as db:
            db.execute("INSERT INTO holidays(day,label) VALUES ('2026-10-19','Alert test holiday')")
        try:
            _,context=self.monitoring_context('/monitoring/spels?view=needs_action&q='+prefix)
            self.assertNotIn(ids['fifteen'],[r['id'] for r in context['rows']])
            self.assertEqual(context['alert_overdue'],0)
        finally:
            with self.tracker.conn() as db:db.execute("DELETE FROM holidays WHERE day='2026-10-19'")
        with self.tracker.conn() as db:
            db.execute('UPDATE copi_pauses SET resumed_on=? WHERE transaction_id=?',('2026-09-28',resumed))
        _,context=self.monitoring_context('/monitoring/spels?view=needs_action&q='+prefix)
        self.assertIn(resumed,[r['id'] for r in context['rows']])


if __name__=='__main__':
    unittest.main()
