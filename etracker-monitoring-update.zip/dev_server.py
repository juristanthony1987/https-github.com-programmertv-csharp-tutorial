"""Run development against database copies, preserving the supplied records.

Usage: python dev_server.py
ETRACKER_RUNTIME_DIR optionally selects where development copies are retained.
Existing account passwords remain valid in those copies.
"""
import os
import secrets
import sqlite3
from pathlib import Path


def prepare_runtime():
    source = Path(__file__).resolve().parent
    runtime = Path(os.getenv('ETRACKER_RUNTIME_DIR', str(source / '.dev-runtime'))).resolve()
    if runtime == source:
        raise RuntimeError('Choose a runtime directory separate from the project database folder.')
    runtime.mkdir(parents=True, exist_ok=True, mode=0o700)
    for name, variable in [('etracker.db', 'ETRACKER_DB'), ('coe.db', 'COE_DB')]:
        original, copied = source / name, runtime / name
        if copied.resolve() == original.resolve():
            raise RuntimeError('Development database must not replace the source database.')
        if not copied.exists() and original.exists():
            with sqlite3.connect(original.as_uri() + '?mode=ro', uri=True) as src:
                with sqlite3.connect(copied) as dst:
                    src.backup(dst)
        os.environ[variable] = str(copied)
    if not os.environ.get('ETRACKER_SECRET_KEY'):
        secret_file = runtime / '.session-key'
        try:
            with open(secret_file, 'x', opener=lambda path, flags: os.open(path, flags, 0o600)) as output:
                output.write(secrets.token_urlsafe(48))
        except FileExistsError:
            pass
        key = secret_file.read_text().strip()
        if not key:
            raise RuntimeError('Development session key is empty. Supply ETRACKER_SECRET_KEY.')
        os.environ['ETRACKER_SECRET_KEY'] = key
    return runtime


if __name__ == '__main__':
    prepare_runtime()
    from app import app, init_db
    init_db()
    app.run(host=os.getenv('ETRACKER_HOST', '127.0.0.1'),
            port=int(os.getenv('ETRACKER_PORT', '5000')), debug=False)
