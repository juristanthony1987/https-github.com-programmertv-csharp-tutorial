from workflow_actions import apply_action_rules, validate_client_release, migrate_action_rules, apply_client_release_choice
from fo_access import fo_office, office_choices, scoped_select, guard_connection, normalize_office
from fo_processing import FO_FIELDS, apply_fo_processing, fo_processing_audit
from copi_clock import initialize_copi_clock, load_pauses, pause_details
from ro_processing import RO_FIELDS, RO_LOCKED_FIELDS, OPEN_ACTIONS, apply_ro_processing, ro_processing_audit, migrate_return_workflow, LEGACY_ACTIONS
# GABAY SA PAGBASA NG eTracker ESD
# May Tagalog na gabay at validation ng transaction dates sa server at browser.
# Ang @app routes ay URL ng pahina; ang def ay function; ang SQL ay utos sa database.
# Ang render_template ay nagpapakita ng hiwalay na HTML file sa templates folder.
# Ang comments na nagsisimula sa # ay paliwanag at hindi utos na pinapatakbo.

"""eTracker ESD: lightweight Flask + SQLite application."""
# MGA LIBRARY: CSV, petsa, JSON, hashing, files, SQLite, Flask, at password checking.
import csv
import calendar
import io
import json
import hashlib
import os
import secrets
import re
import sqlite3
from datetime import date, datetime, timedelta
from functools import wraps
from pathlib import Path
from zoneinfo import ZoneInfo

from flask import Flask, abort, flash, redirect, render_template, request, Response, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

# PANGUNAHING SETTINGS: folder, database path, Flask app, secret key, at session cookies.
BASE = Path(__file__).resolve().parent
DB = Path(os.getenv('ETRACKER_DB', str(BASE / 'etracker.db')))
app = Flask(__name__)
from ui_labels import status_label
app.add_template_filter(status_label, 'status_label')
app.secret_key = os.getenv('ETRACKER_SECRET_KEY', '')
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')
# ========================================================================
# BAHAGI: local_today
# Kunin ang petsa ngayon ayon sa oras ng Pilipinas (Asia/Manila).
# ========================================================================
def local_today():
    return datetime.now(ZoneInfo('Asia/Manila')).date()

# MGA DROPDOWN AT STATUS: ito ang aktuwal na choices na ginagamit ng program.
CATEGORIES = ('CSE-PR', 'HGE', 'Other', 'OFW-PR', 'SKOE')
# Exact choices from Others 2026!G4:G582 data validation in the source workbook.
OFFICE_SOURCES = ('Walk-In', 'ISAFO', 'NVFO', 'QFO', 'BATFO')
OTHER_SUBTYPES = ('BOE', 'MC 11', 'SME', 'BHW', 'BNS', 'EDP', 'FSHGE', 'STS', 'VPR', 'SKOE')
SUBTYPES = {'CSE-PR': ('JOCOSC6', 'MUP'), 'HGE': (), 'Other': OTHER_SUBTYPES, 'OFW-PR': (), 'SKOE': ()}
FINAL_ACTIONS = ('Approved', 'Disapproved')
ACTIONS = ('', 'Received', 'On Process', 'Approved', 'Disapproved', 'Pending', 'Released', 'Other')
# Labels lang ang binago; nananatiling compatible ang dating stored values.
ACTION_LABELS = {value: status_label(value) for value in ACTIONS}


# MGA PROCESSOR: default na pangalan at mga alias na pinagsasama sa iisang pangalan.
PROCESSOR_NAMES = ('B. Bucala', 'AJ Barruga', ' J. Baquiran', 'JA. Canguilan')
PROCESSOR_ALIASES = {
    'b.bucala': 'B. Bucala', 'beverly': 'B. Bucala',
    'a.barruga': 'AJ Barruga', 'j.barruga': 'AJ Barruga', 'ajbarruga': 'AJ Barruga',
        'j.baquiran': 'J. Baquiran',
    'j.baquiran(esd)': 'J. Baquiran',
    'j.baquiran(fo)': 'J. Baquiran',
    'atty.j.baquiran': 'J. Baquiran',
    'j.canguilan': 'JA. Canguilan', 'jurist': 'JA. Canguilan', 'ja.canguilan': 'JA. Canguilan',
}

# ========================================================================
# BAHAGI: canonical_processor
# Pag-isahin ang magkakaibang baybay o alias ng pangalan ng processor.
# ========================================================================
def canonical_processor(value):
    value = (value or '').strip()
    return PROCESSOR_ALIASES.get(re.sub(r'\s+', '', value).casefold(), value)


# ========================================================================
# BAHAGI: conn
# Buksan ang SQLite database; gumamit ng mga row na naa-access sa pangalan ng column.
# I-enable ang foreign keys at WAL para sa pamamahala ng database.
# ========================================================================
def conn():
    DB.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA journal_mode=WAL')
    return guard_connection(db, 'transactions')


# ========================================================================
# BAHAGI: init_db
# Ihanda ang mga table, index, dagdag na column, at COPI trigger kung wala pa.
# Dito rin inaayos ang lumang pangalan/category/source at ginagawa ang unang admin account.
# transactions: pangunahing records; users: login; holidays: hindi bibilanging working days.
# audit: tala ng pagbabago; reference_counters/reference_changes: bilang at kasaysayan ng reference.
# import_review/history/resolutions: pagsusuri at pagsubaybay sa imported Excel records.
# ipmr_slots: manual na exam slots; copi_events: COPI tagging; exception_decisions: desisyon ng Chief.
# ========================================================================
def init_db():
    with conn() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS reference_counters (
            category TEXT PRIMARY KEY, last_number INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS reference_changes (
            id INTEGER PRIMARY KEY, transaction_id INTEGER NOT NULL,
            old_reference TEXT NOT NULL, new_reference TEXT NOT NULL,
            changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS ipmr_slots (
            year INTEGER NOT NULL, month INTEGER NOT NULL CHECK(month BETWEEN 1 AND 12),
            exam TEXT NOT NULL, slots INTEGER NOT NULL CHECK(slots >= 0),
            updated_by TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(year, month, exam)
        );
        CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS holidays (day TEXT PRIMARY KEY, label TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, reference TEXT NOT NULL UNIQUE,
            category TEXT NOT NULL, subtype TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '',
            received_on TEXT NOT NULL, applicant TEXT NOT NULL, eligibility TEXT NOT NULL DEFAULT '',
            first_processor TEXT NOT NULL DEFAULT '', first_date TEXT,
            second_processor TEXT NOT NULL DEFAULT '', acted_on TEXT,
            action TEXT NOT NULL DEFAULT '', released_fo_on TEXT,
            received_back_on TEXT, released_client_on TEXT,
            coe_copies INTEGER NOT NULL DEFAULT 0, auth_copies INTEGER NOT NULL DEFAULT 0,
            remarks TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_transactions_received ON transactions(received_on);
        CREATE INDEX IF NOT EXISTS idx_transactions_category ON transactions(category);
        CREATE INDEX IF NOT EXISTS idx_transactions_acted ON transactions(acted_on);
        CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, transaction_id INTEGER,
            username TEXT NOT NULL, event TEXT NOT NULL, happened_at TEXT DEFAULT CURRENT_TIMESTAMP);
        ''')
        # Enforce case-insensitive uniqueness even for direct database writes.
        db.execute('CREATE UNIQUE INDEX IF NOT EXISTS transactions_reference_normalized ON transactions(lower(trim(reference)))')
        # Upgrade an existing database in place; retain all records and logins.
        columns = {r['name'] for r in db.execute('PRAGMA table_xinfo(transactions)')}
        for field in ('pending_status', 'copi_reason', 'compliance_comment', *FO_FIELDS[:-1], 'ro_transmitted_fo', 'return_fo_reason', 'return_fo_destination', 'return_fo_comment'):
            if field not in columns:
                db.execute(f"ALTER TABLE transactions ADD COLUMN {field} TEXT NOT NULL DEFAULT ''")

        for name, definition in {
            'second_date':'TEXT', 'copi_tagged_at':'TEXT', 'copi_promulgated_on':'TEXT',
            'fo_transmitted_ro_on':'TEXT',
            'ro_transmitted_fo_on':'TEXT',
            'exception_status':"TEXT NOT NULL DEFAULT ''",
            'exception_remarks':"TEXT NOT NULL DEFAULT ''",
            'exception_by':"TEXT NOT NULL DEFAULT ''",
            'exception_at':'TEXT', 'exception_fingerprint':'TEXT',
            'exception_actual_days':'INTEGER', 'reckoning_on':'TEXT'
        }.items():
            if name not in columns:
                db.execute(f'ALTER TABLE transactions ADD COLUMN {name} {definition}')
        # Preserve legacy action dates, then use the second processor date for reports.
        for old in scoped_select(db, 'SELECT id,action,acted_on,second_date FROM transactions').fetchall():
            second = old['second_date'] or old['acted_on']
            final_date = second if old['action'] not in OPEN_ACTIONS else None
            if second != old['second_date'] or final_date != old['acted_on']:
                db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',
                    (old['id'], 'processor-date-update', json.dumps(dict(old), ensure_ascii=False)))
                db.execute('UPDATE transactions SET second_date=?,acted_on=? WHERE id=?',
                           (second, final_date, old['id']))
        db.executescript("""
        DROP TRIGGER IF EXISTS processor_action_insert;
        DROP TRIGGER IF EXISTS processor_action_update;
        CREATE TRIGGER processor_action_insert AFTER INSERT ON transactions
        BEGIN
          UPDATE transactions SET
            second_date=COALESCE(NULLIF(NEW.second_date,''),NULLIF(NEW.acted_on,'')),
            acted_on=CASE WHEN NEW.action IN ('','Received','Pending','FOR REVIEW','On Process','Return to FO') THEN NULL
              ELSE COALESCE(NULLIF(NEW.second_date,''),NULLIF(NEW.acted_on,'')) END
          WHERE id=NEW.id;
        END;
        CREATE TRIGGER processor_action_update
        AFTER UPDATE OF second_date,action,acted_on ON transactions
        WHEN NEW.acted_on IS NOT (CASE WHEN NEW.action IN ('','Received','Pending','FOR REVIEW','On Process','Return to FO') THEN NULL ELSE NULLIF(NEW.second_date,'') END)
        BEGIN
          UPDATE transactions SET acted_on=CASE WHEN NEW.action IN ('','Received','Pending','FOR REVIEW','On Process','Return to FO') THEN NULL
            ELSE NULLIF(NEW.second_date,'') END WHERE id=NEW.id;
        END;
        """)
        user_columns = {r['name'] for r in db.execute('PRAGMA table_info(users)')}
        if 'role' not in user_columns:
            db.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'staff'")
        db.execute("UPDATE users SET role='chief' WHERE lower(username)='ajvtb'")
        db.executescript("\n        CREATE TABLE IF NOT EXISTS exception_decisions (\n          id INTEGER PRIMARY KEY, transaction_id INTEGER NOT NULL, decision TEXT NOT NULL,\n          remarks TEXT NOT NULL, username TEXT NOT NULL, actual_days INTEGER NOT NULL,\n          fingerprint TEXT NOT NULL, decided_at TEXT NOT NULL);\n        CREATE TABLE IF NOT EXISTS copi_events (\n          id INTEGER PRIMARY KEY, transaction_id INTEGER NOT NULL, tagged_at TEXT NOT NULL);\n        CREATE TRIGGER IF NOT EXISTS copi_insert AFTER INSERT ON transactions\n        WHEN NEW.action='Pending' AND NEW.pending_status='For COPI'\n        BEGIN\n          UPDATE transactions SET copi_tagged_at=strftime('%Y-%m-%d %H:%M:%S','now','+8 hours') WHERE id=NEW.id;\n          INSERT INTO copi_events(transaction_id,tagged_at) VALUES(NEW.id,strftime('%Y-%m-%d %H:%M:%S','now','+8 hours'));\n        END;\n        CREATE TRIGGER IF NOT EXISTS copi_update AFTER UPDATE OF action,pending_status ON transactions\n        WHEN NEW.action='Pending' AND NEW.pending_status='For COPI'\n          AND NOT (OLD.action='Pending' AND OLD.pending_status='For COPI')\n        BEGIN\n          UPDATE transactions SET copi_tagged_at=strftime('%Y-%m-%d %H:%M:%S','now','+8 hours') WHERE id=NEW.id;\n          INSERT INTO copi_events(transaction_id,tagged_at) VALUES(NEW.id,strftime('%Y-%m-%d %H:%M:%S','now','+8 hours'));\n        END;\n")
        if 'reckoning_on' not in {r['name'] for r in db.execute('PRAGMA table_info(exception_decisions)')}:
            db.execute('ALTER TABLE exception_decisions ADD COLUMN reckoning_on TEXT')
        if 'reporting_year' not in columns:
            # Generated by SQLite: automatically follows the receipt date on edits.
            db.execute('ALTER TABLE transactions ADD COLUMN reporting_year INTEGER '
                       'GENERATED ALWAYS AS (CAST(substr(received_on,1,4) AS INTEGER)) VIRTUAL')
        if 'quantity' not in columns:
            db.execute('ALTER TABLE transactions ADD COLUMN quantity INTEGER NOT NULL DEFAULT 1 CHECK(quantity>0)')
        for name in ('received_ro_on', 'received_back_ro_on'):
            if name not in {r['name'] for r in db.execute('PRAGMA table_info(transactions)')}:
                db.execute(f'ALTER TABLE transactions ADD COLUMN {name} TEXT')
        for name, definition in [('return_fo_enabled', 'INTEGER NOT NULL DEFAULT 0'), ('received_ro_by', "TEXT NOT NULL DEFAULT ''"), ('received_fo_by', "TEXT NOT NULL DEFAULT ''")]:
            if name not in {r['name'] for r in db.execute('PRAGMA table_info(transactions)')}:
                db.execute(f'ALTER TABLE transactions ADD COLUMN {name} {definition}')
        from legacy_ro_receipt import backfill_old_fo_receipts
        backfill_old_fo_receipts(db, 'transactions')
        db.execute('CREATE TABLE IF NOT EXISTS import_review (source_key TEXT PRIMARY KEY, sheet TEXT, row_number INTEGER, reasons TEXT, raw_json TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS import_history (source_key TEXT PRIMARY KEY, digest TEXT NOT NULL, transaction_id INTEGER)')
        db.execute('CREATE TABLE IF NOT EXISTS import_resolutions (id INTEGER PRIMARY KEY, source_key TEXT NOT NULL, raw_json TEXT NOT NULL, corrected_json TEXT NOT NULL, username TEXT NOT NULL, transaction_id INTEGER NOT NULL, resolved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
        for flag in ('released_fo_na', 'received_back_na'):
            if flag not in columns:
                db.execute(f'ALTER TABLE transactions ADD COLUMN {flag} INTEGER NOT NULL DEFAULT 0 CHECK ({flag} IN (0,1))')
        migrate_return_workflow(db)
        migrate_action_rules(db)
        initialize_copi_clock(db, local_today().isoformat())
        db.execute('CREATE INDEX IF NOT EXISTS idx_transactions_year_category '
                   'ON transactions(reporting_year,category)')
        for category in CATEGORIES:
            db.execute('INSERT OR IGNORE INTO reference_counters(category,last_number) VALUES (?,0)', (category,))
        db.execute("UPDATE transactions SET subtype='' WHERE category='CSE-PR' AND subtype='CSE-PR'")
        for row in scoped_select(db, 'SELECT id,first_processor,second_processor FROM transactions').fetchall():
            for field in ('first_processor','second_processor'):
                old = row[field]
                new = canonical_processor(old)
                if new != old:
                    db.execute(f'UPDATE transactions SET {field}=? WHERE id=?', (new,row['id']))
                    db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',
                               (row['id'],'processor-name-update',field+': '+old+' -> '+new))
        # Preserve existing records; normalize only the renamed category and exact matches.
        db.execute("UPDATE transactions SET category='Other' WHERE category='Others'")
        db.execute("UPDATE transactions SET subtype=eligibility WHERE category='Other' "
                   "AND subtype='' AND eligibility IN (" + ','.join('?' for _ in OTHER_SUBTYPES) + ')', OTHER_SUBTYPES)
        for old, new in (('WI','Walk-In'), ('Isa','ISAFO'), ('NV','NVFO'), ('Qno','QFO'), ('Bat','BATFO')):
            db.execute('UPDATE transactions SET source=? WHERE source=?', (new,old))
        if not db.execute('SELECT 1 FROM users LIMIT 1').fetchone():
            password = os.getenv('ETRACKER_ADMIN_PASSWORD', '')
            if not password:
                raise RuntimeError('Set ETRACKER_ADMIN_PASSWORD before first run.')
            db.execute('INSERT INTO users(username,password_hash) VALUES (?,?)',
                       ('admin', generate_password_hash(password)))


# REFERENCE SETTINGS: source prefix at pangalan ng category sa reference.
SOURCE_CODES = {'Walk-In':'WI', 'ISAFO':'ISAFO', 'NVFO':'NVFO', 'QFO':'QFO', 'BATFO':'BATFO'}
REFERENCE_CATEGORIES = {'Other':'Others'}


# ========================================================================
# BAHAGI: reference_parts
# Basahin ang simula at dulo ng numero mula sa reference; ibalik ang None kung hindi tugma.
# ========================================================================
def reference_parts(reference, category):
    label = REFERENCE_CATEGORIES.get(category, category)
    match = re.fullmatch(r'(?:WI|ISAFO|NVFO|QFO|BATFO)-' + re.escape(label) + r'-(?:\d{4}-\d{4}-)?(\d{5,})(?:-(\d{5,}))?', reference or '')
    return (int(match[1]), int(match[2] or match[1])) if match else None


# ========================================================================
# BAHAGI: reference_text
# Buuin ang reference gamit ang source, category, petsa, at numero.
# Sa HGE, kasama ang unang at huling numero ng batch.
# ========================================================================
def reference_text(category, source, first, last, received_on):
    received = date.fromisoformat(parse_day(received_on, required=True))
    prefix = SOURCE_CODES[source] + '-' + REFERENCE_CATEGORIES.get(category, category) + f'-{received.year:04d}-{received.month:02d}{received.day:02d}'
    return f'{prefix}-{first:05d}-{last:05d}' if category == 'HGE' else f'{prefix}-{first:05d}'


# ========================================================================
# BAHAGI: reference_floor
# Hanapin ang pinakamataas na numero sa counter, baseline file, at kasalukuyang records.
# ========================================================================
def reference_floor(db, category):
    row = db.execute('SELECT last_number FROM reference_counters WHERE category=?', (category,)).fetchone()
    last = row[0] if row else 0
    manifest = BASE / 'reference-baseline.json'
    if manifest.exists():
        last = max(last, json.loads(manifest.read_text(encoding='utf-8'))['maxima'].get(category, 0))
    for row in scoped_select(db, 'SELECT reference FROM transactions WHERE category=?', (category,)):
        parts = reference_parts(row[0], category)
        if parts:
            last = max(last, parts[1])
    return last


# ========================================================================
# BAHAGI: assign_reference
# Magbigay o magpanatili ng reference ayon sa category, source, quantity, at petsa.
# Kapag reserve=False, preview lamang at hindi ina-update ang counter.
# ========================================================================
def assign_reference(db, data, existing=None, reserve=True):
    category, source, quantity = data['category'], data['source'], data['quantity']
    if category not in CATEGORIES or source not in SOURCE_CODES or not 1 <= quantity <= 99999:
        raise ValueError('Choose a category, Office/Source and valid quantity (1–99999).')
    if category != 'HGE' and quantity != 1:
        raise ValueError('Use one application per transaction outside HGE.')
    received_on = parse_day(data.get('received_on'), required=True)
    if existing and category == existing['category'] and quantity == existing['quantity']:
        parts = reference_parts(existing['reference'], category)
        if parts:
            return reference_text(category, source, *parts, received_on)
        if source == existing['source'] and received_on == existing['received_on']:
            return existing['reference']
    first = reference_floor(db, category) + 1
    last = first + quantity - 1
    if reserve:
        db.execute('INSERT INTO reference_counters VALUES (?,?) ON CONFLICT(category) DO UPDATE SET last_number=excluded.last_number', (category,last))
    return reference_text(category, source, first, last, received_on)


# ========================================================================
# BAHAGI: parse_day
# Suriin ang petsa at ibalik sa YYYY-MM-DD; ang optional na blanko ay None.
# ========================================================================
def parse_day(value, required=False):
    value = (value or '').strip()
    if not value:
        if required:
            raise ValueError('A date is required.')
        return None
    return date.fromisoformat(value).isoformat()


# ========================================================================
# BAHAGI: business_days
# Bilangin ang Lunes hanggang Biyernes, kasama ang simula at dulo.
# Hindi kasama ang holidays na nakatala sa database; bawal ang dulo bago ang simula.
# ========================================================================
def business_days(start, end, holidays):
    """Inclusive weekdays, excluding dates entered in Holiday Settings."""
    a, b = date.fromisoformat(start), date.fromisoformat(end)
    if b < a:
        raise ValueError('Action date cannot be earlier than date received.')
    n = 0
    while a <= b:
        if a.weekday() < 5 and a.isoformat() not in holidays:
            n += 1
        a += timedelta(days=1)
    return n


# ========================================================================
# BAHAGI: enriched
# Dagdagan ang records ng bilang ng working days at computed status.
# Approved/Disapproved na may acted_on lamang ang final action.
# Chief-set reckoning dates determine reported days; actual_days retains receipt-based age.
# Existing approved exceptions remain compatible until replaced by a reckoning date.
# ========================================================================
def chief_review_eligible(row, holidays, cutoff):
    """Only completed final decisions beyond 20 actual working days qualify."""
    r = dict(row)
    end = r.get('acted_on')
    start = r.get('received_on')
    if not (r.get('action') in FINAL_ACTIONS and start and end and start <= end <= cutoff):
        return False
    with conn() as db:
        intervals = load_pauses(db, [r]).get(r.get('id'), [])
    paused = pause_details(start, end, holidays, intervals)['copi_pause_days']
    return business_days(start, end, holidays) - paused > 20


def enriched(rows, holidays, cutoff):
    rows = [dict(row) for row in rows]
    with conn() as db:
        pause_history = load_pauses(db, rows)
    result = []
    for row in rows:
        r = dict(row)
        completed = bool(r['acted_on']) and r['action'] in FINAL_ACTIONS and r['acted_on'] <= cutoff
        r['days'] = business_days(r['received_on'], r['acted_on'] if completed else cutoff, holidays) if r['received_on'] <= cutoff or completed else 0
        r['actual_days'] = r['days']
        end = r['acted_on'] if completed else cutoff
        intervals = pause_history.get(r.get('id'), [])
        r.update(pause_details(r['received_on'], end, holidays, intervals))
        r['copi_paused'] = r['copi_paused'] and not completed
        r['copi_resumed_on'] = max((p['resumed_on'] for p in intervals if p['resumed_on'] and p['resumed_on'] <= cutoff), default=None)
        r['active_days'] = max(0, r['actual_days'] - r['copi_pause_days'])
        r['days'] = r['active_days']
        approval_days = r['actual_days']
        if not completed and r.get('exception_at'):
            approval_days = business_days(r['received_on'], min(cutoff, r['exception_at'][:10]), holidays)
        r['exception_applied'] = bool(completed and r['days'] > 20
            and r.get('exception_status') == 'approved'
            and r.get('exception_fingerprint') == exception_fingerprint(r)
            and r.get('exception_actual_days') == approval_days)
        if r['exception_applied']:
            r['days'] = 20
        end = r['acted_on'] if completed else cutoff
        r['reckoning_applied'] = bool(completed and r.get('reckoning_on') and r['received_on'] <= r['reckoning_on'] <= end)
        if r.get('reckoning_on'):
            r['exception_applied'] = False
            if r['reckoning_applied']:
                paused = pause_details(r['reckoning_on'], end, holidays, intervals)['copi_pause_days']
                r['days'] = max(0, business_days(r['reckoning_on'], end, holidays) - paused)
            else:
                r['days'] = r['active_days']
        r['state'] = ('Within 20 days' if r['days'] <= 20 else 'Beyond 20 days') if completed else ('Pending overdue' if r['days'] > 20 else 'Pending')
        result.append(r)
    return result


def report_activity(rows, holidays, start, cutoff):
    """Shared receipt/action periods and pending-at-cutoff classification."""
    rows = [dict(row) for row in rows if row['received_on'] <= cutoff]
    opening = [r for r in rows if r['received_on'] < start and
               (not r['acted_on'] or r['action'] not in FINAL_ACTIONS or r['acted_on'] >= start)]
    received = [r for r in rows if start <= r['received_on'] <= cutoff]
    acted = enriched([r for r in rows if r['action'] in FINAL_ACTIONS and r['acted_on']
                      and start <= r['acted_on'] <= cutoff], holidays, cutoff)
    pending = enriched([r for r in rows if not r['acted_on'] or r['action'] not in FINAL_ACTIONS
                        or r['acted_on'] > cutoff], holidays, cutoff)
    return dict(opening=opening, received=received, acted=acted, pending=pending)


# ========================================================================
# BAHAGI: login_required
# Harangan ang pahinang nangangailangan ng login; ibalik sa login kapag walang session.
# ========================================================================
def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('username'):
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapper


# ========================================================================
# BAHAGI: csrf_protection
# Sa bawat POST, itugma ang token ng form sa token ng session bago magpatuloy.
# ========================================================================
@app.before_request
def csrf_protection():
    if request.method == 'POST' and request.form.get('_csrf') != session.get('csrf'):
        abort(400, 'Invalid form token. Refresh the page and try again.')


# ========================================================================
# BAHAGI: globals_for_templates
# Ipadala sa HTML templates ang dropdown choices, processors, petsa, token, at Chief status.
# ========================================================================
@app.context_processor
def globals_for_templates():
    with conn() as db:
        processors = sorted({canonical_processor(r[0]) for r in scoped_select(db, "SELECT trim(first_processor) AS name FROM transactions UNION SELECT trim(second_processor) FROM transactions ORDER BY name COLLATE NOCASE") if r[0]} | set(PROCESSOR_NAMES), key=str.casefold)
    return {'csrf': session.get('csrf', ''), 'categories': CATEGORIES, 'subtypes': {**SUBTYPES, 'Other': tuple(v for v in OTHER_SUBTYPES if v != 'SKOE')}, 'office_sources': office_choices(OFFICE_SOURCES), 'actions': ACTIONS, 'action_labels': ACTION_LABELS,
            'today': local_today().isoformat(), 'processors': processors, 'is_chief': is_chief(), 'is_admin': is_admin(), 'can_manage_ro': can_manage_ro(), 'return_offices': ('ISAFO','NVFO','QFO','BATFO')}


# ========================================================================
# BAHAGI: reference_preview
# Ibalik ang reference preview mula sa form choices nang hindi nagrereserba ng numero.
# ========================================================================
@app.get('/reference-preview')
@login_required
def reference_preview():
    try:
        data = {'category':request.args.get('category',''), 'source':fo_office() or request.args.get('source',''),
                'quantity':int(request.args.get('quantity','1')), 'received_on':request.args.get('received_on','')}
        with conn() as db:
            existing = scoped_select(db, 'SELECT * FROM transactions WHERE id=?', (request.args.get('id'),)).fetchone() if request.args.get('id') else None
            value = assign_reference(db, data, existing, reserve=False)
        return {'reference':value}
    except (ValueError, KeyError):
        return {'reference':'', 'error':'Choose valid category, source, Date received and quantity.'}, 400


# ========================================================================
# BAHAGI: login
# Ipakita ang login form at suriin ang password hash.
# Kapag tama, gumawa ng bagong session/token at buksan ang dashboard.
# ========================================================================
@app.route('/login', methods=['GET', 'POST'])
def login():
    session.setdefault('csrf', secrets.token_urlsafe(32))
    if request.method == 'POST':
        with conn() as db:
            user = db.execute('SELECT * FROM users WHERE username=?', (request.form.get('username',''),)).fetchone()
        if user and check_password_hash(user['password_hash'], request.form.get('password','')):
            session.clear()
            session['username'] = user['username']
            session['csrf'] = secrets.token_urlsafe(32)
            return redirect(url_for('system_selector'))
        flash('Incorrect username or password. Please try again.')
    return render_template('login.html')


# ========================================================================
# BAHAGI: logout
# Burahin ang session at bumalik sa login.
# ========================================================================
@app.post('/logout')
@login_required
def logout():
    session.clear()
    return redirect(url_for('login'))


# ========================================================================
# BAHAGI: report_year
# Tiyaking wastong buong numero ang report year (1900 hanggang 9998).
# ========================================================================
def report_year(value):
    try:
        year = int(value)
        if not 1900 <= year <= 9998:
            raise ValueError()
        return year
    except (TypeError, ValueError):
        abort(400, 'Invalid report year')


# ========================================================================
# BAHAGI: available_years
# Buuin ang pagpipiliang taon mula sa receipt/action dates at kasalukuyang taon.
# ========================================================================
def available_years(db, selected):
    from year_management import configured_years
    years = {r[0] for r in scoped_select(db, 'SELECT DISTINCT reporting_year FROM transactions') if r[0]}
    years.update(r[0] for r in scoped_select(db, "SELECT DISTINCT CAST(substr(acted_on,1,4) AS INTEGER) FROM transactions WHERE acted_on IS NOT NULL"))
    years.update(configured_years(db))
    years.update((local_today().year, local_today().year + 1, selected))
    return sorted(years, reverse=True)


# ========================================================================
# BAHAGI: efficiency_rate
# Kuwentahin: within 20 days ÷ (beginning pending + bagong received) × 100.
# Kapag zero ang denominator, None ang resulta upang maipakitang N/A.
# ========================================================================
def efficiency_rate(within, opening, received):
    """IPMR indicator 5: timely final decisions / available applications."""
    denominator = opening + received
    return 100 * within / denominator if denominator else None


# ========================================================================
# BAHAGI: build_report
# Pangunahing kuwentahan ng daily, monthly, at yearly reports mula sa database.
# Ang cutoff ay mas maaga sa dulo ng napiling period at petsa ngayon.
# Opening: pending bago magsimula ang period; received: natanggap sa period.
# Acted: final decisions sa period; pending: wala pang final decision sa cutoff.
# Quantity ang sinusuma, kaya ang HGE batch ay maaaring higit sa isang application.
# ========================================================================
def build_report():
    year = report_year(request.args.get('year', local_today().year))
    scope = request.args.get('scope', 'year')
    month = request.args.get('month', local_today().strftime('%m'))
    day = request.args.get('day', local_today().isoformat())
    if scope not in ('day','month','year'):
        abort(400, 'Invalid report type')
    if scope == 'day':
        try:
            end = date.fromisoformat(day)
        except ValueError:
            abort(400, 'Invalid daily report date')
        year, start, label = end.year, end.isoformat(), end.isoformat()
    elif scope == 'month':
        if month not in [f'{m:02d}' for m in range(1,13)]:
            abort(400, 'Invalid report month')
        start = f'{year}-{month}-01'
        end = date(year,int(month),calendar.monthrange(year,int(month))[1])
        label = f'{year}-{month}'
    else:
        start, end, label = f'{year}-01-01', date(year,12,31), str(year)
    cutoff = min(end, local_today()).isoformat()
    requested_cutoff = request.args.get('report_cutoff')
    if requested_cutoff:
        try:
            cutoff = min(date.fromisoformat(cutoff), date.fromisoformat(requested_cutoff)).isoformat()
        except ValueError:
            abort(400, 'Invalid report cutoff')
    with conn() as db:
        years = available_years(db, year)
        rows = scoped_select(db, 'SELECT * FROM transactions WHERE received_on<=?', (cutoff,)).fetchall()
        holidays = {r['day'] for r in db.execute('SELECT day FROM holidays')}
        review_count = scoped_select(db, 'SELECT COUNT(*) FROM import_review').fetchone()[0]
    release_cohort = [dict(r) for r in rows if r['category'] in CATEGORIES]
    released_cohort = [r for r in release_cohort if r['released_client_on'] and r['released_client_on'] <= cutoff]
    unreleased_cohort = [r for r in release_cohort if not r['released_client_on'] or r['released_client_on'] > cutoff]
    legacy_count = sum(r['category'] not in CATEGORIES for r in rows)
    rows = [r for r in rows if r['category'] in CATEGORIES]
    if start > cutoff:
        rows = []
    activity = report_activity(rows, holidays, start, cutoff)
    opening, received, acted, pending = (activity[key] for key in ('opening', 'received', 'acted', 'pending'))
    carried = [r for r in pending if r['reporting_year'] < year]
    monthly = {c: {'opening': sum(r['quantity'] for r in opening if r['category']==c),
                   'received': sum(r['quantity'] for r in received if r['category']==c),
                   'acted': sum(r['quantity'] for r in acted if r['category']==c),
                   'within': sum(r['quantity'] for r in acted if r['category']==c and r['days']<=20),
                   'beyond': sum(r['quantity'] for r in acted if r['category']==c and r['days']>20),
                   'overdue': sum(r['quantity'] for r in pending if r['category']==c and r['days']>20),
                   'pending': sum(r['quantity'] for r in pending if r['category']==c)} for c in CATEGORIES}
    def display_date(value):
        d = date.fromisoformat(value)
        return f'{calendar.month_name[d.month]} {d.day}, {d.year}'
    previous = date.fromisoformat(start) - timedelta(days=1)
    period_display = (display_date(start) if scope=='day' else
                      f'{calendar.month_name[int(month)]} {year}' if scope=='month' else str(year))
    period_phrase = ('on ' if scope=='day' else 'in ') + period_display
    opening_label = (f'Pending from {calendar.month_name[previous.month]} {previous.year}' if scope=='month'
                     else f'Pending from {previous.year}' if scope=='year'
                     else f'Pending as of {display_date(previous.isoformat())}')
    labels = dict(opening=opening_label, received=f'Received {period_phrase}',
                  acted=f'Total Acted Applications {period_phrase}', within=f'Acted within 20 working days {period_phrase}',
                  beyond=f'Acted beyond 20 working days {period_phrase}',
                  pending=f'Pending as of {display_date(cutoff)}',
                  overdue=f'Pending beyond 20 days as of {display_date(cutoff)}',
                  holidays=f'Holidays {period_phrase}',
                  carried=f'Pending received before {year}, as of {display_date(cutoff)}')
    opening_total = sum(r['quantity'] for r in opening)
    received_total = sum(r['quantity'] for r in received)
    within_total = sum(r['quantity'] for r in acted if r['days'] <= 20)
    for counts in monthly.values():
        counts['efficiency'] = efficiency_rate(counts['within'], counts['opening'], counts['received'])
    labels.update(all_received=f'All received as of {display_date(cutoff)}',
                  released=f'Released to client as of {display_date(cutoff)}',
                  unreleased=f'Not Yet Released as of {display_date(cutoff)}')
    result = dict(all_received=release_cohort, released=released_cohort, unreleased=unreleased_cohort,
                all_received_total=sum(r['quantity'] for r in release_cohort),
                released_total=sum(r['quantity'] for r in released_cohort),
                unreleased_total=sum(r['quantity'] for r in unreleased_cohort),
                approved_exception_total=sum(r['quantity'] for r in acted if r['exception_applied']),
                copi_paused_total=sum(r['quantity'] for r in pending if r['copi_paused']),
                efficiency=efficiency_rate(within_total, opening_total, received_total),
                efficiency_denominator=opening_total + received_total,
                labels=labels, period_display=period_display, cutoff_display=display_date(cutoff),
                opening_cutoff_display=display_date(previous.isoformat()), opening=opening,
                opening_total=sum(r['quantity'] for r in opening),
                review_count=review_count, received_total=sum(r['quantity'] for r in received), acted_total=sum(r['quantity'] for r in acted), pending_total=sum(r['quantity'] for r in pending), carried_total=sum(r['quantity'] for r in carried), legacy_count=legacy_count, year=year, years=years, month=month, day=day, scope=scope, future=start>cutoff,
                           period=label, cutoff=cutoff, received=received, acted=acted,
                           pending=pending, carried=carried, monthly=monthly,
                           holiday_count=sum(h.startswith(label) for h in holidays),
                           within=sum(r['quantity'] for r in acted if r['days']<=20),
                           beyond=sum(r['quantity'] for r in acted if r['days']>20),
                           overdue=sum(r['quantity'] for r in pending if r['days']>20))


    # Legacy balances are aggregate counts, not invented individual transactions.
    if scope in ('month', 'year') and start <= cutoff:
        for balance in legacy_ipmr_balances(year):
            opening_extra = balance['opening_quantity'] if scope == 'year' or month == '01' else 0
            acted_extra = balance['within_quantity'] + balance['beyond_quantity'] if scope == 'year' or int(month) == balance['acted_month'] else 0
            within_extra = balance['within_quantity'] if acted_extra else 0
            beyond_extra = balance['beyond_quantity'] if acted_extra else 0
            result['opening_total'] += opening_extra
            result['acted_total'] += acted_extra
            result['within'] += within_extra
            result['beyond'] += beyond_extra
            counts = result['monthly'][balance['category']]
            counts['opening'] += opening_extra
            counts['acted'] += acted_extra
            counts['within'] += within_extra
            counts['beyond'] += beyond_extra
            counts['efficiency'] = efficiency_rate(counts['within'], counts['opening'], counts['received'])
        result['efficiency_denominator'] = result['opening_total'] + result['received_total']
        result['efficiency'] = efficiency_rate(result['within'], result['opening_total'], result['received_total'])
    return result


# ========================================================================
# BAHAGI: dashboard
# Ipakita ang dashboard gamit ang build_report at taunang IPMR data.
# ========================================================================
@app.route('/')
@login_required
def dashboard():
    report = build_report()
    report['ipmr_report_data'] = None if fo_office() else ipmr_report(report['year'])
    html = render_template('dashboard.html', **report)
    return html.replace('</main>', render_template('release_summary.html', report=report)+'</main>', 1)


# ========================================================================
# BAHAGI: beyond_details
# Ipakita ang final-action records na lampas 20 reported working days; may category filter.
# ========================================================================
@app.get('/dashboard/beyond-20-days')
@login_required
def beyond_details():
    report = build_report()
    category = request.args.get('category', '')
    if category and category not in CATEGORIES:
        abort(400, 'Invalid category')
    rows = [r for r in report['acted'] if r['days'] > 20 ]
    rows.sort(key=lambda r: (r['acted_on'], r['id']), reverse=True)
    return render_record_list('beyond_details.html', report=report, rows=rows,
                           category=category, total=sum(r['quantity'] for r in rows))


# ========================================================================
# BAHAGI: dashboard_records
# Ipakita ang records sa likod ng napiling dashboard metric.
# May hiwalay na pagpili para sa within, beyond, overdue, at holidays.
# ========================================================================
# SEARCH AT PAGING: salain muna ang buong listahan bago hatiin sa mga page.
def paginate_records(records, prefix=''):
    q = request.args.get(prefix+'q', '').strip()
    try:
        page = max(1, int(request.args.get(prefix+'page', '1')))
        size = int(request.args.get(prefix+'per_page', '25'))
        if size not in (25,50,100): raise ValueError()
    except ValueError:
        abort(400, 'Invalid paging options.')
    original = [dict(r) for r in records]
    matched = [r for r in original if not q or any(q.casefold() in str(v or '').casefold() for v in r.values())]
    pages = max(1, (len(matched)+size-1)//size)
    page = min(page,pages)
    start = (page-1)*size
    def link(number):
        args = request.args.to_dict()
        args.update({prefix+'q':q, prefix+'page':number, prefix+'per_page':size})
        return url_for(request.endpoint, **dict(request.view_args or {}), **args)
    return matched[start:start+size], dict(q=q, page=page, pages=pages, size=size,
        records=len(matched), all_records=len(original),
        applications=sum(r.get('quantity',1) for r in matched),
        first=start+1 if matched else 0, last=min(start+size,len(matched)),
        link=link, prefix=prefix)


def record_list_csv(rows, filename):
    rows = [dict(row) for row in rows]
    preferred = ['reference','applicant','category','subtype','source','quantity','received_on',
                 'acted_on','days','actual_days','copi_pause_days','active_days','copi_paused','copi_hold_since','copi_resumed_on','action','pending_status','first_processor',
                 'first_date','second_processor','second_date','received_ro_on','received_back_ro_on','released_fo_on','received_back_on',
                 'released_client_on','copi_tagged_at','copi_promulgated_on','copi_reason',
                 'compliance_comment','remarks','day','label','source_key','sheet','row_number','reasons']
    keys = [key for key in preferred if not rows or any(key in row for row in rows)]
    out = io.StringIO(); writer = csv.writer(out)
    writer.writerow([key.replace('_',' ').title() for key in keys])
    def cell(value):
        text = '' if value is None else str(value)
        return "'" + text if text.startswith(('=', '+', '-', '@')) else text
    for row in rows:
        writer.writerow([cell(row.get(key)) for key in keys])
    return Response('\ufeff'+out.getvalue(), mimetype='text/csv',
        headers={'Content-Disposition': f'attachment; filename={filename}.csv'})


def record_csv_link(kind='1'):
    args = request.args.to_dict(); args.pop('page', None); args['download_csv'] = kind
    return url_for(request.endpoint, **dict(request.view_args or {}), **args)


def render_record_list(template, list_key='rows', **context):
    if template == 'priority.html':
        export_kind = request.args.get('download_csv')
        lists = {'priority': context['items'], 'copi': context['copi_items'], 'review': context['review_rows']}
        if export_kind:
            if export_kind not in lists: abort(400, 'Invalid export list')
            return record_list_csv(lists[export_kind], export_kind)
        context['csv_links'] = {kind: record_csv_link(kind) for kind in lists}
        # Show all Priority and Review records without search or paging controls.
        context['review_list_controls'] = ''
        return render_template(template, **context)
    category_filter = template in ('dashboard_records.html','beyond_details.html') and context.get('metric') != 'holidays'
    category_counts = {}
    selected_category = request.args.get('category', '') if category_filter else ''
    if category_filter:
        if selected_category and selected_category not in CATEGORIES: abort(400, 'Invalid category')
        candidates, searched = paginate_records(context[list_key])
        q = searched['q'].casefold()
        category_counts = {c:sum(r.get('quantity',1) for r in context[list_key] if r['category']==c and (not q or any(q in str(v or '').casefold() for v in dict(r).values()))) for c in CATEGORIES}
        context[list_key] = [r for r in context[list_key] if not selected_category or r['category']==selected_category]
    if request.args.get('download_csv'):
        q = request.args.get('q', '').strip().casefold()
        export_rows = [dict(row) for row in context[list_key] if not q or any(q in str(value or '').casefold() for value in dict(row).values())]
        return record_list_csv(export_rows, request.endpoint)
    csv_button = '<div class="no-print"><a class="button" href="' + record_csv_link() .replace('&', '&amp;') + '">Download CSV</a></div>'
    context[list_key], paging = paginate_records(context[list_key])
    context['category'] = selected_category if category_filter else context.get('category', '')
    context['total_records'] = paging['records']
    if 'total' in context: context['total'] = paging['applications']
    controls = render_template('record_list_controls.html', paging=paging, category_filter=category_filter, category_counts=category_counts, selected_category=selected_category)
    if 'review_rows' in context:
        context['review_rows'], review_paging = paginate_records(context['review_rows'], 'review_')
        context['review_list_controls'] = render_template('record_list_controls.html', paging=review_paging)
    html = render_template(template, **context)
    # Ilagay ang controls sa simula at dulo ng content; hindi binabago ang database.
    marker = '<main id="main-content" tabindex="-1">'
    html = html.replace(marker, marker+csv_button+controls, 1)
    if template == 'copi.html':
        return html  # Isang search/paging panel lang sa itaas ng COPI.
    return html.replace('</main>', controls+'</main>', 1)


@app.get('/dashboard/records/<metric>')
@login_required
def dashboard_records(metric):
    if metric not in ('opening','received','acted','pending','within','beyond','overdue','holidays','all_received','released','unreleased'):
        abort(404)
    report = build_report()
    category = request.args.get('category', '')
    if category and category not in CATEGORIES: abort(400, 'Invalid category')
    with conn() as db:
        holiday_rows = [dict(r) for r in db.execute('SELECT day,label FROM holidays ORDER BY day')]
    holidays = {r['day'] for r in holiday_rows}
    if metric == 'holidays':
        rows = [r for r in holiday_rows if r['day'].startswith(report['period'])]
        total = len(rows)
    else:
        source = report['acted'] if metric in ('within','beyond') else report['pending'] if metric=='overdue' else report[metric]
        rows = []
        for item in source:
            if metric == 'within' and item['days'] > 20: continue
            if metric in ('beyond','overdue') and item['days'] <= 20: continue
            row = dict(item)
            if metric == 'opening':
                if report['scope']=='day': start=date.fromisoformat(report['day'])
                elif report['scope']=='month': start=date(report['year'],int(report['month']),1)
                else: start=date(report['year'],1,1)
                endpoint=(start-timedelta(days=1)).isoformat()
            else:
                endpoint = row['acted_on'] if row['action'] in FINAL_ACTIONS and row['acted_on'] and row['acted_on'] <= report['cutoff'] else report['cutoff']
            if metric not in ('acted','within','beyond'):
                row.update(enriched([row], holidays, endpoint)[0])
            rows.append(row)
        rows.sort(key=lambda r:(r['received_on'],r['id']), reverse=True)
        total = sum(r['quantity'] for r in rows)
    return render_record_list('dashboard_records.html', metric=metric, report=report,
                           rows=rows, category=category, total=total)


# ========================================================================
# BAHAGI: report_csv
# I-download ang summary report bilang CSV gamit ang parehong dashboard computation.
# ========================================================================
@app.get('/report.csv')
@login_required
def report_csv():
    # Dashboard, print and CSV share the same calculation to avoid discrepancies.
    r = build_report()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['eTracker ESD report', r['scope'], r['period']])
    writer.writerow(['Pending cutoff', r['cutoff']])
    writer.writerow(['Status', 'Future period: no activity yet' if r['future'] else 'Based on current transaction dates'])
    keys = ('opening','received','acted','within','beyond','pending','overdue')
    writer.writerow(['Chief-approved exceptions reported as 20 days', r['approved_exception_total']])
    writer.writerow(['Opening balance as of', r['opening_cutoff_display']])
    writer.writerow(['Category', *(r['labels'][k] for k in keys)])
    for category, counts in r['monthly'].items():
        writer.writerow([category, *(counts[k] for k in keys)])
    writer.writerow(['TOTAL', *(sum(c[k] for c in r['monthly'].values()) for k in keys)])
    writer.writerow(['Pending from earlier receipt years',r['carried_total']])
    writer.writerow(['Efficiency denominator: beginning pending + new receipts', r['efficiency_denominator']])
    writer.writerow(['Efficiency (%)', round(r['efficiency'], 2) if r['efficiency'] is not None else 'N/A'])
    return Response('\ufeff'+output.getvalue(),mimetype='text/csv',headers={
        'Content-Disposition':f'attachment; filename=etracker-{r["scope"]}-{r["period"]}.csv'})


# ========================================================================
# BAHAGI: ipmr_report
# Pagsamahin ang 12 monthly reports ayon sa category/subtype.
# Sa annual opening, January balance lang; sa annual pending, pinakahuling non-future balance.
# ========================================================================
def legacy_ipmr_balances(year):
    if fo_office(): return []
    # Summary balances confirmed by the user; no invented applicant records/dates.
    with conn() as db:
        exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='ipmr_legacy_balances'").fetchone()
        return [dict(r) for r in db.execute('SELECT * FROM ipmr_legacy_balances WHERE report_year=?', (year,))] if exists else []


def ipmr_report(year, as_of_month=12):
    cutoff = min(local_today(), date(year, as_of_month, calendar.monthrange(year, as_of_month)[1])).isoformat()
    reports = []
    for month in range(1, 13):
        with app.test_request_context(f'/?scope=month&year={year}&month={month:02d}&report_cutoff={cutoff}'):
            reports.append(build_report())
    legacy = legacy_ipmr_balances(year)
    groups = [('CSE-PR', ''), ('CSE-PR', 'MUP'), ('HGE', ''), ('Other', None), ('OFW-PR', None), ('SKOE', None)]
    lines = []
    for metric in ('opening', 'received', 'within', 'beyond', 'pending'):
        for category, subtype in groups:
            values = []
            for report in reports:
                source = report['acted'] if metric in ('within','beyond') else report[metric]
                values.append(sum(r['quantity'] for r in source if r['category']==category
                    and (subtype is None or r['subtype']==subtype)
                    and (metric not in ('within','beyond') or
                         (r['days']<=20 if metric=='within' else r['days']>20))))
            for balance in legacy:
                if balance['category'] == category and subtype in ('', None):
                    if metric == 'opening':
                        values[0] += balance['opening_quantity']
                    elif metric in ('within', 'beyond') and balance['acted_month'] <= as_of_month:
                        values[balance['acted_month']-1] += balance[metric + '_quantity']
            past = [i for i, r in enumerate(reports) if not r['future']]
            total = values[past[-1]] if metric=='pending' and past else (0 if metric=='pending' else sum(values))
            if metric == 'opening':
                total = values[0]
            lines.append(dict(metric=metric, label=category + (' / '+subtype if subtype else ''), values=values, total=total))
    for metric in ('opening','received','within','beyond','pending'):
        group=[line for line in lines if line['metric']==metric]
        lines.append(dict(metric=metric,label='TOTAL',values=[sum(line['values'][i] for line in group) for i in range(12)],total=sum(line['total'] for line in group)))
    received = [r['received_total'] for r in reports]
    within = [r['within'] for r in reports]
    openings = [r['opening_total'] for r in reports]
    # Annual beginning balance is counted once; monthly carryovers are not summed.
    annual_opening = openings[0]
    return dict(year=year, reports=reports, lines=lines,
        approved_exception_total=sum(r['approved_exception_total'] for r in reports),
        efficiency=[efficiency_rate(w,o,r) for w,o,r in zip(within,openings,received)],
        efficiency_denominators=[o+r for o,r in zip(openings,received)],
        annual_efficiency_denominator=annual_opening + sum(received),
        annual_efficiency=efficiency_rate(sum(within), annual_opening, sum(received)),
        review_count=reports[0]['review_count'])


# ========================================================================
# BAHAGI: ipmr
# Ipakita ang IPMR template para sa napiling taon.
# ========================================================================
@app.get('/ipmr')
@login_required
def ipmr():
    year = report_year(request.args.get('year',local_today().year))
    with conn() as db:
        years=available_years(db,year)
    return render_template('ipmr.html',years=years,**ipmr_template_report(year))


# ========================================================================
# BAHAGI: ipmr_csv
# I-download ang IPMR template rows, buwanang halaga, at annual totals bilang CSV.
# ========================================================================
@app.get('/ipmr.csv')
@login_required
def ipmr_csv():
    r = ipmr_template_report(report_year(request.args.get('year', local_today().year)))
    out = io.StringIO(); writer = csv.writer(out)
    writer.writerow(['INTEGRATED PERFORMANCE MONITORING REPORT', r['year'], 'As of', r['cutoff']])
    writer.writerow(['PREXC INDICATOR', 'TECHNICAL DEFINITION', 'PO', *r['months'], 'TOTAL THROUGH CUTOFF', 'REMARKS'])
    for row in r['template_rows']:
        values = [('N/A' if v is None else f'{v:.2f}%' if row['rate'] else v) for v in row['values'] + [row['annual']]]
        writer.writerow([row['label'], row['definition'], row['po'], *values, ''])
    return Response('\ufeff'+out.getvalue(), mimetype='text/csv', headers={'Content-Disposition': f'attachment; filename=ipmr-{r["year"]}.csv'})




# ========================================================================
# BAHAGI: priority
# Ilista ang unresolved records na 17 working days pataas.
# Sa kasalukuyang code, 17–19 ay Priority at 20 pataas ay Overdue.
# Sa ibang report, Beyond 20 days ay higit sa 20; magkaiba ang eksaktong kondisyon.
# ========================================================================
@app.get('/priority')
@login_required
def priority():
    """Operational watchlist for unresolved requests nearing/exceeding the 20-working-day threshold."""
    cutoff = local_today().isoformat()
    with conn() as db:
        rows = scoped_select(db, 'SELECT * FROM transactions WHERE received_on<=? ORDER BY received_on,id', (cutoff,)).fetchall()
        holidays = {r['day'] for r in db.execute('SELECT day FROM holidays')}
    items = []
    copi_items = []
    for item in enriched(rows, holidays, cutoff):
        if item['category'] not in CATEGORIES:
            continue
        if item['acted_on'] and item['action'] in FINAL_ACTIONS and item['acted_on'] <= cutoff:
            continue
        if item['action']=='Pending' and item['pending_status']=='For COPI':
            copi_items.append(item)
            continue
        if item['days'] >= 15:
            item['priority_state'] = 'Beyond 20 days' if item['days'] > 20 else 'Priority'
            item['days_to_20'] = max(0, 20 - item['days'])
            items.append(item)
    items.sort(key=lambda r: (-r['days'], r['received_on'], r['id']))
    review_rows, recent = review_content()
    copi_items.sort(key=lambda r: (-r['days'],r['id']))
    return render_record_list('priority.html', list_key='items', review_rows=review_rows, recent=recent, items=items, copi_items=copi_items, cutoff_display=f"{calendar.month_name[local_today().month]} {local_today().day}, {local_today().year}",
                           overdue_count=sum(r['quantity'] for r in items if r['days'] > 20),
                           priority_count=sum(r['quantity'] for r in items if 15 <= r['days'] <= 20))


# ========================================================================
# BAHAGI: processors_report
# I-tally ang applications ng bawat first/second processor gamit ang quantity.
# Sa unique tally, isang beses lang ang record kahit pareho ang first at second processor.
# Ang year/month filter dito ay batay sa date received.
# ========================================================================
@app.get('/processors')
@login_required
def processors_report():
    selected = canonical_processor(request.args.get('processor', ''))
    year_value = request.args.get('year', '')
    year = report_year(year_value) if year_value else None
    month_value = ''  # Received Month filter removed.
    try:
        month = int(month_value) if month_value else None
        if month is not None and not 1 <= month <= 12: raise ValueError()
        processed_value = request.args.get('processed_month', '')
        processed_month = int(processed_value) if processed_value else None
        if processed_month is not None and not 1 <= processed_month <= 12: raise ValueError()
    except ValueError:
        abort(400, 'Choose a valid month.')
    with conn() as db:
        years = available_years(db, year or local_today().year)
        records = scoped_select(db, 'SELECT * FROM transactions ORDER BY received_on DESC,id DESC').fetchall()
    names = sorted({canonical_processor(r[k]) for r in records for k in ('first_processor','second_processor') if r[k].strip()}, key=str.casefold)
    summary = {name:dict(name=name,first=0,second=0,first_records=0,second_records=0,unique=0) for name in names if not selected or name==selected}
    totals = dict(first=0,second=0,unique=0,unassigned=0)
    # Received filters ay para sa receipt date; processed month ay para sa bawat role date.
    for row in records:
        if year and row['reporting_year'] != year: continue
        if month and int(row['received_on'][5:7]) != month: continue
        roles = []
        for role, field, date_field in (('first','first_processor','first_date'), ('second','second_processor','second_date')):
            processed_date = row[date_field]
            if processed_month is None or (processed_date and processed_date <= local_today().isoformat()
                                           and int(processed_date[5:7]) == processed_month):
                roles.append((role, field))
        if not roles: continue
        participants = {canonical_processor(row[field]) for role, field in roles} - {''}
        if not participants and not selected: totals['unassigned'] += row['quantity']
        if any(name in summary for name in participants): totals['unique'] += row['quantity']
        for name in participants:
            if name in summary: summary[name]['unique'] += row['quantity']
        for role, field in roles:
            name = canonical_processor(row[field])
            if name in summary:
                summary[name][role] += row['quantity']
                totals[role] += row['quantity']
                summary[name][role+'_records'] += 1
    monthly_processors = []
    for name in summary:
        counts = dict(name=name, first=[0]*12, second=[0]*12, unique=[0]*12)
        for row in records:
            if year and row['reporting_year'] != year: continue
            matched_months = set()
            for role, field, date_field in (('first','first_processor','first_date'), ('second','second_processor','second_date')):
                processed_date = row[date_field]
                if canonical_processor(row[field]) != name or not processed_date or processed_date > local_today().isoformat(): continue
                m = int(processed_date[5:7])-1
                counts[role][m] += row['quantity']
                matched_months.add(m)
            for m in matched_months: counts['unique'][m] += row['quantity']
        monthly_processors.append(counts)
    return render_template('processors.html', monthly_processors=monthly_processors, totals=totals, summaries=list(summary.values()), names=names,
                           selected=selected, year=year, month=month, years=years,
                           month_names=calendar.month_name, processed_month=processed_month)

# ========================================================================
# BAHAGI: transactions
# Hanapin at i-filter ang transactions ayon sa taon, category, text, at computed status.
# Hanggang 1000 pinakabagong matching records ang kinukuha bago ang status filter.
# ========================================================================
@app.route('/transactions')
@login_required
def transactions():
    year_value = request.args.get('year', str(local_today().year))
    year = report_year(year_value) if year_value else None
    # Salain ayon sa buwan ng Date Received bago ang search/status paging.
    month_value = request.args.get('month', '')
    try:
        month = int(month_value) if month_value else None
        if month is not None and not 1 <= month <= 12: raise ValueError()
    except ValueError: abort(400, 'Choose a valid received month.')
    q = request.args.get('q','').strip()
    category = request.args.get('category','')
    source = request.args.get('source', '').strip()
    if source not in ('', 'FOs', *OFFICE_SOURCES):
        abort(400, 'Choose a valid Source.')
    status = request.args.get('status','')
    release_status = request.args.get('release_status', '')
    if release_status not in ('', 'released', 'unreleased'): abort(400, 'Invalid release status.')
    try:
        page = max(1, int(request.args.get('page', '1')))
        per_page = int(request.args.get('per_page', '25'))
        if per_page not in (25,50,100): raise ValueError()
    except ValueError: abort(400, 'Invalid paging options.')
    with conn() as db:
        years = available_years(db, year or local_today().year)
        rows = scoped_select(db, 'SELECT * FROM transactions WHERE (? IS NULL OR reporting_year=?) AND (?="" OR category=?) AND (?="" OR reference LIKE ? OR applicant LIKE ? OR eligibility LIKE ?) ORDER BY received_on DESC,id DESC',
            (year, year, category, category, q, f'%{q}%', f'%{q}%', f'%{q}%')).fetchall()
        holidays = {r['day'] for r in db.execute('SELECT day FROM holidays')}
    if source:
        def matching_source(value):
            cleaned = re.sub(r'[\s_-]', '', str(value or '')).lower()
            return 'Walk-In' if cleaned in ('wi', 'walkin') else normalize_office(value)
        rows = [r for r in rows if (matching_source(r['source']) in OFFICE_SOURCES[1:] if source == 'FOs' else matching_source(r['source']) == source)]
    if month is not None:
        rows = [r for r in rows if int(r['received_on'][5:7]) == month]
    rows = enriched(rows, holidays, local_today().isoformat())
    if status: rows = [r for r in rows if r['state']==status]
    for row in rows:
        row['client_released'] = bool((row['released_client_on'] or '').strip())
    if release_status:
        rows = [r for r in rows if r['client_released'] == (release_status == 'released')]
    total = len(rows)
    pages = max(1, (total + per_page - 1) // per_page)
    page = min(page, pages)
    start = (page-1)*per_page
    rows = rows[start:start+per_page]
    def page_url(number):
        return url_for('transactions', year=year_value, q=q, category=category, source=source,
                       status=status, month=month or '', release_status=release_status, per_page=per_page, page=number)
    return render_template('transactions.html', rows=rows, q=q, category=category, source=source,
        status=status, year=year, years=years, month=month, month_names=calendar.month_name, release_status=release_status,
        page=page, pages=pages, per_page=per_page, total=total,
        first_display=start+1 if total else 0, last_display=start+len(rows), page_url=page_url)


# MGA FIELD: pagkakasunod-sunod ng columns na isinusulat mula sa transaction form.
FIELDS = ('reference','category','subtype','source','received_on','applicant','eligibility',
          'first_processor','first_date','second_processor','second_date','acted_on','action','released_fo_on',
          'received_back_on','released_client_on','remarks','released_fo_na','received_back_na','quantity','pending_status','copi_reason','compliance_comment','copi_promulgated_on','received_ro_on','received_back_ro_on','return_fo_enabled','received_ro_by','received_fo_by') + FO_FIELDS + RO_FIELDS
# MGA PETSA: fields na sinusuri sa YYYY-MM-DD format.
DATE_FIELDS = ('received_on','first_date','second_date','acted_on','released_fo_on','received_back_on','released_client_on','received_ro_on','received_back_ro_on')


# ========================================================================
# BAHAGI: transaction_from_form
# Basahin, linisin, at i-validate ang form bago isulat sa database.
# Suriin ang category/source/subtype, quantity, dates, N/A flags, COPI reason, at compliance.
# Hindi maaaring may acted_on ang Pending; kailangan ang action date sa ibang action.
# ========================================================================
# MGA PETSA: parehong tuntunin ang ginagamit sa server at browser.
TRANSACTION_DATE_LABELS = {
    'received_on': 'Date Received', 'first_date': 'Date Acted by First Processor',
    'second_date': 'Date Acted by Second Processor', 'acted_on': 'Action Date',
    'released_fo_on': 'Date of Return Back to FO',
    'received_back_on': 'Date Received Back from FO',
    'received_ro_on': 'Date Received by RO',
    'received_back_ro_on': 'Date Received Back from RO',
    'released_client_on': 'Date Released to Client',
}

def validate_transaction_dates(data):
    data['acted_on'] = data.get('second_date') if data.get('action') not in OPEN_ACTIONS else None
    # Suriin ang aktuwal na petsa bago magsulat sa database.
    today = local_today().isoformat()
    for key, label in TRANSACTION_DATE_LABELS.items():
        raw = (data.get(key) or '').strip()
        if key in ('released_fo_on', 'received_back_on'):
            flag = 'released_fo_na' if key == 'released_fo_on' else 'received_back_na'
            if data.get(flag) in (1, '1'):
                if raw:
                    raise ValueError(f'{label}: clear the date when Not applicable is selected.')
                data[key] = None
                continue
        if not raw:
            if key == 'received_on':
                raise ValueError('Date received is required.')
            data[key] = None
            continue
        try:
            if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', raw):
                raise ValueError()
            data[key] = date.fromisoformat(raw).isoformat()
        except ValueError:
            raise ValueError(f'{label}: enter a valid date in YYYY-MM-DD format.') from None
        if data[key] > today:
            raise ValueError(f'{label}: cannot be later than today ({today}).')
    received = data['received_on']
    for key, label in TRANSACTION_DATE_LABELS.items():
        if key != 'received_on' and data[key] and data[key] < received:
            raise ValueError(f'{label}: cannot be earlier than Date received.')
    if data['received_back_on'] and data['released_fo_on'] and data['received_back_on'] < data['released_fo_on']:
        raise ValueError('Date returned from Field Office cannot precede Date sent to Field Office.')
    if data.get('received_ro_on') and data.get('released_fo_on') and data['released_fo_on'] < data['received_ro_on']:
        raise ValueError('Date Released to FO must not precede Date Received by RO.')
    if data.get('received_ro_on') and data.get('second_date') and data['second_date'] < data['received_ro_on']:
        raise ValueError('Date Acted by Second Processor cannot be earlier than Date Received by RO.')
    if data.get('received_ro_on') and data.get('received_back_ro_on') and data['received_back_ro_on'] < data['received_ro_on']:
        raise ValueError('Date Received Back from RO cannot precede Date Received by RO.')
    if data.get('action') == 'Pending' and data['acted_on']:
        raise ValueError('Leave the action date blank while the application is pending.')
    if data.get('action') not in OPEN_ACTIONS and not data['acted_on']:
        raise ValueError('Enter Date Acted by Second Processor for a non-pending action.')


@app.after_request
def add_transaction_date_guard(response):
    # Idagdag ang browser checks sa transaction forms nang hindi pinapalitan ang HTML templates.
    if request.endpoint in ('new_transaction', 'edit_transaction', 'review_edit') and response.mimetype == 'text/html':
        html = response.get_data(as_text=True)
        if 'id="transaction-form"' in html:
            config = json.dumps({'today': local_today().isoformat(), 'labels': TRANSACTION_DATE_LABELS})
            script = '<script id="transaction-date-config" type="application/json">' + config + '</script>'
            script += '<script src="' + url_for('static', filename='transaction-date-validation.js', v='manual-release-20261014') + '" defer></script>'
            response.set_data(html.replace('</body>', script + '</body>') if '</body>' in html else html + script)
    return response


def transaction_from_form(ro_values=None):
    d = {key: request.form.get(key,'').strip() for key in FIELDS}
    stored = dict(ro_values or {})
    manage_ro = can_manage_ro()
    if not manage_ro:
        # Read-only means the server also preserves every RO-managed field.
        for key in RO_LOCKED_FIELDS:
            value = stored.get(key)
            d[key] = '' if value is None else str(value)
        d['action'] = stored.get('action') or ''
    elif not d['action'] and stored.get('action') in LEGACY_ACTIONS:
        d['action'] = stored['action']  # Preserve a historical removed action on an unrelated edit.
    d['received_ro_by'] = stored.get('received_ro_by') or ''
    apply_fo_processing(d, request.form, stored, bool(fo_office()), local_today().isoformat())
    apply_ro_processing(d, request.form, stored, manage_ro, local_today().isoformat())
    apply_action_rules(d, request.form, stored, bool(fo_office()), manage_ro, local_today().isoformat())
    for field in ('first_processor','second_processor'):
        d[field] = canonical_processor(d[field])
    for key in ('category','received_on','applicant'):
        if not d[key]: raise ValueError(f'Required: {key}')
    if d['category'] not in CATEGORIES or (d['action'] not in ACTIONS and not (stored.get('action') == d['action'] and d['action'] in LEGACY_ACTIONS)):
        raise ValueError('Invalid category or action.')
    if d['source'] not in OFFICE_SOURCES:
        raise ValueError('Choose Office/Source from the dropdown.')
    if d['category'] == 'CSE-PR' and d['subtype'] == 'CSE-PR':
        d['subtype'] = ''
    allowed = SUBTYPES[d['category']]
    if allowed and d['subtype'] not in allowed and not (d['category']=='CSE-PR' and not d['subtype']):
        raise ValueError('Choose a valid subtype for the selected category.')
    if not allowed:
        d['subtype'] = ''
    # For Other, the eligibility and subtype describe the same workbook choice.
    if d['category'] == 'Other':
        d['eligibility'] = d['subtype']
    try:
        d['quantity'] = int(d['quantity'] or '1')
    except ValueError:
        raise ValueError('Number of applications must be a positive whole number.')
    if d['quantity'] < 1 or (d['category'] != 'HGE' and d['quantity'] != 1):
        raise ValueError('Only HGE batch records may have more than one application.')
    for flag in ('released_fo_na', 'received_back_na'):
        d[flag] = 1 if d[flag] == '1' else 0
    if d['copi_promulgated_on']:
        try:
            d['copi_promulgated_on'] = date.fromisoformat(d['copi_promulgated_on']).isoformat()
        except ValueError:
            raise ValueError('Enter a valid Date of Promulgation of COPI Resolution.')
    else:
        d['copi_promulgated_on'] = None
    apply_client_release_choice(d, request.form)
    validate_transaction_dates(d)
    validate_client_release(d)
    if d['action'] != 'Pending':
        d['pending_status'] = ''
    if d['action'] == 'Pending':
        if d['pending_status'] not in ('', 'For Compliance', 'For COPI'):
            raise ValueError('Choose For Compliance or For COPI.')
        if d['pending_status'] == 'For COPI' and not d['copi_reason']:
            raise ValueError('Enter the reason for COPI.')
    if d['action'] == 'Pending' and d['pending_status'] == 'For Compliance' and not d['compliance_comment'] and manage_ro:
        raise ValueError('Enter the required compliance in the comment window.')
    return d


# ========================================================================
# BAHAGI: review_form_data
# Ihanda ang review form mula sa orihinal na Excel columns ayon sa source sheet.
# I-normalize ang values; hindi hinuhulaan ang petsa kapag hindi ito mabasa.
# ========================================================================
def review_form_data(review):
    """Use original imported columns; never infer dates for a review form."""
    raw = json.loads(review['raw_json'])
    def value(i):
        return '' if i >= len(raw) or raw[i] is None else str(raw[i]).strip()
    category = {'Others 2026':'Other', 'CSE PR 2026':'CSE-PR', 'Honor Grad 2026':'HGE'}.get(review['sheet'])
    if not category:
        raise ValueError('Unsupported source sheet. Review the original Excel row.')
    d = {key:'' for key in FIELDS}
    d.update(category=category, quantity=1, released_fo_na=0, received_back_na=0)
    if category == 'HGE':
        indices = {'received_on':1, 'quantity':2, 'source':4, 'eligibility':7,
                   'applicant':8, 'first_processor':9, 'first_date':10,
                   'second_processor':11, 'acted_on':12, 'action':13,
                   'released_fo_on':14, 'released_client_on':15, 'received_back_on':16,
                   'remarks':17}
        ref_from, ref_to = value(5), value(6)
    else:
        indices = {'received_on':0, 'source':2, 'eligibility':6,
                   'applicant':4 if category=='CSE-PR' else 5,
                   'first_processor':7, 'first_date':8, 'second_processor':9,
                   'acted_on':10, 'action':11, 'released_fo_on':12,
                   'received_back_on':13, 'released_client_on':14, 'remarks':15}
        ref_from, ref_to = value(3), value(4) if category=='Other' else value(3)
    for key, idx in indices.items():
        d[key] = value(idx)
    original = {key:d[key] for key in ('source', 'received_on', 'acted_on', 'action')}
    if category == 'HGE':
        d['applicant'] = d['applicant'] or ('Batch: '+value(3) if value(3) else '')
        try:
            q = float(d['quantity'])
            d['quantity'] = int(q) if q.is_integer() and q>0 else ''
        except ValueError:
            d['quantity'] = ''
    d['subtype'] = ({'JOCOSC6':'JOCOSC6','MUP':'MUP'}.get(value(1),'') if category=='CSE-PR'
                    else d['eligibility'] if category=='Other' else '')
    d['source'] = {'WI':'Walk-In','Isa':'ISAFO','NV':'NVFO','Qno':'QFO','Bat':'BATFO'}.get(d['source'],d['source'])
    imported_compliance = d['action'].strip().lower() == 'for compliance'
    d['action'] = {a.lower():a for a in ACTIONS if a}.get(d['action'].lower(), 'Pending' if not d['action'] else '')
    if imported_compliance:
        d['action'], d['pending_status'] = 'Pending', 'For Compliance'
    for key, flag in (('released_fo_on','released_fo_na'),('received_back_on','received_back_na')):
        d[flag] = int(d[key].upper() in ('N/A','NA'))
    for key in DATE_FIELDS:
        try:
            # Original archive stores Excel datetimes as ISO date + time.
            d[key] = datetime.fromisoformat(d[key]).date().isoformat() if d[key] else ''
        except ValueError:
            d[key] = ''
    d['second_date'] = d.get('acted_on') or ''
    d['reference'] = f"XL-{category}-{ref_from or 'ROW'}-{ref_to or 'ROW'}-R{review['row_number']}"
    for field in ('first_processor','second_processor'):
        d[field] = canonical_processor(d[field])
    return d, original


# ========================================================================
# BAHAGI: review_list
# Buksan ang Priority page, na kasama rin ang mga imported record na For Review.
# ========================================================================
@app.get('/review')
@login_required
def review_list():
    return priority()


# ========================================================================
# BAHAGI: review_content
# Kunin ang For Review records at huling 20 na naresolbang import.
# ========================================================================
def review_content():
    with conn() as db:
        rows = scoped_select(db, 'SELECT * FROM import_review ORDER BY sheet,row_number').fetchall()
        recent = scoped_select(db, 'SELECT source_key,username,transaction_id,resolved_at FROM import_resolutions ORDER BY id DESC LIMIT 20').fetchall()
    items = []
    for row in rows:
        d, original = review_form_data(row)
        items.append(dict(row, applicant=d['applicant'], original=original))
    return items, recent


# ========================================================================
# BAHAGI: review_edit
# Payagan ang pagwawasto at pag-save ng isang imported record.
# Suriin ang source digest, import history, at duplicate bago gumawa ng transaction.
# Itala ang orihinal/corrected values at alisin sa review pagkatapos ma-save.
# ========================================================================
@app.route('/review/<path:source_key>', methods=['GET','POST'])
@login_required
def review_edit(source_key):
    with conn() as db:
        review = scoped_select(db, 'SELECT * FROM import_review WHERE source_key=?',(source_key,)).fetchone()
        history = scoped_select(db, 'SELECT transaction_id FROM import_history WHERE source_key=?',(source_key,)).fetchone()
    if review is None:
        flash('This record is no longer awaiting review. Another user may have already saved it.')
        return redirect(url_for('review_list'))
    initial, original = review_form_data(review)
    digest = hashlib.sha256(review['raw_json'].encode()).hexdigest()
    if history:
        # Conflicting imports must never create another transaction for an existing source row.
        return render_template('review_conflict.html', review=review, original=original,
                               transaction_id=history['transaction_id']), 409
    if request.method == 'POST':
        try:
            d = transaction_from_form(initial)
            if d['category'] != 'Other':
                d['eligibility'] = initial.get('eligibility', '')
            if request.form.get('_source_digest') != digest:
                raise ValueError('The source record has changed. Reopen the review before saving.')
            with conn() as db:
                db.execute('BEGIN IMMEDIATE')
                current = scoped_select(db, 'SELECT raw_json FROM import_review WHERE source_key=?',(source_key,)).fetchone()
                if not current or hashlib.sha256(current['raw_json'].encode()).hexdigest()!=digest:
                    raise ValueError('This record has already been saved or changed. Return to Records needing review.')
                if scoped_select(db, 'SELECT 1 FROM import_history WHERE source_key=?',(source_key,)).fetchone():
                    raise ValueError('This source record was already imported. No duplicate was created.')
                d['reference'] = assign_reference(db, d)
                duplicate = scoped_select(db, "SELECT id FROM transactions WHERE reference=? OR (applicant=? AND received_on=? AND category=? AND source=? AND ? NOT LIKE 'Batch: %')",
                    (d['reference'],d['applicant'],d['received_on'],d['category'],d['source'],d['applicant'])).fetchone()
                if duplicate:
                    raise ValueError(f"A matching transaction exists (ID {duplicate['id']}). Check Transactions before continuing.")
                cursor = db.execute('INSERT INTO transactions ('+','.join(FIELDS)+') VALUES ('+','.join('?' for _ in FIELDS)+')',tuple(d[key] for key in FIELDS))
                ident = cursor.lastrowid
                db.execute('INSERT INTO import_history VALUES (?,?,?)',(source_key,digest,ident))
                db.execute('INSERT INTO import_resolutions(source_key,raw_json,corrected_json,username,transaction_id) VALUES (?,?,?,?,?)',
                           (source_key,review['raw_json'],json.dumps(d,ensure_ascii=False),session['username'],ident))
                db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',(ident,session['username'],'resolved Excel review: '+source_key))
                db.execute('DELETE FROM import_review WHERE source_key=?',(source_key,))
            flash('Corrected record saved. Reports now include it using the dates and status you entered.')
            return redirect(url_for('review_list'))
        except (ValueError,sqlite3.IntegrityError) as exc:
            flash(str(exc))
    return render_template('form.html',row=request.form if request.method=='POST' else initial,
                           editing=False,review=review,original=original,source_digest=digest)


# ========================================================================
# BAHAGI: new_transaction
# Gumawa ng bagong transaction matapos ang validation at reference assignment.
# BEGIN IMMEDIATE ang ginagamit sa pagsulat para maayos ang reservation ng numero; may audit entry.
# ========================================================================
@app.route('/transactions/new', methods=['GET','POST'])
@login_required
def new_transaction():
    if request.method == 'POST':
        try:
            d = transaction_from_form()
            with conn() as db:
                db.execute('BEGIN IMMEDIATE')
                d['reference'] = assign_reference(db, d)
                db.execute('INSERT INTO transactions ('+','.join(FIELDS)+') VALUES ('+','.join('?' for _ in FIELDS)+')', tuple(d.values()))
                ident = db.execute('SELECT last_insert_rowid()').fetchone()[0]
                db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',(ident,session['username'],'Created: '+json.dumps({'reference':d['reference'],'action':d['action']},ensure_ascii=False)))
                if fo_office() and 'fo_action' in request.form:
                    db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',
                        (ident, session['username'], 'FO processing: ' + json.dumps(fo_processing_audit(d), ensure_ascii=False)))
                if not fo_office() and d.get('ro_transmitted_fo'):
                    db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',
                        (ident, session['username'], 'RO processing: ' + json.dumps(ro_processing_audit(d), ensure_ascii=False)))
            flash('Transaction saved. Continue editing or select Back.')
            return redirect(url_for('edit_transaction', ident=ident))
        except (ValueError,sqlite3.IntegrityError) as exc:
            flash(str(exc))
    return render_template('form.html', row=request.form if request.method=='POST' else {'source':fo_office() or '', 'action':'', 'fo_action':''}, editing=False)


# ========================================================================
# BAHAGI: edit_transaction
# I-update ang napiling transaction matapos ang validation.
# Kapag nagbago ang reference, itala ang luma at bago; itala rin ang update sa audit.
# ========================================================================
@app.route('/transactions/<int:ident>/edit', methods=['GET','POST'])
@login_required
def edit_transaction(ident):
    with conn() as db:
        row = scoped_select(db, 'SELECT * FROM transactions WHERE id=?',(ident,)).fetchone()
    if not row: abort(404)
    if request.method == 'POST':
        try:
            d = transaction_from_form(row)
            with conn() as db:
                db.execute('BEGIN IMMEDIATE')
                current = scoped_select(db, 'SELECT * FROM transactions WHERE id=?', (ident,)).fetchone()
                if current is None:
                    abort(404)
                if any(current[key] != row[key] for key in RO_LOCKED_FIELDS):
                    abort(409, 'RO updated this record. Reload the form before saving.')
                if not fo_office() and '_ro_version' in request.form and request.form['_ro_version'] != ro_form_version(dict(current)):
                    abort(409, 'RO updated this record. Reload the form before saving.')
                if fo_office() and 'fo_action' in request.form and any(current[key] != row[key] for key in ('first_date', *FO_FIELDS)):
                    abort(409, 'FO processing was updated. Reload the form before saving.')
                # RO edits keep the latest FO values even if another FO user saved meanwhile.
                if not fo_office():
                    for key in FO_FIELDS:
                        d[key] = current[key]
                if d['category'] != 'Other':
                    d['eligibility'] = current['eligibility']
                if is_admin():
                    reference = request.form.get('reference', '').strip()
                    if not reference or len(reference) > 120 or any(ord(ch) < 32 for ch in reference):
                        raise ValueError('Enter a reference number of 1–120 characters.')
                    if scoped_select(db, 'SELECT 1 FROM transactions WHERE id<>? AND lower(trim(reference))=lower(?)', (ident,reference)).fetchone():
                        raise ValueError('Reference number already exists. Choose a unique reference.')
                    d['reference'] = reference
                else:
                    d['reference'] = assign_reference(db, d, current)
                if d['reference'] != current['reference']:
                    db.execute('INSERT INTO reference_changes(transaction_id,old_reference,new_reference) VALUES (?,?,?)', (ident,current['reference'],d['reference']))
                    db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)', (ident,session['username'],'Reference changed: '+current['reference']+' -> '+d['reference']))
                db.execute('UPDATE transactions SET '+','.join(f'{k}=?' for k in FIELDS)+',updated_at=CURRENT_TIMESTAMP WHERE id=?',(*d.values(),ident))
                db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',(ident,session['username'],'Changes: '+json.dumps({key:{'before':current[key],'after':d[key]} for key in FIELDS if str(current[key] or '') != str(d[key] or '')},ensure_ascii=False)))
                if fo_office() and fo_processing_audit(d) != fo_processing_audit(dict(current)):
                    db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',
                        (ident, session['username'], 'FO processing: ' + json.dumps(fo_processing_audit(d), ensure_ascii=False)))
                if not fo_office() and ro_processing_audit(d) != ro_processing_audit(dict(current)):
                    db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',
                        (ident, session['username'], 'RO processing: ' + json.dumps(ro_processing_audit(d), ensure_ascii=False)))
            flash('Changes saved. Continue editing or select Back.')
            return redirect(url_for('edit_transaction', ident=ident))
        except (ValueError,sqlite3.IntegrityError) as exc:
            flash(str(exc))
    with conn() as db:
        holidays = {r['day'] for r in db.execute('SELECT day FROM holidays')}
    display = dict(row)
    if request.method == 'POST':
        display.update(request.form.to_dict())
    if not can_manage_ro():
        display.update({key: row[key] for key in RO_LOCKED_FIELDS})
    with conn() as db:
        copi_history = load_pauses(db, [dict(row)]).get(ident, [])
    copi_clock = enriched([row], holidays, local_today().isoformat())[0]
    return render_template('form.html',row=display,editing=True,ident=ident, ro_version=ro_form_version(dict(row)), chief_review_available=chief_review_eligible(row, holidays, local_today().isoformat()), copi_history=copi_history, copi_clock=copi_clock)


def ro_form_version(row):
    return hashlib.sha256(json.dumps(ro_processing_audit(row), sort_keys=True).encode()).hexdigest()


# ========================================================================
# BAHAGI: delete_transaction
# Burahin ang transaction na tinukoy ng ID at magtala ng delete event sa audit.
# ========================================================================
@app.post('/transactions/<int:ident>/delete')
@login_required
def delete_transaction(ident):
    # Hindi puwedeng mag-delete ang Field Office accounts.
    # Server-side guard ito para hindi ma-bypass kahit baguhin ang form o URL.
    if fo_office():
        abort(403, 'Field Office accounts are not allowed to delete transactions.')
    with conn() as db:
        row = scoped_select(db, 'SELECT reference FROM transactions WHERE id=?', (ident,)).fetchone()
        if row is None:
            abort(404)
        if request.form.get('confirm_reference', '') != row['reference']:
            flash('Record was not deleted. Type the exact reference number to confirm.')
            return redirect(url_for('edit_transaction', ident=ident))
        db.execute('DELETE FROM transactions WHERE id=?',(ident,))
        db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',(ident,session['username'],'Deleted: '+row['reference']))
    flash('Transaction deleted.')
    return redirect(url_for('transactions'))


# ========================================================================
# BAHAGI: holidays_page
# Magdagdag o mag-update ng holiday at ipakita ang listahan at buwanang bilang.
# Ginagamit ang mga petsang ito sa susunod na working-day computation.
# ========================================================================
@app.route('/holidays',methods=['GET','POST'])
@login_required
def holidays_page():
    if request.method == 'POST':
        try:
            day = parse_day(request.form.get('day'),True)
            label = request.form.get('label','').strip()
            if not label: raise ValueError('Enter holiday name.')
            with conn() as db:
                db.execute('INSERT INTO holidays(day,label) VALUES (?,?) ON CONFLICT(day) DO UPDATE SET label=excluded.label',(day,label))
            flash('Holiday saved. Working-day counts have been updated.')
            return redirect(url_for('holidays_page'))
        except ValueError as exc: flash(str(exc))
    with conn() as db:
        rows = db.execute('SELECT * FROM holidays ORDER BY day DESC').fetchall()
    summary = {}
    for r in rows: summary[r['day'][:7]] = summary.get(r['day'][:7],0)+1
    return render_template('holidays.html',rows=rows,summary=summary)


# ========================================================================
# BAHAGI: delete_holiday
# Burahin ang holiday upang maisama muli ang petsa sa susunod na working-day computation.
# ========================================================================
@app.post('/holidays/<day>/delete')
@login_required
def delete_holiday(day):
    # FO accounts ay hindi rin puwedeng mag-delete ng holidays.
    if fo_office():
        abort(403, 'Field Office accounts are not allowed to delete holidays.')
    with conn() as db:
        db.execute('DELETE FROM holidays WHERE day=?',(day,))
    flash('Holiday deleted. Dashboard counts have been updated.')
    return redirect(url_for('holidays_page'))


# ========================================================================
# BAHAGI: export_csv
# I-export ang transactions, computed days/status, actual days, Chief decision, at COPI date.
# Isulat bilang N/A ang FO dates na may kaukulang N/A flag.
# ========================================================================
@app.get('/export')
@login_required
def export_page():
    with conn() as db:
        years = available_years(db, local_today().year)
    return render_template('export.html', years=years, selected=local_today().year)


@app.get('/export.csv')
@login_required
def export_csv():
    raw_year = request.args.get('year', '').strip()
    year = report_year(raw_year) if raw_year else None
    with conn() as db:
        rows = scoped_select(db, 'SELECT * FROM transactions WHERE reporting_year=? ORDER BY received_on,id', (year,)).fetchall() if year else scoped_select(db, 'SELECT * FROM transactions ORDER BY received_on,id').fetchall()
        holidays = {r['day'] for r in db.execute('SELECT day FROM holidays')}
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(['reporting_year',*FIELDS,'action_days','computed_status','actual_working_days','approved_exception_applied','exception_status','chief_remarks','chief_username','decision_at','copi_tagged_at','reckoning_date','reckoning_applied','copi_paused_working_days','active_working_days','copi_counting_paused','copi_paused_since','copi_resumed_on'])
    for r in enriched(rows,holidays,local_today().isoformat()):
        writer.writerow([r['reporting_year'],*('N/A' if (k=='released_fo_on' and r['released_fo_na']) or (k=='received_back_on' and r['received_back_na']) else r[k] for k in FIELDS),r['days'],r['state'],r['actual_days'],r['exception_applied'],r.get('exception_status'),r.get('exception_remarks'),r.get('exception_by'),r.get('exception_at'),r.get('copi_tagged_at'),r.get('reckoning_on'),r['reckoning_applied'],r['copi_pause_days'],r['active_days'],r['copi_paused'],r['copi_hold_since'],r['copi_resumed_on']])
    return Response('\ufeff'+out.getvalue(),mimetype='text/csv',headers={'Content-Disposition':f'attachment; filename=etracker-export-{year or "all-years"}.csv'})


# MGA IPMR LABEL: pamagat ng bawat indicator sa template/report.
IPMR_LABELS = ['5. Efficiency Rate in the Grant of Eligibility under Special Laws and CSC Issuances (SLCI)', '5.1. Total Acted Applications', '5.1.1. Total Acted Applications within 20 working days from receipt', '5.1.2. Total Acted Applications beyond 20 working days from receipt', '5.2. Total number of applications received', '5.2.1. Number of applications received for the month', '5.2.2. Beginning balance', '5a. Efficiency Rate in the Grant of Eligibility under SLCI (Applications received in the current year)', '5a.1. Total Acted Applications', '5a.1.1. Number of applications acted upon within 20 working days from receipt', '5a.1.2. Number of applications acted upon beyond 20 working days from receipt', '5a.2. Total number of applications received for the month', '5a.2.1. Number of applications received for the month', '5a.2.2. Number of applications pending from previous month', '5b. Efficiency Rate in the Grant of Eligibility under SLCI (Applications received from the previous year)', '5b.1. Total Acted Applications', '5b.1.1. Number of applications acted upon within 20 working days from receipt', '5b.1.2. Number of applications acted upon beyond 20 working days from receipt', '5b.2. Total number of applications unacted as of December 31, 2025', '6. Number of slots made available for examinees of various Civil Service Eligibility Examinations', '6.1. CSE Professional Level via PPT', '6.2. CSE Subprofessional Level via PPT', '6.3. CSE Professional Level via COMEX', '6.4. CSE Subprofessional Level via COMEX', '6.5. Fire Officer Examination', '6.6. Penology Officer Examination', '6.7. CSE for Foreign Service Officer']

# MGA EXAM: internal keys para sa manual na Section 6 slots.
EXAM_KEYS = ('cse_prof_ppt','cse_subprof_ppt','cse_prof_comex','cse_subprof_comex','foe','poe','fso')


# ========================================================================
# BAHAGI: ipmr_template_report
# I-map ang database reports sa IPMR indicators 5, 5a, at 5b.
# Ihiwalay ang current-year receipts at receipts bago ang napiling taon.
# Ang Section 6 exam slots ay kinukuha mula sa manual na ipmr_slots entries.
# ========================================================================
def ipmr_template_report(year):
    raw_month = request.args.get('as_of_month', '12') if request else '12'
    try:
        as_of_month = int(raw_month)
        if not 1 <= as_of_month <= 12:
            raise ValueError()
    except (TypeError, ValueError):
        abort(400, 'Invalid As of Month')
    data = ipmr_report(year, as_of_month)
    reports = data['reports']
    output = []
    format_path = BASE / 'ipmr-format.json'
    source_format = json.loads(format_path.read_text(encoding='utf-8')) if format_path.exists() else []
    def add(index, values, annual, rate=False, definition=''):
        label = IPMR_LABELS[index]
        po = 'ERPO' if index in (0,14,19) else ''
        if index < len(source_format):
            label = source_format[index]['label']
            definition = source_format[index]['definition']
            po = source_format[index]['po']
        if index == 18:
            label = f'5b.2. Total number of applications unacted as of December 31, {year-1}'
        output.append(dict(label=label, values=values, annual=annual, rate=rate,
                           definition=definition, po=po,
                           heading=index in (0,7,14,19), exam=None))
    legacy = legacy_ipmr_balances(year)
    def cohort(which):
        def included(r):
            return which == 'all' or (r['reporting_year'] == year if which == 'current' else r['reporting_year'] < year)
        def counts(key, timely=None):
            return [sum(r['quantity'] for r in report[key] if included(r) and
                        (timely is None or (r['days'] <= 20) == timely)) for report in reports]
        opening=counts('opening'); received=counts('received'); acted=counts('acted')
        within=counts('acted',True); beyond=counts('acted',False)
        if which in ('all', 'prior'):
            for balance in legacy:
                opening[0] += balance['opening_quantity']
                index = balance['acted_month']-1
                if balance['acted_month'] <= as_of_month:
                    acted[index] += balance['within_quantity'] + balance['beyond_quantity']
                    within[index] += balance['within_quantity']
                    beyond[index] += balance['beyond_quantity']
        # Match the reference Excel carryover formulas using database counts.
        # Only January's opening comes from the initial balance. Later openings
        # are the previous month's available applications less its final decisions.
        for index in range(1, 12):
            opening[index] = opening[index-1] + received[index-1] - acted[index-1]
        denominator=[a+b for a,b in zip(opening,received)]
        annual_denominator=opening[0]+sum(received)
        rates=[100*w/d if d else 0 for w,d in zip(within,denominator)]
        for index in range(12):
            if reports[index]['future']:
                opening[index] = denominator[index] = 0
                rates[index] = 0
        rate=100*sum(within)/annual_denominator if annual_denominator else 0
        return opening,received,acted,within,beyond,denominator,annual_denominator,rates,rate
    for which, offset in [('all',0),('current',7),('prior',14)]:
        opening,received,acted,within,beyond,denom,annual_d,rates,rate=cohort(which)
        add(offset,rates,rate,True,'Applications acted upon within 20 working days ÷ available applications × 100.')
        add(offset+1,acted,sum(acted),definition='Acted applications: Approved or Disapproved.')
        add(offset+2,within,sum(within))
        add(offset+3,beyond,sum(beyond))
        add(offset+4,denom,annual_d,definition='Beginning pending balance + new receipts.' if which!='prior' else 'Unresolved applications received before the selected year; remaining balance at each month’s start.')
        if which!='prior':
            add(offset+5,received,sum(received))
            add(offset+6,opening,opening[0],definition='Annual beginning balance is counted once, at January 1.')
    with conn() as db:
        slots={(r['exam'],r['month']):r['slots'] for r in db.execute('SELECT * FROM ipmr_slots WHERE year=?',(year,))}
    totals=[sum(slots.get((exam,m),0) for exam in EXAM_KEYS) for m in range(1,13)]
    add(19,totals,sum(totals[:as_of_month]),definition='Maximum exam capacity: greater of initially allocated slots or approved applications by the filing deadline.')
    for index,exam in enumerate(EXAM_KEYS,20):
        values=[slots.get((exam,m),0) for m in range(1,13)]
        add(index,values,sum(values[:as_of_month])); output[-1]['exam']=exam
    data.update(template_rows=output,months=[calendar.month_name[m].upper() for m in range(1,13)],
                cutoff=min(local_today(),date(year,as_of_month,calendar.monthrange(year,as_of_month)[1])).isoformat(),
                as_of_month=as_of_month, as_of_label=calendar.month_name[as_of_month])
    return data


# ========================================================================
# BAHAGI: save_ipmr_slots
# I-validate at i-save ang manual Section 6 slots para sa bawat exam at buwan.
# Non-negative whole numbers lamang; itala ang nag-update at oras.
# ========================================================================
@app.post('/ipmr/slots')
@login_required
def save_ipmr_slots():
    year=report_year(request.form.get('year'))
    values=[]
    for exam in EXAM_KEYS:
        for month in range(1,13):
            raw=request.form.get(f'slots_{exam}_{month}','').strip()
            if not raw.isascii() or not raw.isdecimal() or len(raw)>9:
                abort(400,'Enter a non-negative whole number for every exam slot cell (0 if none).')
            values.append((year,month,exam,int(raw),session['username']))
    with conn() as db:
        db.executemany("""INSERT INTO ipmr_slots(year,month,exam,slots,updated_by) VALUES (?,?,?,?,?)
            ON CONFLICT(year,month,exam) DO UPDATE SET slots=excluded.slots,
            updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP""",values)
    flash(f'Section 6 slots for {year} saved.')
    return redirect(url_for('ipmr',year=year,as_of_month=request.form.get('as_of_month','12')))



# APPROVAL PASSWORD HASH: ito ang ginagamit sa pag-verify ng Chief approval password.
CHIEF_APPROVAL_PASSWORD_HASH = 'scrypt:32768:8:1$e8rWq34NmwvaIvVl$c6ee57927a729cec0ed3f72830e8c3c77f5d21717fc52e919f93ac2d9f0d86f8a550e92324b00441de44919cddeb44a24cf04a45960a1f989d0c5603d43f5f05'

# ========================================================================
# BAHAGI: exception_fingerprint
# Gumawa ng SHA-256 fingerprint ng FIELDS upang makita kung nagbago ang record.
# ========================================================================
def exception_fingerprint(row):
    # Any substantive record edit requires a fresh decision.
    return hashlib.sha256(json.dumps({k: row[k] for k in FIELDS if k not in FO_FIELDS + RO_FIELDS},
        sort_keys=True, ensure_ascii=False).encode()).hexdigest()


# ========================================================================
# BAHAGI: is_chief
# Suriin sa users table kung chief ang role ng kasalukuyang naka-login.
# ========================================================================
def can_manage_ro():
    return bool(not fo_office() and is_admin())


def is_admin():
    with conn() as db:
        user = db.execute('SELECT role FROM users WHERE username=?', (session.get('username',''),)).fetchone()
    return bool(user and (user['role'] == 'admin' or session.get('username','').casefold() == 'admin'))


def is_chief():
    with conn() as db:
        user = db.execute('SELECT role FROM users WHERE username=?',
                          (session.get('username',''),)).fetchone()
    return bool(user and user['role'] == 'chief' and session.get('username','').casefold() == 'ajvtb')


# ========================================================================
# BAHAGI: copi
# Ipakita ang records na Pending at For COPI, kasama ang petsa ng pag-tag.
# ========================================================================
@app.get('/copi')
@login_required
def copi():
    with conn() as db:
        rows = scoped_select(db, "SELECT * FROM transactions WHERE action='Pending' AND pending_status='For COPI' ORDER BY copi_tagged_at DESC,id DESC").fetchall()
    return redirect(url_for('priority', _anchor='copi-section'))


# ========================================================================
# BAHAGI: exception_review
# Ipakita ang record at decision history; sa POST, suriin ang Chief role at approval password.
# Only completed final decisions beyond 20 actual days qualify for Chief review.
# Suriin kung hindi nagbago ang record, actual days, o nakaraang decision bago mag-save.
# Save the reckoning date, fingerprint, actual days, timestamp and audit.
# Retain original dates; reports count working days from the saved reckoning date.
# ========================================================================
@app.route('/transactions/<int:ident>/exception', methods=['GET','POST'])
@login_required
def exception_review(ident):
    with conn() as db:
        if request.method == 'POST':
            db.execute('BEGIN IMMEDIATE')
        row = scoped_select(db, 'SELECT * FROM transactions WHERE id=?',(ident,)).fetchone()
        if not row:
            abort(404)
        holidays = {r['day'] for r in db.execute('SELECT day FROM holidays')}
        item = enriched([row], holidays, local_today().isoformat())[0]
        if not chief_review_eligible(row, holidays, local_today().isoformat()):
            abort(403, 'Chief review is available only for completed Approved or Disapproved transactions beyond 20 working days.')
        fingerprint = exception_fingerprint(row)
        if request.method == 'POST':
            if not is_chief():
                abort(403, 'Only a Division Chief account may decide an exception.')
            if not check_password_hash(CHIEF_APPROVAL_PASSWORD_HASH, request.form.get('approval_password', '')):
                abort(403, 'Incorrect Division Chief approval password. Go back and try again.')
            decision = 'reckoning'
            remarks = request.form.get('chief_remarks','').strip()
            if not remarks:
                abort(400, 'Enter the Division Chief remarks.')
            reckoning = request.form.get('reckoning_on', '')
            try:
                if date.fromisoformat(reckoning).isoformat() != reckoning:
                    raise ValueError()
            except ValueError:
                abort(400, 'Enter a valid reckoning date in YYYY-MM-DD format.')
            end = row['acted_on'] if row['action'] in FINAL_ACTIONS and row['acted_on'] else local_today().isoformat()
            end = min(end, local_today().isoformat())
            if not row['received_on'] <= reckoning <= end:
                abort(400, 'Reckoning date must be on or after receipt and no later than today or final action date.')
            if item['actual_days'] <= 20:
                abort(400, 'Only records with actual working days beyond 20 qualify.')
            if request.form.get('fingerprint') != fingerprint or request.form.get('actual_days') != str(item['actual_days']) or request.form.get('previous_decision','') != (row['exception_at'] or ''):
                abort(409, 'Record, holidays or decision changed. Reload before deciding.')
            timestamp = datetime.now(ZoneInfo('Asia/Manila')).isoformat(timespec='microseconds')
            db.execute('UPDATE transactions SET exception_status=?,exception_remarks=?,exception_by=?,exception_at=?,exception_fingerprint=?,exception_actual_days=?,reckoning_on=? WHERE id=?',
                       (decision,remarks,session['username'],timestamp,fingerprint,item['actual_days'],reckoning,ident))
            db.execute('INSERT INTO exception_decisions(transaction_id,decision,remarks,username,actual_days,fingerprint,decided_at,reckoning_on) VALUES (?,?,?,?,?,?,?,?)',
                       (ident,decision,remarks,session['username'],item['actual_days'],fingerprint,timestamp,reckoning))
            db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',
                       (ident,session['username'],'Reckoning date set to '+reckoning+': '+remarks))
        history = scoped_select(db, 'SELECT * FROM exception_decisions WHERE transaction_id=? ORDER BY id DESC',(ident,)).fetchall()
    if request.method == 'POST':
        flash('Reckoning date saved. Working days now count from the new date; original dates and actual elapsed days are retained.')
        return redirect(url_for('exception_review', ident=ident))
    return render_template('exception_review.html', r=item, history=history, fingerprint=fingerprint, reckoning_max=min(local_today().isoformat(), row['acted_on']) if row['action'] in FINAL_ACTIONS and row['acted_on'] else local_today().isoformat())

# PAGSISIMULA: tiyaking may secret key, ihanda ang database, at patakbuhin ang Flask server.
# Host/port ay mula sa environment; default ay 127.0.0.1:5000 at debug=False.

@app.context_processor
def window_navigation():
    endpoint=request.endpoint or ''
    args=request.view_args or {}
    if endpoint=='system_selector' or not session.get('username'):
        return {'window_close_url':None}
    if endpoint == 'receiver_release':
        target = url_for('receiver_dashboard', system=args.get('system', 'spels'), view='for_release')
    elif endpoint == 'receiver_dashboard':
        target = url_for('system_selector')
    elif endpoint in ('role_record', 'role_new'):
        target = url_for('role_work', system=args.get('system', 'spels'))
    elif endpoint in ('role_work', 'role_password'):
        target = url_for('system_selector')
    elif endpoint in ('new_transaction','edit_transaction'):
        target=url_for('transactions')
    elif endpoint=='coe_form':
        target=url_for('coe_transactions')
    elif endpoint=='exception_review':
        target=url_for('edit_transaction',ident=args['ident'])
    elif endpoint=='fo_return_detail':
        target=url_for('fo_receipt_records',system='spels')
    elif endpoint=='review_edit':
        target=url_for('review_list')
    elif endpoint=='unassigned_processors':
        target=url_for('processors_report')
    elif endpoint in ('dashboard','coe_dashboard'):
        target=url_for('system_selector')
    elif endpoint.startswith('coe_') or args.get('system')=='coe':
        target=url_for('coe_dashboard')
    else:
        filters={key:request.args[key] for key in ('scope','year','month','day') if key in request.args}
        target=url_for('dashboard',**filters)
    return {'window_close_url':target}


@app.get('/systems')
@login_required
def system_selector():
    return render_template('systems.html')

@app.get('/processors/unassigned')
@login_required
def unassigned_processors():
    year = request.args.get('year','')
    month = request.args.get('processed_month','')
    if month and (not month.isdigit() or not 1 <= int(month) <= 12): abort(400)
    with conn() as db:
        records = scoped_select(db, 'SELECT * FROM transactions ORDER BY received_on DESC,id DESC').fetchall()
    rows=[]
    for r in records:
        fields=[field for field,day in [('first_processor','first_date'),('second_processor','second_date')] if not month or (r[day] and r[day]<=local_today().isoformat() and int(r[day][5:7])==int(month))]
        if fields and not any(canonical_processor(r[field]) for field in fields): rows.append(r)
    if year:
        chosen = report_year(year)
        rows = [r for r in rows if r['reporting_year']==chosen]
    return render_record_list('unassigned.html',rows=rows)

from coe_monitor import register_coe
register_coe(app, BASE, login_required)

from year_management import register_year_management
register_year_management(app, conn, login_required)

from fo_access import register_fo_access
register_fo_access(app, DB, login_required, is_admin)

from ro_receipt_alerts import register_ro_receipt_alerts
register_ro_receipt_alerts(app, globals())
from fo_receipt_alerts import register_fo_receipt_alerts
register_fo_receipt_alerts(app, globals())

from admin_logs import register_admin_logs
register_admin_logs(app, globals())

from pending_list_display import register_pending_list_display
register_pending_list_display(app)

from ro_accounts import register_ro_accounts
register_ro_accounts(app, globals())

if __name__ == '__main__':
    if not app.secret_key:
        raise RuntimeError('Set ETRACKER_SECRET_KEY before starting.')
    init_db()
    app.run(host=os.getenv('ETRACKER_HOST','127.0.0.1'),port=int(os.getenv('ETRACKER_PORT','5000')),debug=False)
