# eTracker interface and workflow update

This update improves the shared interface, English labels, navigation, and workflow guidance. It keeps stored status values compatible with existing records.

## Install on your existing project

1. Stop eTracker.
2. Back up your entire current project folder, including both databases.
3. Extract `etracker-ui-update.zip` into your existing project folder. Replace the included source and template files. The update ZIP contains no databases, account credentials, or record exports.
4. Keep your existing `etracker.db`, `coe.db`, Python environment, and secret settings.
5. Start eTracker using your usual command. Refresh the browser to load the updated styles.

The update assumes the project from `etracker2026(New).zip`. Do not install individual files from this update against a different release.

## Development without changing original records

Run `python dev_server.py` from the project folder after installing requirements. It creates development database copies in `.dev-runtime` and retains a private session key there. Existing account passwords work with those copies. Repeated starts reuse the development copies; they do not refresh or sync with the original databases. Keep `.dev-runtime` private and exclude it from source archives.

To use the original databases in your existing installation, keep using `python app.py` with your existing environment settings.

## Clearer terminology

- Awaiting processing: received, but processing has not started.
- In progress: processing is underway.
- Awaiting compliance: requirements or corrections are outstanding.
- Verification stage: draft, submitted, returned, or verified. It is separate from the action taken.
- Total Acted Applications: approved or disapproved applications in the selected report period.
- Sent to an office: dispatch has been recorded; receipt is a separate confirmation.
- Released to client: actual client release has been recorded.

Workflow help appears in transaction and verification screens. FO means Field Office; RO means Regional Office. Official acronyms such as SPELS, COE, IPMR, and COPI remain available.

## Validation

Run `python -m unittest test_ui_flow -v` in a separate process. Four regression tests exercise login/logout and CSRF, transaction creation and reporting, role access and password validation, and compatibility of displayed labels with stored status values. Tests use fresh temporary databases.

Browser checks passed for desktop and mobile pages, menu interaction, and JavaScript execution. Existing-data copies rendered the dashboard, transactions, COE pages, priority, reports, review, and account screens successfully. These checks do not exhaust every office-specific verification and release transition.

## Files in this update

Application: app.py, ro_accounts.py, ui_labels.py, dev_server.py, test_ui_flow.py.
Interface: static/ui-refresh.css and the included templates.

No existing database migrations or report-counting policies were changed by this update. The original archive remains available separately.
