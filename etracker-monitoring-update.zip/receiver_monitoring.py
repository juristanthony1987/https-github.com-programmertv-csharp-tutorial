"""RO-wide monitoring and audited releasing for the designated receiving account."""
import calendar
import hashlib
import json
import re
from datetime import date

from flask import abort, flash, redirect, render_template, request, session, url_for
from workflow_actions import validate_client_release


def is_monitoring_receiver(account):
    return bool(account and account.get('enabled') and account.get('role') == 'receiver'
                and account.get('username', '').casefold() == 'edbermelad')


def record_version(row):
    return hashlib.sha256(json.dumps(dict(row), sort_keys=True, default=str).encode()).hexdigest()


def register_receiver_monitoring(app, main, current_account, connection, settings, stage):
    def authorized():
        account = current_account()
        if not is_monitoring_receiver(account):
            abort(403, 'This workspace is assigned to the receiving and releasing officer.')
        return account

    def received_at_ro(row):
        return row.get('received_ro_on') or (row.get('received_on') if row.get('source') == 'Walk-In' else '')

    def confirmed_action(row):
        if row.get('action') in (*main['FINAL_ACTIONS'], 'Released'):
            return row['action']
        if (row.get('verifier_state') == 'verified'
                and row.get('second_action') in main['FINAL_ACTIONS']
                and row.get('action') in ('', 'Received', 'On Process')):
            return row['second_action']
        return None

    def release_issue(row, system):
        """Use saved verification/action data; clients cannot select a decision."""
        if row.get('released_client_on'):
            return 'Already released to client.'
        if not received_at_ro(row):
            return 'Regional Office receipt must be recorded first.'
        if system == 'spels':
            if not confirmed_action(row):
                return 'An Approved or Disapproved action must be recorded before release.'
            try:
                validate_client_release({**row, 'released_client_on': main['local_today']().isoformat()})
            except ValueError as error:
                return str(error)
            if row.get('ro_transmitted_fo') == 'Yes' and not row.get('received_back_ro_on'):
                return 'The destination Field Office must confirm receipt first.'
        else:
            raw = row.get('status') or ''
            if raw in ('COPI', 'For COPI', 'For Compliance', 'To be transmitted to FO',
                       'To be transmitted to ESD-ROII', 'To Be Received by FO'):
                return 'Resolve the hold or office handoff before client release.'
            verified = (row.get('verifier_state') == 'verified'
                        and row.get('second_action') in main['FINAL_ACTIONS']
                        and row.get('second_verified_on'))
            if raw not in ('For Release', 'Released', 'Released to Client') and not verified:
                return 'Complete verification or mark the application Ready for release first.'
        return ''

    def action_label(row, system):
        if system == 'spels':
            return main['ACTION_LABELS'].get(row.get('action'), row.get('action') or 'Awaiting processing')
        from ui_labels import status_label
        return status_label(row.get('status'))

    def decorate(row, system):
        row = dict(row)
        issue = release_issue(row, system)
        row['_release_issue'] = issue
        row['_ready'] = not issue
        row['_released'] = bool(row.get('released_client_on'))
        row['_received_at_ro'] = received_at_ro(row)
        row['_action_label'] = action_label(row, system)
        row['_stage'] = stage(row, system)
        row['_acted'] = (row.get('action') in main['FINAL_ACTIONS']) if system == 'spels' else bool(
            row.get('verifier_state') == 'verified' or row.get('status') in ('For Release', 'Released', 'Released to Client'))
        row['_hold'] = (row.get('action') == 'Pending') if system == 'spels' else row.get('status') in ('Pending','COPI','For COPI','For Compliance')
        row['_in_progress'] = not row['_acted'] and not row['_hold'] and not row['_released']
        row['_quantity'] = row.get('quantity', 1) if system == 'spels' else 1
        return row

    def spels_performance_dashboard():
        today = main['local_today']()
        year = request.args.get('year', str(today.year))
        month = request.args.get('month', '')
        if year and (not re.fullmatch(r'\d{4}', year) or not 1900 <= int(year) <= 9998):
            abort(400, 'Choose a valid year.')
        if month and (not re.fullmatch(r'\d{1,2}', month) or not 1 <= int(month) <= 12):
            abort(400, 'Choose a valid month.')
        if month and not year:
            year = str(today.year)
        if month:
            start = f'{year}-{int(month):02d}-01'
            end = date(int(year), int(month), calendar.monthrange(int(year), int(month))[1])
            period = f'{calendar.month_name[int(month)]} {year}'
        elif year:
            start, end, period = f'{year}-01-01', date(int(year),12,31), year
        else:
            start, end, period = '1900-01-01', today, 'All years'
        cutoff = min(end, today).isoformat()
        q = request.args.get('q', '').strip()
        with connection('spels') as db:
            raw = [dict(r) for r in db.execute('SELECT * FROM transactions ORDER BY received_on DESC,id DESC')]
            holidays = {r[0] for r in db.execute('SELECT day FROM holidays')}
        live = [r for r in raw if received_at_ro(r) and received_at_ro(r) <= today.isoformat()
                and r['received_on'] <= today.isoformat() and r['category'] in main['CATEGORIES']]
        years = sorted({r['received_on'][:4] for r in live} | {str(today.year),year} - {''}, reverse=True)
        if q:
            live = [r for r in live if q.casefold() in ' '.join(str(r.get(k) or '')
                    for k in ('reference','applicant','source')).casefold()]
        report_rows = [r for r in live if received_at_ro(r) <= cutoff]
        if start > cutoff:
            report_rows = []
        activity = main['report_activity'](report_rows, holidays, start, cutoff)
        lists = {
            **activity,
            'within': [r for r in activity['acted'] if r['days'] <= 20],
            'beyond': [r for r in activity['acted'] if r['days'] > 20],
        }
        # Releasing remains a live queue, including applications from older periods.
        live = [decorate(r, 'spels') for r in live]
        lists.update(for_release=[r for r in live if r['_ready']],
                     released=[r for r in live if r['_released']],
                     in_progress=[r for r in activity['pending'] if r['action'] != 'Pending'],
                     on_hold=[r for r in activity['pending'] if r['action'] == 'Pending'])
        totals = {key: sum(r['quantity'] for r in rows) for key, rows in lists.items()}
        view = request.args.get('view', 'received')
        if view not in lists:
            abort(400, 'Choose a valid monitoring view.')
        shown = lists[view]
        if view == 'opening':
            from datetime import timedelta
            days_cutoff = (date.fromisoformat(start) - timedelta(days=1)).isoformat()
        else:
            days_cutoff = today.isoformat() if view in ('for_release','released') else cutoff
        if view in ('opening','received','for_release','released'):
            shown = main['enriched'](shown, holidays, days_cutoff)
        shown = [decorate(r,'spels') for r in shown]
        for row in shown:
            row['_pending'] = row['state'] in ('Pending','Pending overdue')
        total, pages = len(shown), max(1, (len(shown)+24)//25)
        try:
            page = min(max(1,int(request.args.get('page',1))),pages)
        except ValueError:
            abort(400, 'Choose a valid page.')
        def link(**changes):
            return url_for('receiver_dashboard',system='spels',**{**request.args.to_dict(),**changes})
        return render_template('receiver_dashboard.html',system='spels',performance=True,
            rows=shown[(page-1)*25:page*25],name_field='applicant',totals=totals,
            view=view,years=years,year=year,month=month,q=q,total=total,page=page,pages=pages,
            first=(page-1)*25+1 if total else 0,last=min(page*25,total),link=link,page_link=lambda number: link(page=number),
            period_display=period,cutoff_display=date.fromisoformat(cutoff).strftime('%B %d, %Y'),
            has_legacy=bool(main['legacy_ipmr_balances'](int(year))) if year else False)

    @app.get('/monitoring/<system>')
    @main['login_required']
    def receiver_dashboard(system):
        authorized()
        table, name, *_ = settings(system)
        if system == 'spels':
            return spels_performance_dashboard()
        with connection(system) as db:
            rows = [decorate(dict(r), system) for r in db.execute(f'SELECT * FROM {table} ORDER BY received_on DESC,id DESC')
                    if received_at_ro(dict(r))]
        years = sorted({r['_received_at_ro'][:4] for r in rows}, reverse=True)
        year = request.args.get('year', '')
        if year and (not re.fullmatch(r'\d{4}', year) or not 1900 <= int(year) <= 9999):
            abort(400, 'Choose a valid year.')
        month = request.args.get('month', '')
        if month and (not re.fullmatch(r'\d{1,2}', month) or not 1 <= int(month) <= 12):
            abort(400, 'Choose a valid month.')
        q = request.args.get('q', '').strip()
        rows = [r for r in rows if (not year or r['_received_at_ro'].startswith(year))
                and (not month or r['_received_at_ro'][5:7] == f'{int(month):02}')
                and (not q or q.casefold() in ' '.join(str(r.get(k) or '') for k in ('reference', name, 'source')).casefold())]
        tests = {'received': lambda r: True, 'acted': lambda r: r['_acted'],
                 'for_release': lambda r: r['_ready'], 'released': lambda r: r['_released'],
                 'in_progress': lambda r: r['_in_progress'], 'on_hold': lambda r: r['_hold']}
        totals = {key: sum(r['_quantity'] for r in rows if test(r)) for key, test in tests.items()}
        view = request.args.get('view', 'received')
        if view not in tests:
            abort(400, 'Choose a valid monitoring view.')
        shown = [r for r in rows if tests[view](r)]
        total = len(shown)
        pages = max(1, (total + 24) // 25)
        try:
            page = min(max(1, int(request.args.get('page', 1))), pages)
        except ValueError:
            abort(400, 'Choose a valid page.')
        def link(**changes):
            return url_for('receiver_dashboard', system=system, **{**request.args.to_dict(), **changes})
        return render_template('receiver_dashboard.html', system=system, rows=shown[(page-1)*25:page*25],
            name_field=name, performance=False, totals=totals, view=view, years=years, year=year, month=month,
            q=q, total=total, page=page, pages=pages, first=(page-1)*25+1 if total else 0, last=min(page*25,total), link=link, page_link=lambda number: link(page=number))

    @app.route('/releasing/<system>/<int:ident>', methods=['GET','POST'])
    @main['login_required']
    def receiver_release(system, ident):
        account = authorized()
        table, name, *_ = settings(system)
        with connection(system) as db:
            if request.method == 'POST':
                db.execute('BEGIN IMMEDIATE')
            raw = db.execute(f'SELECT * FROM {table} WHERE id=?', (ident,)).fetchone()
            if raw is None or not received_at_ro(dict(raw)):
                abort(404)
            row = dict(raw)
            if request.method == 'POST':
                allowed = {'_csrf','version','released_client_on'}
                if set(request.form) - allowed:
                    abort(403, 'Only the actual client release date can be recorded here.')
                if request.form.get('version') != record_version(row):
                    abort(409, 'This application changed. Reload before recording release.')
                issue = release_issue(row, system)
                if issue:
                    abort(409, issue)
                try:
                    value = request.form.get('released_client_on', '').strip()
                    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
                        raise ValueError('Enter the actual client release date.')
                    released = date.fromisoformat(value).isoformat()
                    if released > main['local_today']().isoformat():
                        raise ValueError('Release date cannot be later than today.')
                    minimum = max(str(row.get(k) or '') for k in ('received_on','received_ro_on','first_date',
                        'second_date','acted_on','first_verified_on','second_verified_on','released_fo_on',
                        'released_on','received_back_ro_on','received_back_on'))
                    if released < minimum:
                        raise ValueError('Release date cannot precede receipt, verification, or recorded office handoff dates.')
                    changes = {'released_client_on': released}
                    if system == 'spels':
                        changes['action'] = confirmed_action(row)
                        validate_client_release({**row, **changes})
                    else:
                        changes.update(status='Released', updated_by=account['username'])
                    db.execute(f'UPDATE {table} SET '+','.join(k+'=?' for k in changes)+',updated_at=CURRENT_TIMESTAMP WHERE id=?', (*changes.values(),ident))
                    before = {k:row.get(k) for k in changes}
                    event = 'Client release recorded: ' + json.dumps({'before':before,'after':changes},ensure_ascii=False)
                    if system == 'spels':
                        db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)', (ident,account['username'],event))
                    else:
                        db.execute('INSERT INTO coe_audit(transaction_id,username,event,old_json,new_json) VALUES (?,?,?,?,?)',
                            (ident,account['username'],'Client release recorded',json.dumps(before),json.dumps(changes)))
                    flash('Client release recorded. The original receipt and verification dates are retained.')
                    return redirect(url_for('receiver_dashboard',system=system,view='released'))
                except ValueError as error:
                    flash(str(error))
                    return render_template('receiver_release.html',system=system,row=decorate(row,system),
                        name_field=name,version=record_version(row),release_date=request.form.get('released_client_on','')),400
            return render_template('receiver_release.html',system=system,row=decorate(row,system),
                name_field=name,version=record_version(row),release_date=main['local_today']().isoformat())
