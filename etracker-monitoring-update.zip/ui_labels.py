"""Presentation labels only; stored status values remain compatible."""
STATUS_LABELS = {
    '': 'No action recorded',
    'Received': 'Awaiting processing',
    'Received/Awaiting Processing': 'Awaiting processing',
    'On Process': 'In progress',
    'Pending': 'Pending resolution',
    'For Compliance': 'Awaiting compliance',
    'For COPI': 'On hold for COPI',
    'COPI': 'On hold for COPI',
    'Other': 'Other action',
    'FOR REVIEW': 'Needs review',
    'Within 20 days': 'Within 20 working days',
    'Beyond 20 days': 'Beyond 20 working days',
    'Pending overdue': 'Pending beyond 20 working days',
    'To be transmitted to ESD-ROII': 'Ready to send to Regional Office',
    'To be transmitted to FO': 'Ready to send to Field Office',
    'To Be Received by FO': 'Awaiting Field Office receipt',
    'For Release': 'Ready for release',
    'Not Yet Released': 'Not yet released to client',
    'Released': 'Released',
}

def status_label(value):
    return STATUS_LABELS.get(value, value or 'No action recorded')
