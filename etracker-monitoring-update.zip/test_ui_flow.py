"""Isolated regression checks: python -m unittest test_ui_flow -v.

Uses fresh temporary databases; never opens the supplied production databases.
"""
import os
import secrets
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


class InterfaceFlowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.password = secrets.token_urlsafe(24)
        cls.environment = patch.dict(os.environ, {
            'ETRACKER_DB': str(Path(cls.temp.name) / 'main.db'),
            'COE_DB': str(Path(cls.temp.name) / 'coe.db'),
            'ETRACKER_SECRET_KEY': secrets.token_urlsafe(32),
            'ETRACKER_ADMIN_PASSWORD': cls.password,
        })
        cls.environment.start()
        import app
        cls.tracker = app
        app.app.config['TESTING'] = True
        app.init_db()
        app.init_db()
        from werkzeug.security import generate_password_hash
        with app.conn() as db:
            db.execute('INSERT INTO users(username,password_hash,role) VALUES (?,?,?)',
                       ('flow-verifier', generate_password_hash(cls.password), 'first_verifier'))
            db.execute('INSERT INTO ro_account_profiles(username,display_name,created_by) VALUES (?,?,?)',
                       ('flow-verifier', 'Test Verifier', 'admin'))

    @classmethod
    def tearDownClass(cls):
        cls.environment.stop()
        cls.temp.cleanup()

    def setUp(self):
        self.client = self.tracker.app.test_client()

    def login(self, username='admin'):
        self.client.get('/login')
        with self.client.session_transaction() as session:
            token = session['csrf']
        response = self.client.post('/login', data={
            'username': username, 'password': self.password, '_csrf': token})
        self.assertEqual(response.status_code, 302)
        with self.client.session_transaction() as session:
            return session['csrf']

    def test_login_logout_and_csrf(self):
        token = self.login()
        self.assertEqual(self.client.get('/systems').status_code, 200)
        self.assertEqual(self.client.post('/logout', data={'_csrf': 'invalid'}).status_code, 400)
        self.assertEqual(self.client.post('/logout', data={'_csrf': token}).status_code, 302)
        self.assertEqual(self.client.get('/transactions').status_code, 302)

    def test_create_transaction_and_report(self):
        token = self.login()
        response = self.client.post('/transactions/new', data={
            '_csrf': token, 'category': 'Other', 'subtype': 'BOE',
            'source': 'Walk-In', 'applicant': 'UI Flow Test',
            'received_on': self.tracker.local_today().isoformat(), 'quantity': '1'})
        self.assertEqual(response.status_code, 302)
        self.assertIn('/edit', response.location)
        self.assertEqual(self.client.get(response.location).status_code, 200)
        with self.tracker.conn() as db:
            row = db.execute("SELECT * FROM transactions WHERE applicant='UI Flow Test'").fetchone()
        self.assertIsNotNone(row)
        self.assertIsNone(row['released_client_on'])
        self.assertEqual(self.client.get('/report.csv').status_code, 200)

    def test_role_navigation_and_password_validation(self):
        token = self.login('flow-verifier')
        self.assertIn('/work/spels', self.client.get('/').location)
        self.assertEqual(self.client.get('/transactions').status_code, 403)
        for path in ['/work/spels', '/work/coe', '/work/password']:
            response = self.client.get(path)
            self.assertEqual(response.status_code, 200, path)
        html = self.client.get('/work/coe').get_data(as_text=True)
        self.assertIn('href="/systems" aria-label="Back"', html)
        response = self.client.get('/work/password')
        self.assertIn('minlength="10"', response.get_data(as_text=True))
        response = self.client.post('/work/password', data={
            '_csrf': token, 'current_password': self.password,
            'password': 'short', 'confirm_password': 'short'})
        self.assertIn('at least 10 characters', response.get_data(as_text=True))

    def test_labels_preserve_saved_values(self):
        from ui_labels import status_label
        self.assertEqual(status_label('On Process'), 'In progress')
        self.assertEqual(status_label('Approved'), 'Approved')
        self.login()
        html = self.client.get('/coe/new').get_data(as_text=True)
        self.assertIn('value="On Process"', html)
        self.assertIn('In progress</option>', html)
        self.assertIn('How this workflow works', html)
        with self.client.get('/static/ui-refresh.css') as response:
            self.assertEqual(response.status_code, 200)


if __name__ == '__main__':
    unittest.main()
