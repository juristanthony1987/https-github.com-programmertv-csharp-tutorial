"""Windows/local-network entry point. Database passwords are prompted, not saved.

python launch_postgres.py migrate
python launch_postgres.py check
python launch_postgres.py run
"""
import argparse
import getpass
import json
import os
import secrets
from pathlib import Path


def configure_connection():
    if os.getenv('ETRACKER_DATABASE_URL'):
        return
    from psycopg.conninfo import make_conninfo
    host=input('PostgreSQL host [127.0.0.1]: ').strip() or '127.0.0.1'
    port=input('PostgreSQL port [5432]: ').strip() or '5432'
    name=input('Database name [etracker]: ').strip() or 'etracker'
    username=input('Database user [etracker_app]: ').strip() or 'etracker_app'
    password=getpass.getpass('Database password (hidden): ')
    os.environ['ETRACKER_DATABASE_URL']=make_conninfo(host=host,port=port,dbname=name,user=username,password=password)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['migrate','check','run'])
    parser.add_argument('--sqlite-main',type=Path,default=Path(__file__).parent/'etracker.db')
    parser.add_argument('--sqlite-coe',type=Path,default=Path(__file__).parent/'coe.db')
    parser.add_argument('--report',type=Path,default=Path('postgres-migration-report.json'))
    parser.add_argument('--host',default='127.0.0.1',help='Use 0.0.0.0 only for your intended office network.')
    parser.add_argument('--port',type=int,default=5000)
    args=parser.parse_args()
    configure_connection()
    if args.action=='migrate':
        if args.report.exists():
            parser.error('Report already exists. Choose a new --report filename.')
        from migrate_postgres import migrate
        report=migrate(args.sqlite_main,args.sqlite_coe)
        args.report.write_text(json.dumps({'status':'verified','tables':report},indent=2))
        print('Migration complete:',sum(r['rows'] for r in report),'rows verified. Original SQLite files were not changed.')
        return
    import database
    database.ensure_initialized()
    from app import app,conn
    with conn() as db:
        users=db.execute('SELECT count(*) FROM users').fetchone()[0]
        count=db.execute('SELECT count(*) FROM transactions').fetchone()[0]
    if not users:
        raise RuntimeError('No migrated accounts found. Run the migration before starting.')
    if args.action=='check':
        print('PostgreSQL connected. Accounts:',users,'SPELS records:',count)
        return
    # Persist a separate session key without publishing database credentials.
    if not os.getenv('ETRACKER_SECRET_KEY'):
        local=Path(__file__).resolve().parent/'.postgres-local'
        local.mkdir(exist_ok=True,mode=0o700)
        key=local/'session-key'
        try:
            with open(key,'x',opener=lambda p,f:os.open(p,f,0o600)) as output:
                output.write(secrets.token_urlsafe(48))
        except FileExistsError:
            pass
        os.environ['ETRACKER_SECRET_KEY']=key.read_text().strip()
    app.secret_key=os.environ['ETRACKER_SECRET_KEY']
    if not app.secret_key:
        raise RuntimeError('The local session key is empty.')
    from waitress import serve
    print('Starting eTracker with PostgreSQL. Press Ctrl+C to stop.')
    serve(app,host=args.host,port=args.port,threads=8)


if __name__=='__main__':
    try:
        main()
    except KeyboardInterrupt:
        pass
    except Exception as error:
        # Driver diagnostics can contain row values; do not print them here.
        print('Operation stopped ('+type(error).__name__+').')
        if isinstance(error,(RuntimeError,ValueError,FileNotFoundError)):
            print(str(error))
        raise SystemExit(1)
