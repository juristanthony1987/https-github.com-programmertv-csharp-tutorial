from fo_access import fo_office, office_choices, scoped_select, guard_connection
from year_management import coe_year_choices
"""COE monitoring uses a separate SQLite database and existing login/CSRF."""
import calendar, csv, io, json, os
import database as sqlite3
from datetime import date, datetime
from zoneinfo import ZoneInfo
from pathlib import Path

FIELDS=('reference','received_on','source','transaction_no','eligible_name','coe_copies','auth_copies','first_verifier','second_verifier','authenticated_by','remarks','status','released_on','received_ro_on','received_back_ro_on','released_client_on','destination_fo','first_verified_on','second_verified_on')

def connect(path):
    db=sqlite3.connect(path,timeout=30); db.row_factory=sqlite3.Row
    return guard_connection(db, 'coe_transactions')

def initialize(path):
    if sqlite3.postgres_enabled():
        sqlite3.ensure_initialized()
        return
    with connect(path) as db:
        db.executescript('''CREATE TABLE IF NOT EXISTS coe_transactions (
        id INTEGER PRIMARY KEY, received_on TEXT, source TEXT NOT NULL DEFAULT '', transaction_no TEXT NOT NULL,
        eligible_name TEXT NOT NULL, coe_copies INTEGER NOT NULL DEFAULT 0 CHECK(coe_copies>=0),
        auth_copies INTEGER NOT NULL DEFAULT 0 CHECK(auth_copies>=0), first_verifier TEXT NOT NULL DEFAULT '',
        second_verifier TEXT NOT NULL DEFAULT '', authenticated_by TEXT NOT NULL DEFAULT '', remarks TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL DEFAULT 'Pending', released_on TEXT, source_key TEXT UNIQUE, source_json TEXT,
        updated_by TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS coe_audit(id INTEGER PRIMARY KEY, transaction_id INTEGER, username TEXT,
        event TEXT, old_json TEXT, new_json TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);''')

    with connect(path) as db:
        columns={r[1] for r in db.execute('PRAGMA table_info(coe_transactions)')}
        for field in ('first_verified_on', 'second_verified_on'):
            if field not in columns:
                db.execute(f'ALTER TABLE coe_transactions ADD COLUMN {field} TEXT')
        if 'destination_fo' not in columns:
            db.execute("ALTER TABLE coe_transactions ADD COLUMN destination_fo TEXT NOT NULL DEFAULT ''")
        if 'released_client_on' not in columns:
            db.execute('ALTER TABLE coe_transactions ADD COLUMN released_client_on TEXT')
        if 'received_back_ro_on' not in columns:
            db.execute('ALTER TABLE coe_transactions ADD COLUMN received_back_ro_on TEXT')
        if 'received_ro_on' not in columns:
            db.execute('ALTER TABLE coe_transactions ADD COLUMN received_ro_on TEXT')
        if 'reference' not in columns:
            db.execute('ALTER TABLE coe_transactions ADD COLUMN reference TEXT')
        db.executescript('CREATE UNIQUE INDEX IF NOT EXISTS coe_reference_unique ON coe_transactions(reference); CREATE TABLE IF NOT EXISTS coe_sequences(source TEXT, year INTEGER, last_number INTEGER NOT NULL, PRIMARY KEY(source,year));')
        from legacy_ro_receipt import backfill_old_fo_receipts
        backfill_old_fo_receipts(db, 'coe_transactions')

SOURCES=('Walk-In','ISAFO','NVFO','QFO','BATFO')
TRANSMISSION_STATUS='To be transmitted to FO'
RO_TRANSMISSION_STATUS='To be transmitted to ESD-ROII'
COMPLIANCE_STATUS='For Compliance'
FO_RECEIPT_STATUS='To Be Received by FO'
FOR_RELEASE_STATUS='For Release'
DESTINATION_FOS=('BATFO','ISAFO','NVFO','QFO')

def validate_destination(status, destination, previous=''):
    destination=canonical_source(destination) if destination else ''
    if status==TRANSMISSION_STATUS:
        if destination not in DESTINATION_FOS:
            raise ValueError('Choose a Destination FO: BATFO, ISAFO, NVFO or QFO.')
        return destination
    return previous or ''

SOURCE_CODES={'Walk-In':'WI','ISAFO':'ISAFO','NVFO':'NVFO','QFO':'QFO','BATFO':'BATFO'}

def canonical_source(value):
    aliases={'wi':'Walk-In','walk-in':'Walk-In','walk in':'Walk-In','isa':'ISAFO','isafo':'ISAFO','isabela':'ISAFO','nv':'NVFO','nvfo':'NVFO','qno':'QFO','qn':'QFO','qfo':'QFO','quirino':'QFO','bat':'BATFO','batfo':'BATFO','batanes':'BATFO'}
    return aliases.get((value or '').strip().lower(), value)

def effective_status(row):
    """COPI takes precedence. Walk-In is released under the office rule.
    Historical release dates are never invented.
    """
    raw=str(row.get('status') or '').strip()
    if raw in ('Received/Awaiting Processing', 'On Process'): return raw
    if 'copi' in raw.casefold(): return 'COPI'
    # Panatilihin ang For Compliance kahit Walk-In o may dating release date.
    if raw.casefold()==COMPLIANCE_STATUS.casefold(): return COMPLIANCE_STATUS
    if raw.casefold()==FOR_RELEASE_STATUS.casefold(): return FOR_RELEASE_STATUS
    if raw.casefold() in (FO_RECEIPT_STATUS.casefold(), 'processed/to transmit fo'):
        return FOR_RELEASE_STATUS if row.get('received_back_ro_on') else FO_RECEIPT_STATUS
    if raw.casefold()==TRANSMISSION_STATUS.casefold(): return TRANSMISSION_STATUS
    if raw.casefold()==RO_TRANSMISSION_STATUS.casefold(): return RO_TRANSMISSION_STATUS
    if canonical_source(row.get('source'))=='Walk-In': return 'Released'
    if raw.casefold()=='pending': return 'Pending'
    if row.get('released_client_on') or row.get('released_on') or raw.casefold().startswith('released'): return 'Released'
    return 'Pending'


PROCESSOR_FIELDS=('first_verifier','second_verifier','authenticated_by')

def processor_names(db):
    names={}
    for row in scoped_select(db, 'SELECT first_verifier,second_verifier,authenticated_by FROM coe_transactions'):
        for value in row:
            name=' '.join(str(value or '').split())
            if name and name not in ('-', '—'):
                names.setdefault(name.casefold(), name)
    return sorted(names.values(),key=str.casefold)

def processor_summary(rows):
    summary={}
    for row in rows:
        for field in PROCESSOR_FIELDS:
            name=' '.join(str(row.get(field) or '').split())
            if not name or name in ('-', '—'): continue
            key=name.casefold()
            item=summary.setdefault(key,dict(name=name,first_verifier=0,second_verifier=0,authenticated_by=0,total=0))
            item[field]+=1
            if field in ('first_verifier','second_verifier'): item['total']+=1
    return sorted(summary.values(),key=lambda r:(-r['total'],r['name'].casefold()))


def reserve_reference(db, source, received_on):
    """Call within BEGIN IMMEDIATE; annual counter per source never reuses numbers."""
    source=canonical_source(source)
    if source not in SOURCES: raise ValueError('Choose a valid Office / Source.')
    day=date.fromisoformat(received_on); code=SOURCE_CODES[source]
    db.execute('INSERT OR IGNORE INTO coe_sequences VALUES (?,?,0)',(source,day.year))
    while True:
        db.execute('UPDATE coe_sequences SET last_number=last_number+1 WHERE source=? AND year=?',(source,day.year))
        number=db.execute('SELECT last_number FROM coe_sequences WHERE source=? AND year=?',(source,day.year)).fetchone()[0]
        ref=f'{code}{day.year}-{day:%m%d}-{number:05d}'
        if not scoped_select(db, 'SELECT 1 FROM coe_transactions WHERE reference=?',(ref,)).fetchone(): return ref

def register_coe(app, base, login_required):
    from flask import abort, flash, redirect, render_template, request, Response, session, url_for
    path=Path(os.getenv('COE_DB',str(base/'coe.db')))
    initialize(path)
    app.config['COE_DB']=str(path)

    def can_release_to_fo():
        from flask import current_app
        if fo_office(): return False
        username = session.get('username','')
        with sqlite3.connect(current_app.config['FO_MAIN_DB']) as users_db:
            account = users_db.execute('SELECT role FROM users WHERE username=?',(username,)).fetchone()
        return bool(account and (account[0]=='admin' or username.casefold()=='admin'
                    or (username.casefold()=='ajvtb' and account[0]=='chief')))

    @app.context_processor
    def coe_handoff_permissions():
        return {'can_release_to_fo':can_release_to_fo() if session.get('username') else False}

    def selection():
        year=request.args.get('year',''); month=request.args.get('month',''); day=request.args.get('day','')
        if year and (not year.isdigit() or not 1900<=int(year)<=9999): abort(400,'Invalid year')
        if month and (not month.isdigit() or not 1<=int(month)<=12): abort(400,'Invalid month')
        if day and (not day.isdigit() or not 1<=int(day)<=31): abort(400,'Invalid day')
        if year and month and day:
            try: date(int(year),int(month),int(day))
            except ValueError: abort(400,'Invalid date')
        with connect(path) as db: all_rows=[dict(r) for r in scoped_select(db, 'SELECT * FROM coe_transactions ORDER BY received_on DESC,id DESC')]
        for r in all_rows:
            r['stored_status']=r['status']; r['status']=effective_status(r)
        rows=[r for r in all_rows if (not year or (r['received_on'] or '')[:4]==year) and (not month or (r['received_on'] or '')[5:7]==month.zfill(2)) and (not day or (r['received_on'] or '')[8:10]==day.zfill(2))]
        return all_rows,rows,year,month,day

    def filter_rows(rows):
        q=request.args.get('q','').strip()
        state=request.args.get('state','').strip().casefold()
        source=request.args.get('source','')
        if source and source not in SOURCES: abort(400,'Invalid source')
        # Keep old dashboard/bookmark links working.
        if state=='unreleased': state='pending'
        if state not in ('','released','pending','copi','review','received/awaiting processing','on process',COMPLIANCE_STATUS.casefold(),FOR_RELEASE_STATUS.casefold(),FO_RECEIPT_STATUS.casefold(),TRANSMISSION_STATUS.casefold(),RO_TRANSMISSION_STATUS.casefold()): abort(400,'Invalid status')
        selected=[]
        for r in rows:
            if source and canonical_source(r['source'])!=source: continue
            if q and not any(q.casefold() in str(r.get(k) or '').casefold() for k in FIELDS): continue
            if state=='review':
                if r['received_on'] and not (r['released_on'] and r['released_on']<r['received_on']): continue
            elif state=='pending':
                if r['status'] not in ('Pending','Received/Awaiting Processing','On Process',TRANSMISSION_STATUS,RO_TRANSMISSION_STATUS,FO_RECEIPT_STATUS): continue
            elif state and r['status'].casefold()!=state: continue
            selected.append(r)
        return selected,q,state

    @app.get('/coe')
    @login_required
    def coe_dashboard():
        all_rows,rows,year,month,day=selection()
        source=request.args.get('source','')
        if source and source not in SOURCES: abort(400,'Invalid source')
        if source:
            all_rows=[r for r in all_rows if canonical_source(r['source'])==source]
            rows=[r for r in rows if canonical_source(r['source'])==source]
        released=[r for r in rows if r['status']=='Released']
        monthly=[]
        for m in range(1,13):
            received=[r for r in all_rows if (not year or (r['received_on'] or '')[:4]==year) and (r['received_on'] or '')[5:7]==f'{m:02}']
            out=[r for r in all_rows if r['status']=='Released' and (not year or (r.get('released_client_on') or r['released_on'] or '')[:4]==year) and (r.get('released_client_on') or r['released_on'] or '')[5:7]==f'{m:02}']
            monthly.append(dict(month=calendar.month_name[m],received=len(received),released=len(out),coe=sum(r['coe_copies'] for r in out),auth=sum(r['auth_copies'] for r in out)))
        statuses={}
        for r in rows: statuses[r['status']]=statuses.get(r['status'],0)+1
        verifier=request.args.get('verifier','').strip()
        verifier_year=request.args.get('verifier_year',year)
        verifier_month=request.args.get('verifier_month',month)
        if verifier_year and (not verifier_year.isdigit() or not 1900<=int(verifier_year)<=9999): abort(400,'Invalid verifier year')
        if verifier_month and (not verifier_month.isdigit() or not 1<=int(verifier_month)<=12): abort(400,'Invalid verifier month')
        with connect(path) as db: verifier_options=processor_names(db)
        verifier_rows=[r for r in all_rows if (not verifier_year or (r['received_on'] or '')[:4]==verifier_year) and (not verifier_month or (r['received_on'] or '')[5:7]==verifier_month.zfill(2))]
        processors=processor_summary(verifier_rows)
        if verifier: processors=[p for p in processors if p['name'].casefold()==verifier.casefold()]
        return render_template('coe_dashboard.html',empty_database=not all_rows,total=len(rows),released=len(released),pending=sum(r['status'] in ('Pending','Received/Awaiting Processing','On Process',TRANSMISSION_STATUS,RO_TRANSMISSION_STATUS,FO_RECEIPT_STATUS) for r in rows),for_release=sum(r['status']==FOR_RELEASE_STATUS for r in rows),compliance=sum(r['status']==COMPLIANCE_STATUS for r in rows),copi=sum(r['status']=='COPI' for r in rows),coe=sum(r['coe_copies'] for r in rows),auth=sum(r['auth_copies'] for r in rows),monthly=monthly,statuses=statuses,source=source,coe_sources=office_choices(SOURCES),processors=processors,verifier=verifier,verifier_year=verifier_year,verifier_month=verifier_month,verifier_options=verifier_options,year=year,month=month,day=day,months=calendar.month_name,years=coe_year_choices(path, all_rows, year))

    @app.post('/coe/import-source')
    @login_required
    def coe_import_source():
        from import_coe import import_file
        source=base/'COE.xlsx'
        if not source.is_file():abort(400,'COE.xlsx is missing. Copy the supplied workbook into the app folder.')
        with connect(path) as db:
            if scoped_select(db, 'SELECT count(*) FROM coe_transactions').fetchone()[0]:
                abort(409,'COE already contains records. Import was not run.')
        result=import_file(source,path)
        flash(f"Imported {result['imported']} COE records. Review missing or inconsistent dates.")
        return redirect(url_for('coe_dashboard'))

    @app.get('/coe/transactions')
    @login_required
    def coe_transactions():
        all_rows,rows,year,month,day=selection()
        rows,q,state=filter_rows(rows)
        try:page=max(1,int(request.args.get('page',1)))
        except ValueError:abort(400)
        total=len(rows);pages=max(1,(total+24)//25);page=min(page,pages)
        def link(n):
            args=request.args.to_dict();args['page']=n
            return url_for('coe_transactions',**args)
        return render_template('coe_transactions.html',rows=rows[(page-1)*25:page*25],coe_sources=office_choices(SOURCES),total=total,page=page,pages=pages,link=link,q=q,year=year,month=month,day=day,state=state,months=calendar.month_name,years=coe_year_choices(path, all_rows, year))

    @app.route('/coe/new',methods=['GET','POST'])
    @app.route('/coe/<int:ident>/edit',methods=['GET','POST'])
    @login_required
    def coe_form(ident=None):
        with connect(path) as db:
            old=scoped_select(db, 'SELECT * FROM coe_transactions WHERE id=?',(ident,)).fetchone() if ident else None
            if ident and not old:abort(404)
            verifiers=processor_names(db)
            row=dict(old) if old else {'received_on':datetime.now(ZoneInfo('Asia/Manila')).date().isoformat(),'source':fo_office() or ''}
            if request.method=='POST':
                row={k:request.form.get(k,'').strip() for k in FIELDS}
                if fo_office():
                    stored = dict(old) if old else {}
                    for key in ('first_verifier','second_verifier','authenticated_by'):
                        row[key] = stored.get(key) or ''
                    row['received_ro_on'] = stored.get('received_ro_on') or ''
                stored = dict(old) if old else {}
                for field in ('first_verified_on', 'second_verified_on'):
                    if not can_release_to_fo() or field not in request.form:
                        row[field] = stored.get(field) or ''
                if not can_release_to_fo():
                    row['released_on'] = stored.get('released_on') or ''
                row['received_back_ro_on'] = stored.get('received_back_ro_on') or ''
                try:
                    for k in ('coe_copies','auth_copies'):
                        row[k]=int(row[k] or 0)
                        if row[k]<0:raise ValueError('Copies must be zero or higher.')
                    for k in ('received_on','released_on','received_ro_on','received_back_ro_on','released_client_on','first_verified_on','second_verified_on'):
                        if row[k]: date.fromisoformat(row[k])
                        else:row[k]=None
                    row['source']=canonical_source(row['source'])
                    if row['source'] not in SOURCES:raise ValueError('Choose a valid Office / Source.')
                    if not row['received_on']:raise ValueError('Date received is required.')
                    for date_field, person_field in (('first_verified_on','first_verifier'),('second_verified_on','second_verifier')):
                        value = row[date_field]
                        if value and (value < max(row['received_on'], row['received_ro_on'] or '') or value > datetime.now(ZoneInfo('Asia/Manila')).date().isoformat()):
                            raise ValueError('Verification date must be on/after RO receipt and not in the future.')
                        if value and not row[person_field]:
                            raise ValueError('Select the verifier before entering a verification date.')
                    if row['second_verified_on'] and (not row['first_verified_on'] or row['second_verified_on'] < row['first_verified_on']):
                        raise ValueError('Complete the 1st verification date before the 2nd verification date.')
                    if row['source']!='Walk-In' and not row['eligible_name']:raise ValueError('Name of eligible is required for Field Office transactions.')
                    if ident and old['reference'] and (row['source']!=canonical_source(old['source']) or row['received_on']!=old['received_on']):raise ValueError('Source and Date Received are locked after a reference is assigned.')
                    if row['released_on'] and row['released_on']<row['received_on']:raise ValueError('Release date must not precede receipt date.')
                    if row['released_on'] and row['received_ro_on'] and row['released_on']<row['received_ro_on']:
                        raise ValueError('Date Released to FO must not precede Date Received by RO.')
                    if row['received_ro_on'] and row['received_ro_on']<row['received_on']:raise ValueError('Date Received by RO must not precede Date Received.')
                    if row['received_ro_on'] and row['received_ro_on']>datetime.now(ZoneInfo('Asia/Manila')).date().isoformat():raise ValueError('Date Received by RO must not be in the future.')
                    if row['received_back_ro_on']:
                        if row['received_back_ro_on']>datetime.now(ZoneInfo('Asia/Manila')).date().isoformat():raise ValueError('Date Received Back from RO must not be in the future.')
                        if row['received_back_ro_on']<row['received_on']:raise ValueError('Date Received Back from RO must not precede Date Received.')
                        if row['released_on'] and row['received_back_ro_on']<row['released_on']:raise ValueError('Date Received Back from RO must not precede Date Released to FO.')
                    if row['status'] not in ('','Received/Awaiting Processing','On Process','Pending','Released','COPI','For COPI','Released to Client','Released to FO',COMPLIANCE_STATUS,FOR_RELEASE_STATUS,FO_RECEIPT_STATUS,TRANSMISSION_STATUS,RO_TRANSMISSION_STATUS):
                        raise ValueError('Choose Pending, For Compliance, To be transmitted to FO, Released or COPI.')
                    if row['status']==FO_RECEIPT_STATUS:
                        if fo_office() and stored.get('status') not in (FO_RECEIPT_STATUS,'Processed/To Transmit FO'):
                            raise ValueError('To Be Received by FO is assigned by the Regional Office only.')
                        if row['source'] not in DESTINATION_FOS:
                            raise ValueError('To Be Received by FO requires a Field Office source.')
                    if row['status']==COMPLIANCE_STATUS and fo_office() and stored.get('status')!=COMPLIANCE_STATUS:
                        raise ValueError('For Compliance is assigned by the Regional Office only.')
                    if row['status']==RO_TRANSMISSION_STATUS:
                        if row['source'] not in DESTINATION_FOS or (not fo_office() and stored.get('status')!=RO_TRANSMISSION_STATUS):
                            raise ValueError('To be transmitted to ESD-ROII is selected by Field Office accounts only.')
                    if row['status']==TRANSMISSION_STATUS and (row['source']!='Walk-In' or not can_release_to_fo()):
                        raise ValueError('To be transmitted to FO is available only for Walk-In transactions under Admin or AJVTB.')
                    row['destination_fo']=validate_destination(row['status'],row['destination_fo'],stored.get('destination_fo') or '')
                    if row['status'] not in ('Released','Released to Client'):
                        row['released_client_on']=None
                    if fo_office() and row['status'] in ('Released','Released to Client') and not row['released_client_on']:
                        raise ValueError('Date Released to Client is required when FO selects Released.')
                    if row['released_client_on']:
                        if row['released_client_on']>datetime.now(ZoneInfo('Asia/Manila')).date().isoformat():raise ValueError('Date Released to Client must not be in the future.')
                        for key,label in [('received_on','Date Received'),('released_on','Date Released to FO'),('received_back_ro_on','Date Received Back from RO')]:
                            if row[key] and row['released_client_on']<row[key]:raise ValueError('Date Released to Client must not precede '+label+'.')
                    row['status']=effective_status(row)
                except ValueError as error:
                    flash(str(error));return render_template('coe_form.html',row=row,ident=ident,coe_sources=office_choices(SOURCES),verifiers=verifiers),400
                db.execute('BEGIN IMMEDIATE')
                if ident:
                    sqlite3.lock_record(db, 'coe_transactions', ident)
                current=scoped_select(db, 'SELECT * FROM coe_transactions WHERE id=?',(ident,)).fetchone() if ident else None
                if ident and (not current or dict(current)!=dict(old)):abort(409,'Record changed. Reload before saving.')
                row['reference']=current['reference'] if current and current['reference'] else reserve_reference(db,row['source'],row['received_on'])
                row['transaction_no']=current['transaction_no'] if current else row['reference']
                values=[row[k] for k in FIELDS]
                if ident:
                    db.execute('UPDATE coe_transactions SET '+','.join(k+'=?' for k in FIELDS)+',updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',values+[session['username'],ident])
                else:
                    cur=db.execute('INSERT INTO coe_transactions ('+','.join(FIELDS)+',updated_by) VALUES ('+','.join('?' for _ in range(len(FIELDS)+1))+')',values+[session['username']]);ident=cur.lastrowid
                db.execute('INSERT INTO coe_audit(transaction_id,username,event,old_json,new_json) VALUES (?,?,?,?,?)',(ident,session['username'],'Edit' if old else 'Create',json.dumps(dict(old)) if old else None,json.dumps(row)))
                flash('COE transaction saved. Select X when you are ready to close.');return redirect(url_for('coe_form',ident=ident))
        row['status']=effective_status(row)
        return render_template('coe_form.html',row=row,ident=ident,coe_sources=office_choices(SOURCES),verifiers=verifiers)

    @app.get('/coe/export.csv')
    @login_required
    def coe_export():
        _,rows,_,_,_=selection(); rows,_,_=filter_rows(rows); output=io.StringIO(); writer=csv.writer(output);writer.writerow(FIELDS)
        for r in rows:
            vals=[r[k] for k in FIELDS]
            writer.writerow(["'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v for v in vals])
        return Response('\ufeff'+output.getvalue(),mimetype='text/csv',headers={'Content-Disposition':'attachment; filename=COE-transactions.csv'})
