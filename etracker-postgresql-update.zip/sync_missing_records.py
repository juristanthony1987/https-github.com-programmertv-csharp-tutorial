"""Add only missing Excel transactions. Stop eTracker before --apply. Never updates existing records."""
import os as _database_environment
if _database_environment.getenv('ETRACKER_DATABASE_URL'):
    raise RuntimeError('This legacy maintenance tool is SQLite-only. Use a reviewed PostgreSQL migration; no records were changed.')
import argparse, json, re, sqlite3
from datetime import datetime
from pathlib import Path
import app as a
from migrate_excel import read_workbook

def number(value):
    value=str(value or '').strip()
    if re.fullmatch(r'\d+(?:\.0)?',value):return int(float(value))
    m=re.fullmatch(r'[A-Za-z ]*0*(\d+)',value)
    if m:return int(m[1])
    raise ValueError('Original reference number needs review')

def sync(workbook, apply=False):
    if not a.DB.is_file():raise RuntimeError('Existing etracker.db is required; no new database will be created.')
    accepted,invalid,*_=read_workbook(workbook)
    review=[{'sheet':r['sheet'],'row':r['row_number'],'reason':r['reasons']} for r in invalid]
    added=[];skipped=[]
    with a.conn() as db:
        db.execute('BEGIN IMMEDIATE')
        existing=[dict(r) for r in db.execute('SELECT * FROM transactions')]
        reserved=[(r['category'],a.reference_parts(r['reference'],r['category'])) for r in existing]
        for r in accepted:
            d=r['data'];raw=json.loads(r['raw_json'])
            try:
                first=number(raw[5] if d['category']=='HGE' else raw[3])
                last=number(raw[6] if d['category']=='HGE' else raw[4] if d['category']=='Other' else raw[3])
                if first<1 or last-first+1 != d['quantity']:raise ValueError('Reference range and application quantity do not match')
                ref=a.reference_text(d['category'],d['source'],first,last,d['received_on'])
                same=[x for x in existing if x['reference']==ref]
                if same:
                    skipped.append(ref);continue
                overlaps=any(cat==d['category'] and parts and first<=parts[1] and last>=parts[0] for cat,parts in reserved)
                same_person=any(x['category']==d['category'] and x['source']==d['source'] and x['received_on']==d['received_on'] and ' '.join(x['applicant'].upper().split())==' '.join(d['applicant'].upper().split()) for x in existing)
                if overlaps or same_person:raise ValueError('Existing reference range or applicant match; manual review required')
                d['reference']=ref
                d['first_processor']=a.canonical_processor(d['first_processor']);d['second_processor']=a.canonical_processor(d['second_processor'])
                d['second_date']=d['acted_on']
                d['pending_status']='On Process' if d['action']=='Pending' else ''
                d['copi_reason']='';d['compliance_comment']=''
                if d['action']=='Pending' and 'copi' in d['remarks'].casefold():
                    d['pending_status']='For COPI';d['copi_reason']=d['remarks']
                if apply:
                    cur=db.execute('INSERT INTO transactions ('+','.join(a.FIELDS)+') VALUES ('+','.join('?' for _ in a.FIELDS)+')',tuple(d[k] for k in a.FIELDS))
                    db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',(cur.lastrowid,'excel-sync','Added missing reference '+ref))
                existing.append(dict(d));reserved.append((d['category'],(first,last)));added.append(ref)
            except (ValueError,KeyError) as e:review.append({'sheet':r['sheet'],'row':r['row_number'],'reason':str(e)})
    return {'applied':apply,'added' if apply else 'proposed':added,'existing_skipped':skipped,'review':review}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('workbook',nargs='?',default='latest-logbook.xlsx');p.add_argument('--apply',action='store_true');args=p.parse_args()
    if args.apply:
        if not a.DB.is_file():raise SystemExit('Existing etracker.db required.')
        backup=a.DB.with_name('etracker-before-sync-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.db')
        with sqlite3.connect(a.DB) as source,sqlite3.connect(backup) as dest:source.backup(dest)
        a.init_db()
    result=sync(Path(args.workbook),args.apply)
    Path('missing-records-review.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('Added/proposed:',len(result.get('added',result.get('proposed',[]))),'Existing skipped:',len(result['existing_skipped']),'For review:',len(result['review']))
