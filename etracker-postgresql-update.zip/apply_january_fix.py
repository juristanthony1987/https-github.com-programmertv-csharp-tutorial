import os as _database_environment
if _database_environment.getenv('ETRACKER_DATABASE_URL'):
    raise RuntimeError('This legacy maintenance tool is SQLite-only. Use a reviewed PostgreSQL migration; no records were changed.')
import sqlite3,json,sys
from pathlib import Path
from datetime import datetime
root=Path(__file__).resolve().parent;path=Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()/'etracker.db'
if not path.is_file():raise SystemExit('Hindi makita ang etracker.db')
with sqlite3.connect(path,timeout=30) as db:
 db.row_factory=sqlite3.Row
 backup=path.with_name('etracker-before-january-fix-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.db')
 with sqlite3.connect(backup) as dest:db.backup(dest)
 db.execute('BEGIN IMMEDIATE');updated=0
 for c in json.loads((root/'changes.json').read_text()):
  r=db.execute('select * from transactions where reference=?',(c['reference'],)).fetchone()
  if not r or r['applicant']!=c['applicant']:raise RuntimeError('Hindi tugma ang record: '+c['reference'])
  if r['received_on']==c['received_on']:continue
  if r['received_on']!=c['old_received_on']:raise RuntimeError('Nagbago na ang date; review required: '+c['reference'])
  db.execute('update transactions set received_on=? where id=?',(c['received_on'],r['id']));db.execute('insert into audit(transaction_id,username,event) values(?,?,?)',(r['id'],'user-date-exception',json.dumps(c)));updated+=1
print('Updated:',updated,'Backup:',backup)
