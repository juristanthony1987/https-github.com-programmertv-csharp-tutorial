from workflow_actions import received_action
"""FO confirmation: petsa ay awtomatikong itinatala gamit ang oras sa Pilipinas."""
import database as sqlite3
from flask import abort, flash, redirect, render_template, request, session, url_for
from fo_access import fo_office, normalize_office, scoped_select, OFFICES


def needs_fo_receipt(row, system, cutoff):
    if system == 'spels' and row.get('ro_transmitted_fo'):
        destination = normalize_office(row.get('return_fo_destination') or row.get('source'))
        sent = row.get('ro_transmitted_fo_on')
        return bool(row.get('return_fo_enabled') and row['ro_transmitted_fo'] == 'Yes'
                    and destination in OFFICES and sent and sent <= cutoff
                    and row.get('received_ro_on') and row['received_ro_on'] <= sent
                    and not row.get('received_back_ro_on'))
    if system == 'coe' and str(row.get('status') or '').strip().casefold() in ('to be received by fo', 'processed/to transmit fo'):
        received = row.get('received_ro_on')
        release = row.get('released_on')
        return bool(normalize_office(row.get('source')) in ('ISAFO','NVFO','QFO','BATFO')
                    and received and received <= cutoff
                    and (not release or received <= release <= cutoff)
                    and not row.get('received_back_ro_on'))
    # Kapareho ng kasalukuyang handoff forms: ISAFO, NVFO at QFO lang.
    if normalize_office(row.get('source')) not in ('ISAFO', 'NVFO', 'QFO'):
        return False
    if system == 'spels' and not row.get('return_fo_enabled'):
        return False
    release = row.get('released_on' if system == 'coe' else 'released_fo_on')
    received = row.get('received_ro_on')
    return bool(received and release and received <= cutoff and release <= cutoff
                and not row.get('received_back_ro_on')
                and not (system == 'spels' and row.get('released_fo_na')))


def register_fo_receipt_alerts(app, main):
    def connection(system):
        if system == 'coe':
            from coe_monitor import connect
            return connect(app.config['COE_DB'])
        if system == 'spels':
            db = sqlite3.connect(main['DB'], timeout=30)
            db.row_factory = sqlite3.Row
            return db
        abort(404)

    def spels_returns(db, ident=None):
        # Scope receipt access by destination; keep source-based reports unchanged.
        db.create_function('fo_normalize_office', 1, normalize_office)
        office = fo_office()
        clauses, args = [], []
        if office:
            clauses.append("fo_normalize_office(COALESCE(NULLIF(return_fo_destination,''),source))=?")
            args.append(office)
            clauses.append("(fo_normalize_office(source)=? OR ro_transmitted_fo='Yes')")
            args.append(office)
        if ident is not None:
            clauses.append('id=?'); args.append(ident)
        query = 'SELECT * FROM transactions' + (' WHERE ' + ' AND '.join(clauses) if clauses else '') + ' ORDER BY id'
        return db.execute(query, tuple(args))

    @app.get('/fo-receipt-alerts/spels/<int:ident>')
    @main['login_required']
    def fo_return_detail(ident):
        with connection('spels') as db:
            row = spels_returns(db, ident).fetchone()
        if row is None or not row['return_fo_enabled']:
            abort(404)
        row = dict(row)
        return render_template('fo_return_detail.html', r=row,
            awaiting=needs_fo_receipt(row, 'spels', main['local_today']().isoformat()),
            recipient_names=main['globals_for_templates']()['processors'])

    def records(system):
        cutoff = main['local_today']().isoformat()
        table = 'coe_transactions' if system == 'coe' else 'transactions'
        with connection(system) as db:
            rows = [dict(r) for r in (spels_returns(db) if system == 'spels' else scoped_select(db, f'SELECT * FROM {table} ORDER BY id'))]
        return [r for r in rows if needs_fo_receipt(r, system, cutoff)]

    @app.context_processor
    def context():
        if session.get('username') and request.endpoint in ('dashboard', 'coe_dashboard'):
            system = 'coe' if request.endpoint == 'coe_dashboard' else 'spels'
            rows = records(system)
            return {'fo_receipt_card': {'count': len(rows), 'link': url_for('fo_receipt_records', system=system)}}
        return {}

    @app.get('/fo-receipt-alerts/<system>')
    @main['login_required']
    def fo_receipt_records(system):
        rows = records(system)
        q = request.args.get('q', '').strip()
        if q:
            rows = [r for r in rows if any(q.casefold() in str(r.get(k) or '').casefold()
                    for k in ('reference', 'applicant', 'eligible_name', 'source'))]
        try:
            page = max(1, int(request.args.get('page', 1)))
        except ValueError:
            abort(400)
        pages = max(1, (len(rows) + 24) // 25)
        page = min(page, pages)
        return render_template('fo_receipt_records.html', system=system,
            rows=rows[(page-1)*25:page*25], total=len(rows), q=q, page=page, pages=pages,
            recipient_names=main['globals_for_templates']()['processors'])

    @app.post('/fo-receipt-alerts/<system>/<int:ident>/confirm')
    @main['login_required']
    def fo_receipt_confirm(system, ident):
        office = fo_office()
        if not office:
            abort(403, 'Only the assigned Field Office can confirm receipt.')
        table = 'coe_transactions' if system == 'coe' else 'transactions'
        cutoff = main['local_today']().isoformat()
        with connection(system) as db:
            # Lock bago magbasa upang hindi mapalitan ang unang confirmation.
            db.execute('BEGIN IMMEDIATE')
            sqlite3.lock_record(db, table, ident)
            row = (spels_returns(db, ident) if system == 'spels' else scoped_select(db, f'SELECT * FROM {table} WHERE id=?', (ident,))).fetchone()
            if not row:
                abort(404)
            row = dict(row)
            if normalize_office((row.get('return_fo_destination') or row['source']) if system == 'spels' else row['source']) != office:
                abort(403)
            if row.get('received_back_ro_on'):
                flash('Receipt was already confirmed; the original date is retained.')
            else:
                if not needs_fo_receipt(row, system, cutoff):
                    abort(409, 'RO receipt and release dates are required before confirmation.')
                if system == 'spels':
                    name = session['username']
                    fo_action = row.get('fo_action') or ''
                    if row.get('first_processor') and fo_action in ('', 'Received', 'Acted'):
                        fo_action = 'Acted'  # On Process ang display ng legacy value na Acted.
                    else:
                        fo_action = received_action(fo_action)
                    action = row.get('action') or ''
                    if action in ('', 'Received', 'FOR REVIEW') and (row.get('first_processor') or row.get('second_processor')):
                        action = 'On Process'
                    else:
                        action = received_action(action)
                    db.execute('UPDATE transactions SET received_back_ro_on=?,received_fo_by=?,fo_action=?,action=?,updated_at=CURRENT_TIMESTAMP WHERE id=?', (cutoff, name, fo_action, action, ident))
                    db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',
                               (ident, session['username'], 'FO receipt confirmed: ' + cutoff + '; office: ' + office + '; received by: ' + name + '; FO Action: ' + fo_action + '; RO Action: ' + action))
                else:
                    db.execute(f'UPDATE {table} SET received_back_ro_on=?,status=? WHERE id=?', (cutoff, 'For Release', ident))
                    import json
                    db.execute('INSERT INTO coe_audit(transaction_id,username,event,old_json,new_json) VALUES (?,?,?,?,?)', (ident,session['username'],'FO receipt confirmed',json.dumps({'received_back_ro_on':row.get('received_back_ro_on'),'status':row.get('status')}),json.dumps({'received_back_ro_on':cutoff,'status':'For Release'})))
                db.execute('''CREATE TABLE IF NOT EXISTS fo_receipt_confirmations
                    (transaction_id INTEGER PRIMARY KEY, username TEXT NOT NULL,
                     office TEXT NOT NULL, received_on TEXT NOT NULL)''')
                db.execute('INSERT INTO fo_receipt_confirmations VALUES (?,?,?,?) ON CONFLICT(transaction_id) DO UPDATE SET username=excluded.username,office=excluded.office,received_on=excluded.received_on',
                           (ident, session['username'], office, cutoff))
                flash('Receipt confirmed. Date Received Back from RO: ' + cutoff)
        return redirect(url_for('fo_receipt_records', system=system))
