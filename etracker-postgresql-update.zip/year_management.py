"""Persistent reporting-year choices for SPELS and COE."""
import json
from flask import request, session, redirect, url_for, abort, flash
from fo_access import fo_office


def configured_years(db, module='spels'):
    return {row[0] for row in db.execute('SELECT year FROM reporting_year_choices WHERE module=?', (module,))}


def coe_year_choices(path, rows, selected=''):
    import database as sqlite3
    from datetime import datetime
    from zoneinfo import ZoneInfo
    # SPELS and COE retain separate choices in the main database.
    from flask import current_app
    with sqlite3.connect(current_app.config['YEAR_CHOICES_DB']) as db:
        years = configured_years(db, 'coe')
    today = datetime.now(ZoneInfo('Asia/Manila')).year
    years.update((today, today + 1))
    years.update(int(r['received_on'][:4]) for r in rows if r['received_on'])
    if selected:
        years.add(int(selected))
    return [str(y) for y in sorted(years, reverse=True)]


def register_year_management(app, conn, login_required):
    with conn() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS reporting_year_choices (
            module TEXT NOT NULL CHECK(module IN ('spels','coe')),
            year INTEGER NOT NULL CHECK(year BETWEEN 1900 AND 9998),
            added_by TEXT NOT NULL, added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(module,year))''')
        app.config['YEAR_CHOICES_DB'] = db.execute('PRAGMA database_list').fetchone()[2]

    @app.post('/reporting-years/add')
    @login_required
    def add_reporting_year():
        if fo_office():
            abort(403, 'Reporting years are managed by the Regional Office.')
        module = request.form.get('module')
        raw = request.form.get('year', '').strip()
        if module not in ('spels', 'coe') or not raw.isdecimal() or not 1900 <= int(raw) <= 9998:
            abort(400, 'Enter a year from 1900 to 9998.')
        year = int(raw)
        with conn() as db:
            result = db.execute('INSERT OR IGNORE INTO reporting_year_choices(module,year,added_by) VALUES (?,?,?)',
                                (module, year, session['username']))
        flash(f'{year} added to {"COE" if module == "coe" else "SPELS"} year choices.' if result.rowcount else f'{year} is already in the year choices.')
        endpoint = request.form.get('return_endpoint', '')
        allowed = {'dashboard','transactions','ipmr','processors_report','export_page','coe_dashboard','coe_transactions'}
        if endpoint not in allowed or endpoint not in app.view_functions:
            endpoint = 'coe_dashboard' if module == 'coe' else 'dashboard'
        if (endpoint.startswith('coe_')) != (module == 'coe'):
            endpoint = 'coe_dashboard' if module == 'coe' else 'dashboard'
        return redirect(url_for(endpoint, year=year))

    @app.after_request
    def add_year_controls(response):
        if fo_office():
            return response
        if request.endpoint not in ('dashboard', 'coe_dashboard'):
            return response
        if not session.get('username') or response.mimetype != 'text/html' or response.status_code != 200:
            return response
        if response.headers.get('Content-Disposition'):
            return response
        module = 'coe' if request.path.startswith('/coe') else 'spels'
        payload = json.dumps({'url':url_for('add_reporting_year'), 'csrf':session.get('csrf',''),
                              'module':module, 'endpoint':request.endpoint, 'scope':request.args.get('scope','year')}).replace('<', '\\u003c')
        script = '''<script id="reporting-year-controls">
(()=>{const settings=PAYLOAD;
if(settings.module==='spels' && ['month','day'].includes(settings.scope)) return;
document.querySelectorAll('select[name="year"]').forEach(select=>{
 const box=document.createElement('span'); box.style.cssText='display:flex;gap:8px;align-items:center;flex-wrap:wrap';
 select.parentNode.insertBefore(box,select);box.appendChild(select);
 const button=document.createElement('button');button.type='button';button.className='no-print';button.textContent='Add Year';box.appendChild(button);
 button.addEventListener('click',()=>{
  const dialog=document.createElement('dialog');dialog.style.cssText='border:1px solid #e7e3ec;border-radius:18px;padding:24px;max-width:400px';
  const form=document.createElement('form');form.method='post';form.action=settings.url;
  const title=document.createElement('h2');title.textContent='Add Year — '+(settings.module==='coe'?'COE':'SPELS');form.appendChild(title);
  for(const [name,value] of Object.entries({_csrf:settings.csrf,module:settings.module,return_endpoint:settings.endpoint})){
   const input=document.createElement('input');input.type='hidden';input.name=name;input.value=value;form.appendChild(input);
  }
  const label=document.createElement('label');label.textContent='Year';const input=document.createElement('input');input.type='number';input.name='year';input.min='1900';input.max='9998';input.step='1';input.required=true;
  const values=[...select.options].map(o=>Number(o.value)).filter(v=>v>=1900&&v<9998);input.value=String(Math.max(new Date().getFullYear(),...values)+1);label.appendChild(input);form.appendChild(label);
  const actions=document.createElement('p');const save=document.createElement('button');save.type='submit';save.textContent='Save Year';actions.appendChild(save);
  const cancel=document.createElement('button');cancel.type='button';cancel.textContent='Cancel';cancel.style.marginLeft='8px';cancel.onclick=()=>dialog.close();actions.appendChild(cancel);form.appendChild(actions);
  dialog.appendChild(form);document.body.appendChild(dialog);dialog.addEventListener('close',()=>dialog.remove());dialog.showModal();input.focus();input.select();
 });
});})();</script>'''.replace('PAYLOAD',payload)
        text = response.get_data(as_text=True)
        if '</body>' in text:
            response.set_data(text.replace('</body>', script + '</body>', 1))
        return response
