import os as _database_environment
if _database_environment.getenv('ETRACKER_DATABASE_URL'):
    raise RuntimeError('This legacy maintenance tool is SQLite-only. Use a reviewed PostgreSQL migration; no records were changed.')
import json,sqlite3,sys,subprocess,re
from pathlib import Path
root=Path(__file__).resolve().parent
path=(Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()/'etracker.db').resolve()
subprocess.run([sys.executable,str(root/'apply_date_update.py'),str(path)],check=True)
patches=json.loads((root/'existing-corrections.json').read_text());entries=json.loads((root/'new-records.json').read_text());skips=[];corrected=added=0
with sqlite3.connect(path,timeout=30) as db:
 db.row_factory=sqlite3.Row;db.execute('BEGIN IMMEDIATE')
 for p in patches:
  ref=p['reference'];r=db.execute('select * from transactions where reference=?',(ref,)).fetchone()
  if not r and 'reference' in p['new']:r=db.execute('select * from transactions where reference=?',(p['new']['reference'],)).fetchone()
  if r and all(r[k]==v for k,v in p['new'].items()):continue
  if not r or any(r[k]!=v for k,v in p['old'].items()):skips.append([ref,'Existing values changed since upload']);continue
  db.execute('update transactions set '+','.join(k+'=?' for k in p['new'])+' where id=?',list(p['new'].values())+[r['id']]);db.execute('insert into audit(transaction_id,username,event) values(?,?,?)',(r['id'],'excel-reconciliation',json.dumps(p)));corrected+=1
 for entry in entries:
  d=entry['data'];seq=re.findall(r'\d+',d['reference'])[-1];existing=db.execute('select reference from transactions where category=?',(d['category'],)).fetchall()
  if any(re.findall(r'\d+',r[0])[-1]==seq for r in existing):continue
  keys=list(d);cur=db.execute('insert into transactions ('+','.join(keys)+') values ('+','.join('?' for _ in keys)+')',list(d.values()));db.execute('insert into audit(transaction_id,username,event) values(?,?,?)',(cur.lastrowid,'excel-new-records',entry['raw_json']));added+=1
 for cat in ('HGE','CSE-PR','Other'):
  nums=[int(re.findall(r'\d+',r[0])[-1]) for r in db.execute('select reference from transactions where category=?',(cat,))]
  db.execute('update reference_counters set last_number=max(last_number,?) where category=?',(max(nums,default=0),cat))
 if db.execute('pragma integrity_check').fetchone()[0]!='ok':raise RuntimeError('Integrity check failed')
(root/'Excel-Install-Skipped.json').write_text(json.dumps(skips,indent=2))
print('New records:',added,'Existing corrections:',corrected,'Skipped corrections:',len(skips))
