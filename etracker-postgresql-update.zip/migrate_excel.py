"""Preview Excel migration; --apply imports validated rows after a SQLite backup.
Run while eTracker is stopped. No Excel file is changed. See MIGRATION.md.
"""
import os as _database_environment
if _database_environment.getenv('ETRACKER_DATABASE_URL'):
    raise RuntimeError('This legacy maintenance tool is SQLite-only. Use a reviewed PostgreSQL migration; no records were changed.')
import argparse
import csv
import hashlib
import json
import sqlite3
from collections import Counter
from datetime import date, datetime
from pathlib import Path

import openpyxl
import app as tracker

SHEETS = {'CSE PR 2026':'CSE-PR', 'Honor Grad 2026':'HGE', 'Others 2026':'Other'}
# Scoped to the exact supplied workbook; no blanket year replacement.
CORRECTION_SOURCE_SHA256 = '24fe57ed936f87d4573e2f096a169900755911c55471c4a303a113d6fda68d6e'
CORRECTIONS = {
    ('Honor Grad 2026',191): ('first_date', '4/8/0206', '2026-04-08', 'Year typo; month/day match receipt and the 2026 log.'),
    ('Honor Grad 2026',610): ('first_date', '6/15/0226', '2026-06-15', 'Year typo; month/day match receipt/action and the 2026 log.'),
    ('Honor Grad 2026',412): ('released_fo_on', '`', None, 'Stray character removed; date remains unknown, not N/A. Original retained in remarks.'),
    **{('Others 2026',r): ('received_on','#VALUE!','2026-08-10','Original Excel serial 6693657 represents August 10, 20226. Year normalized to the 2026 log.') for r in range(135,140)}
}

SOURCES = {'WI':'Walk-In','Isa':'ISAFO','NV':'NVFO','Qno':'QFO','Bat':'BATFO'}

def text(value):
    return '' if value is None else str(value).strip()

def day(value, field, problems, required=False):
    if value is None or text(value).upper() in ('','N/A','NA'):
        if required: problems.append(field+': missing date')
        return None
    if isinstance(value,datetime): return value.date().isoformat()
    if isinstance(value,date): return value.isoformat()
    try:
        return date.fromisoformat(text(value)).isoformat()
    except ValueError:
        problems.append(field+': invalid date '+text(value))
        return None

def read_workbook(path):
    wb=openpyxl.load_workbook(path,read_only=True,data_only=True)
    formula=openpyxl.load_workbook(path,read_only=True,data_only=False)
    apply_corrections = hashlib.sha256(Path(path).read_bytes()).hexdigest() == CORRECTION_SOURCE_SHA256
    accepted=[]; review=[]; controls=[]; holidays=[]
    for sheet,category in SHEETS.items():
        for number,(row,frow) in enumerate(zip(wb[sheet].iter_rows(min_row=4,max_col=18,values_only=True),formula[sheet].iter_rows(min_row=4,max_col=18,values_only=True)),4):
            # Ignore empty formatting/formula rows, retain batches without applicant names.
            is_hge=category=='HGE'
            if is_hge and not any(text(row[i]) for i in (2,3,4,7,8)):
                continue  # Ignore the separate reference lookup table below the transaction log.
            if not any(text(row[i]) for i in ([1,2,3,8] if is_hge else [0,4 if category=='CSE-PR' else 5])): continue
            problems=[]; corrections=[]
            d={k:'' for k in tracker.FIELDS}
            d.update(category=category,quantity=1,released_fo_na=0,received_back_na=0)
            if is_hge:
                received,quantity,school,source,ref_from,ref_to,eligibility,applicant,first,first_date,second,acted,action,release_fo,release_client,back,remarks=row[1:18]
                try:
                    if isinstance(quantity,bool) or float(quantity)!=int(quantity) or int(quantity)<1: raise ValueError()
                    d['quantity']=int(quantity)
                except (ValueError,TypeError,OverflowError): problems.append('Invalid number of applications')
                applicant=text(applicant) or ('Batch: '+text(school) if school else '')
                subtype=''
            else:
                received=row[0]; source=row[2];ref_from=row[3];ref_to=row[4] if category=='Other' else ref_from
                applicant=row[4] if category=='CSE-PR' else row[5]
                eligibility=row[6]; first,first_date,second,acted,action,release_fo,back,release_client,remarks=row[7:16]
                subtype=({'JOCOSC6':'','MUP':'MUP'}.get(text(row[1]),'') if category=='CSE-PR' else text(eligibility))
                school=''
                if subtype and subtype not in tracker.SUBTYPES[category]: problems.append('Unknown subtype: '+subtype)
            d.update(source=SOURCES.get(text(source),text(source)),subtype=subtype,applicant=text(applicant),eligibility=text(eligibility),first_processor=text(first),second_processor=text(second))
            if d['source'] not in tracker.OFFICE_SOURCES: problems.append('Office/source needs mapping: '+text(source))
            if not d['applicant']: problems.append('Missing applicant or batch school')
            for key,value in [('received_on',received),('first_date',first_date),('acted_on',acted),('released_fo_on',release_fo),('received_back_on',back),('released_client_on',release_client)]:
                fix=CORRECTIONS.get((sheet,number)) if apply_corrections else None
                if fix and key==fix[0] and text(value)==fix[1]:
                    corrections.append(dict(field=key,original=text(value),corrected=fix[2],basis=fix[3]))
                    value=fix[2]
                d[key]=day(value,key,problems,key=='received_on')
            for key,value in [('released_fo_na',release_fo),('received_back_na',back)]:d[key]=int(text(value).upper() in ('NA','N/A'))
            d['action']={a.lower():a for a in tracker.ACTIONS}.get(text(action).lower(),'Pending' if not text(action) else '')
            if not d['action']: problems.append('Unknown action: '+text(action))
            if d['action'] in tracker.FINAL_ACTIONS and not d['acted_on']: problems.append('Final action without date')
            if d['action']=='Pending' and d['acted_on']: problems.append('Action date without action status')
            if d['received_on'] and d['acted_on'] and d['acted_on']<d['received_on']: problems.append('Action precedes receipt')
            raw=json.dumps(row,default=str,ensure_ascii=False)
            key=f'{sheet}:{number}'
            d['reference']=f'XL-{category}-{text(ref_from) or "ROW"}-{text(ref_to) or "ROW"}-R{number}'
            # Preserve original columns (including exam date, school and IDs) losslessly in import_history/raw archive.
            remarks_col=17 if is_hge else 15
            original_note='' if isinstance(frow[remarks_col],str) and frow[remarks_col].startswith('=') else text(remarks)
            d['remarks']=original_note+f' [Excel: {sheet}, row {number}; original reference {text(source)} {text(ref_from)}–{text(ref_to)}'+(f'; school {school}' if school else '')+']'
            if corrections:
                d['remarks'] += ' [Import correction: '+ '; '.join(f"{c['field']}: {c['original']} -> {c['corrected'] or 'unknown'} ({c['basis']})" for c in corrections)+']'
            record=dict(corrections=corrections,source_key=key,sheet=sheet,row_number=number,reasons='; '.join(problems),raw_json=raw,digest=hashlib.sha256(raw.encode()).hexdigest(),data=d)
            (review if problems else accepted).append(record)
    for row in wb['List of Holidays 2026'].iter_rows(min_row=2,max_col=3,values_only=True):
        problems=[]; value=day(row[0],'holiday',problems)
        if value and not problems: holidays.append((value,text(row[2]) or 'Excel holiday'))
    s=wb['DashBoard-for IPMR']
    # Cached source totals only: the workbook is not recalculated or modified.
    for category,rows in [('CSE-PR',(3,9,10,23)),('HGE',(4,11,12,24)),('Other',(5,13,14,25))]:
        for metric,r in zip(('received','within','beyond','pending'),rows):
            for month in range(1,13):controls.append((category,metric,month,s.cell(r,month+3).value))
    manual=[]
    for category,rows in [('Other',(40,46,52,59)),('CSE-PR',(41,47,53,60)),('MUP',(42,48,54,61)),('HGE',(43,49,55,62))]:
        for metric,r in zip(('received','within','beyond','pending'),rows):
            for month in range(1,13):manual.append((category,metric,month,s.cell(r,month+3).value))
    wb.close();formula.close()
    return accepted,review,holidays,controls,manual

def safe(value):
    if isinstance(value,(int,float)) and not isinstance(value,bool): return value
    value=text(value)
    return "'"+value if value.startswith(('=','+','-','@','\t','\r')) else value

def write_csv(path,header,rows):
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(header)
        for row in rows:w.writerow([safe(v) for v in row])

def preview(path,out):
    accepted,review,holidays,controls,manual=read_workbook(path)
    out.mkdir(parents=True,exist_ok=True)
    write_csv(out/'review.csv',['Sheet','Excel row','Reason','Applications','Applicant / batch','Original data'],[(r['sheet'],r['row_number'],r['reasons'],r['data']['quantity'],r['data']['applicant'],r['raw_json']) for r in review])
    write_csv(out/'corrections.csv',['Sheet','Excel row','Field','Original','Corrected','Basis'],[(r['sheet'],r['row_number'],c['field'],c['original'],c['corrected'],c['basis']) for r in accepted+review for c in r['corrections']])
    # Full source provenance is retained even for rejected rows.
    (out/'source-archive.json').write_text(json.dumps(accepted+review,ensure_ascii=False,indent=2),encoding='utf-8')
    hs={h[0] for h in holidays};computed=Counter()
    for item in accepted:
        d=item['data'];q=d['quantity'];c=d['category'];received=date.fromisoformat(d['received_on'])
        if received.year==2026:computed[c,'received',received.month]+=q
        if d['action'] in tracker.FINAL_ACTIONS and d['acted_on']:
            acted=date.fromisoformat(d['acted_on']);days=tracker.business_days(d['received_on'],d['acted_on'],hs)
            if acted.year==2026:computed[c,'within' if days<=20 else 'beyond',acted.month]+=q
        for m in range(1,13):
            end=date(2026,m,tracker.calendar.monthrange(2026,m)[1]).isoformat()
            if d['received_on']<=end and (d['action'] not in tracker.FINAL_ACTIONS or not d['acted_on'] or d['acted_on']>end): computed[c,'pending',m]+=q
    # Blank IPMR totals represent zero only where source formulas intentionally emit an empty string.
    controls=[(c,k,m,0 if v=='' or v is None else v) for c,k,m,v in controls]
    write_csv(out/'ipmr-reconciliation.csv',['Category','Metric','Month','Excel upper dashboard cached','Validated import only','Difference (import minus Excel)'],[(c,k,m,v,computed[c,k,m],computed[c,k,m]-v if isinstance(v,(int,float)) else 'Source not numeric') for c,k,m,v in controls])
    write_csv(out/'ipmr-manual-reference.csv',['Category/subtype','Metric','Month','Excel lower manual section cached'],manual)
    summary={'source':path.name,'candidate_rows':len(accepted)+len(review),'ready_rows':len(accepted),'ready_applications':sum(r['data']['quantity'] for r in accepted),'review_rows':len(review),'corrected_rows':sum(bool(r['corrections']) for r in accepted+review),'holidays':len(holidays),'by_category':{c:{'ready_rows':sum(r['data']['category']==c for r in accepted),'ready_applications':sum(r['data']['quantity'] for r in accepted if r['data']['category']==c),'review_rows':sum(r['data']['category']==c for r in review)} for c in tracker.CATEGORIES}}
    (out/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    return accepted,review,holidays,summary

def apply(accepted,review,holidays):
    if not tracker.DB.is_file():raise RuntimeError('Start eTracker once first to create your database and admin account.')
    stamp=datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup=tracker.DB.with_name('etracker-before-import-'+stamp+'.db')
    with sqlite3.connect(tracker.DB) as source,sqlite3.connect(backup) as dest:source.backup(dest)
    tracker.init_db()
    added=skipped=conflicts=0
    with tracker.conn() as db:
        db.execute('BEGIN IMMEDIATE')
        # Remove only the previously flagged whitespace-only row from the exact baseline workbook.
        blank=db.execute("SELECT raw_json FROM import_review WHERE source_key='Others 2026:295'").fetchone()
        if blank:
            raw=json.loads(blank[0])
            if not any(text(raw[i]) for i in (0,5)):
                db.execute("DELETE FROM import_review WHERE source_key='Others 2026:295'")
        for r in review:
            # A correction saved in the web app resolves this exact source snapshot.
            # Re-importing the unchanged Excel must not undo or re-open that correction.
            old=db.execute('SELECT digest FROM import_history WHERE source_key=?',(r['source_key'],)).fetchone()
            if old and old['digest']==r['digest']:
                db.execute('DELETE FROM import_review WHERE source_key=?',(r['source_key'],))
                skipped+=1
                continue
            db.execute('INSERT OR REPLACE INTO import_review VALUES (?,?,?,?,?)',tuple(r[k] for k in ('source_key','sheet','row_number','reasons','raw_json')))
        for r in accepted:
            old=db.execute('SELECT digest FROM import_history WHERE source_key=?',(r['source_key'],)).fetchone()
            if old and old[0]==r['digest']:skipped+=1;continue
            d=r['data']
            duplicate=db.execute("SELECT id FROM transactions WHERE reference=? OR (applicant=? AND received_on=? AND category=? AND source=? AND ? NOT LIKE 'Batch: %')",(d['reference'],d['applicant'],d['received_on'],d['category'],d['source'],d['applicant'])).fetchone()
            if old or duplicate:
                db.execute('INSERT OR REPLACE INTO import_review VALUES (?,?,?,?,?)',(r['source_key'],r['sheet'],r['row_number'],'Existing record or changed source row: review before merging',r['raw_json']))
                conflicts+=1;continue
            cur=db.execute('INSERT INTO transactions ('+','.join(tracker.FIELDS)+') VALUES ('+','.join('?' for _ in tracker.FIELDS)+')',tuple(d[k] for k in tracker.FIELDS))
            db.execute('INSERT INTO import_history VALUES (?,?,?)',(r['source_key'],r['digest'],cur.lastrowid))
            db.execute('DELETE FROM import_review WHERE source_key=?',(r['source_key'],))
            db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',(cur.lastrowid,'excel-import',r['source_key']))
            added+=1
        db.executemany('INSERT OR IGNORE INTO holidays(day,label) VALUES (?,?)',holidays)
        active_review=db.execute('SELECT sheet,row_number,reasons,raw_json FROM import_review ORDER BY sheet,row_number').fetchall()
    review_dir=Path(__file__).parent/'migration'/'review'
    review_dir.mkdir(parents=True,exist_ok=True)
    write_csv(review_dir/'database-review.csv',['Sheet','Excel row','Reason','Original data'],active_review)
    return dict(imported=added,already_imported=skipped,conflicts=conflicts,backup=backup.name)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('workbook',nargs='?',default=str(Path(__file__).parent/'migration'/'source.xlsx'))
    parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    out=Path(__file__).parent/'migration'/'review'
    accepted,review,holidays,summary=preview(Path(args.workbook),out)
    print(json.dumps(summary,indent=2))
    if args.apply:
        result=apply(accepted,review,holidays)
        (out/'last-import.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        print(json.dumps(result,indent=2))
    else:print('PREVIEW ONLY. No database changed. See migration/review. Use --apply to import validated rows.')
