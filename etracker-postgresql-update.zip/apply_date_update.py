"""Patakbuhin sa folder ng kasalukuyang etracker.db. Dates lang ang ina-update."""
import os as _database_environment
if _database_environment.getenv('ETRACKER_DATABASE_URL'):
    raise RuntimeError('This legacy maintenance tool is SQLite-only. Use a reviewed PostgreSQL migration; no records were changed.')
import json, sqlite3, sys
from pathlib import Path
from datetime import datetime
root=Path(__file__).resolve().parent
path=Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()/'etracker.db'
if not path.exists():raise SystemExit('Hindi makita ang etracker.db. Ilagay ang update files sa program folder.')
changes=json.loads((root/'date-changes.json').read_text())
with sqlite3.connect(path,timeout=30) as db:
 db.row_factory=sqlite3.Row
 backup=path.with_name('etracker-before-date-update-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.db')
 with sqlite3.connect(backup) as dest:db.backup(dest)
 db.execute('BEGIN IMMEDIATE');count=0;skips=[]
 for c in changes:
  r=db.execute('SELECT * FROM transactions WHERE reference=?',(c['reference'],)).fetchone()
  if not r or r['applicant']!=c['applicant'] or r['category']!=c['category'] or r['source']!=c['source']:
   skips.append((c['reference'],'Record identity mismatch'));continue
  if r['received_on']==c['received_on'] and r['received_ro_on']==c['received_ro_on']:continue
  if r['received_on']!=c['old_received_on'] or r['received_ro_on']!=c['old_received_ro_on']:
   skips.append((c['reference'],'Dates changed after the uploaded database'));continue
  db.execute('UPDATE transactions SET received_on=?,received_ro_on=? WHERE id=?',(c['received_on'],c['received_ro_on'],r['id']))
  db.execute('INSERT INTO audit(transaction_id,username,event) VALUES(?,?,?)',(r['id'],'excel-date-update',json.dumps(c)));count+=1
 if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Database integrity check failed')
(root/'Install-Skipped.json').write_text(json.dumps(skips,indent=2))
print('Updated:',count,'Skipped:',len(skips),'Backup:',backup)
