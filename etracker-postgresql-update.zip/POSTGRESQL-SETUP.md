# PostgreSQL setup for an office PC

This is an update to the supplied eTracker project, not a complete application. Install the previous UI update first if it is not already installed. The same eTracker accounts and passwords are copied during migration. PostgreSQL's database password is a separate credential.

## 1. Prepare and back up

Choose one office PC as the central server. Stop every running eTracker process. Make a complete backup of your existing project, including `etracker.db`, `coe.db`, and environment settings. Keep this backup unchanged. Do not encode new applications during migration.

Extract this update into the existing project folder, replacing its included source files. Do not delete the SQLite databases. No data or credentials are included in the update package.

Open Command Prompt in the existing project folder. Activate your existing Python virtual environment, then run:

```bat
python -m pip install -r requirements.txt
python -m unittest test_ui_flow -v
```

The four UI regression tests use temporary SQLite databases. They do not test or modify your live PostgreSQL database.

## 2. Install PostgreSQL on the server PC

Use the official Windows download page: https://www.postgresql.org/download/windows/

Install PostgreSQL 17 or a newer supported release, including pgAdmin and command-line tools. Use the default database port 5432 unless your PC already uses it. Remember the installation's administrator password securely. Stack Builder add-ons are not needed for eTracker. Validation of this update used PostgreSQL 17.11.

In pgAdmin, connect to your local PostgreSQL server. Under Login/Group Roles, create a role named `etracker_app`:

- Set a strong password in the Definition tab.
- Enable Can login.
- Leave Superuser, Create roles, and Create databases disabled.

Under Databases, create an EMPTY database named `etracker`, with `etracker_app` as Owner. Do not use the server's `postgres` administrator account for running eTracker.

Keep PostgreSQL listening on the server PC's loopback address. Other office PCs need access to eTracker, not direct database access. No paid cloud service is needed for this local setup.

## 3. Migrate the existing records

From the project folder, with the app still stopped:

```bat
python launch_postgres.py migrate
```

Enter the default host `127.0.0.1`, port `5432`, database `etracker`, username `etracker_app`, and the database password when prompted. The password is hidden and is not saved by the launcher. Do not paste passwords into chat.

The migration reads SQLite in read-only transactions, copies both databases into separate PostgreSQL schemas, preserves account password hashes and audit history, resets ID sequences, and compares all imported source fields. It refuses a nonempty target. Copying and verification are committed together; a verification failure rolls back the data import. Empty schema setup may remain after a failed migration.

Wait for `Migration complete` and inspect the row counts in `postgres-migration-report.json`. If migration fails, do not keep retrying against the same destination without checking the cause. Preserve your SQLite backup.

If your database files have different names, pass explicit paths:

```bat
python launch_postgres.py migrate --sqlite-main "C:\path\etracker.db" --sqlite-coe "C:\path\coe.db"
```

Then check connectivity:

```bat
python launch_postgres.py check
```

## 4. Start and check on the server PC

```bat
python launch_postgres.py run
```

Enter the same database connection details. Open the local application on the PC using the selected app port (5000 by default). Sign in with an EXISTING eTracker account. Check SPELS and COE totals, reports, and representative applications before allowing new entries.

The launcher uses Waitress with eight worker threads, not Flask's development server. It retains a private session key in `.postgres-local`; do not distribute that folder or include it in GitHub. If your existing ETRACKER_SECRET_KEY is set, it is reused.

PostgreSQL is selected only when `ETRACKER_DATABASE_URL` is present in the process. The launcher sets it for that process. Running the old `python app.py` command without this setting still selects SQLite. After cutover, use the PostgreSQL launcher consistently so staff do not split records across databases.

## 5. Enable office-network users

After the local checks, stop the app with Ctrl+C and start:

```bat
python launch_postgres.py run --host 0.0.0.0 --port 5000
```

Use `ipconfig` on the central PC to find its office-network IPv4 address. Other staff open the central PC's address with port 5000 in their browsers. Allow the app port in Windows Firewall only for the intended private office network. Do not expose PostgreSQL's port to staff PCs or open it to the internet. The central PC must stay powered on. For access outside a trusted local network, configure HTTPS and an approved access method before deployment.

## 6. Backups and rollback

After migration, SQLite copies no longer receive updates. Back up PostgreSQL regularly. In PostgreSQL's command-line tools directory (or with that directory on PATH), use:

```bat
pg_dump -h 127.0.0.1 -U etracker_app -d etracker -Fc -f "D:\eTrackerBackups\etracker-backup.dump"
```

Choose a real backup directory first. The command prompts for the database password. Store dumps privately because they contain office records and password hashes. Test restoring into a SEPARATE empty database with `pg_restore --no-owner --no-privileges --exit-on-error`. pgAdmin can also create and restore custom-format backups.

Before any new PostgreSQL entries, rollback means stopping the PostgreSQL-backed app and restoring the previous source and SQLite backup. After staff have encoded new PostgreSQL data, do not switch back to SQLite without a data-reconciliation/export plan; the old files no longer contain those new entries.

Historical SQLite patch and Excel-reconciliation scripts are blocked when PostgreSQL is selected. They require their own reviewed PostgreSQL conversion. The normal app screens, COE import route, and CSV exports use the selected backend. Direct SQLite maintenance scripts are not PostgreSQL migration tools.

## Developer validation

Nine PostgreSQL integration tests cover login/pages, ten concurrent SPELS saves, ten concurrent COE saves, COPI/date triggers, Field Office scope/guards, review resolution, stale-edit rejection, rollback, and refusal to overwrite a nonempty migration target. Run separately with `ETRACKER_TEST_DATABASE_URL` pointing to a NEW EMPTY dedicated test database:

```bat
python -m unittest test_postgres -v
```

Do not set that variable to your live database. Tests refuse a nonempty target but create test records in the selected empty database. Tests were run against real PostgreSQL, and migration plus backup/restore were checked with a non-superuser database owner. Repeat deployment checks on the actual office PC before staff use it.
