"""Integration tests. Use an EMPTY dedicated database, never the live database.

Set ETRACKER_TEST_DATABASE_URL, then run: python -m unittest test_postgres -v
Tests refuse a nonempty destination. Run in its own Python process.
"""
import os
import secrets
import unittest
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch


@unittest.skipUnless(os.getenv('ETRACKER_TEST_DATABASE_URL'), 'Set an empty dedicated ETRACKER_TEST_DATABASE_URL')
class PostgresTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import psycopg
        cls.password = secrets.token_urlsafe(24)
        cls.url = os.environ['ETRACKER_TEST_DATABASE_URL']
        if cls.url == os.getenv('ETRACKER_DATABASE_URL'):
            raise RuntimeError('Test URL must be separate from the application URL.')
        with psycopg.connect(cls.url) as db:
            tables = db.execute("SELECT table_schema,table_name FROM information_schema.tables WHERE table_schema IN ('etracker_main','etracker_coe') AND table_name <> 'schema_version'").fetchall()
            from psycopg import sql
            for schema,table in tables:
                if db.execute(sql.SQL('SELECT 1 FROM {}.{} LIMIT 1').format(sql.Identifier(schema),sql.Identifier(table))).fetchone():
                    raise RuntimeError('Refusing to run tests on a nonempty database.')
        cls.environment = patch.dict(os.environ,{'ETRACKER_DATABASE_URL':cls.url,'ETRACKER_ADMIN_PASSWORD':cls.password,'ETRACKER_SECRET_KEY':secrets.token_urlsafe(32)})
        cls.environment.start()
        import app
        cls.tracker = app
        app.app.config['TESTING']=True
        app.init_db()
        app.init_db()
        from werkzeug.security import generate_password_hash
        with app.conn() as db:
            for username,role in [('pg-fo','staff'),('pg-first','first_verifier')]:
                db.execute('INSERT INTO users(username,password_hash,role) VALUES (?,?,?)',(username,generate_password_hash(cls.password),role))
            db.execute("INSERT INTO fo_accounts(username,office_source,created_by) VALUES ('pg-fo','ISAFO','admin')")
            db.execute("INSERT INTO ro_account_profiles(username,display_name,created_by) VALUES ('pg-first','Test First Verifier','admin')")

    @classmethod
    def tearDownClass(cls):
        cls.environment.stop()

    def client(self, username='admin'):
        client=self.tracker.app.test_client()
        with client.session_transaction() as session:
            session.update(username=username,csrf='integration-token')
        return client

    def record(self, reference, source='Walk-In', **extra):
        data=dict(reference=reference,category='Other',subtype='BOE',source=source,received_on=self.tracker.local_today().isoformat(),applicant=reference)
        data.update(extra)
        with self.tracker.conn() as db:
            return db.execute('INSERT INTO transactions ('+','.join(data)+') VALUES ('+','.join('?' for _ in data)+')',tuple(data.values())).lastrowid

    def test_actual_login_and_pages(self):
        client=self.tracker.app.test_client();client.get('/login')
        with client.session_transaction() as session:token=session['csrf']
        self.assertEqual(client.post('/login',data={'username':'admin','password':self.password,'_csrf':token}).status_code,302)
        for path in ['/','/transactions','/coe','/coe/new','/transactions/new','/report.csv','/ipmr','/priority','/processors','/admin/logs','/admin/logs?start=2026-01-01']:
            self.assertEqual(client.get(path).status_code,200,path)

    def test_ten_simultaneous_spels_saves(self):
        def save(number):
            return self.client().post('/transactions/new',data={'_csrf':'integration-token','category':'HGE','source':'Walk-In','applicant':f'Concurrent SPELS {number}','received_on':self.tracker.local_today().isoformat(),'quantity':'1'}).status_code
        with ThreadPoolExecutor(max_workers=10) as pool:
            results=list(pool.map(save,range(10)))
        self.assertEqual(results,[302]*10)
        with self.tracker.conn() as db:
            rows=db.execute("SELECT reference FROM transactions WHERE applicant LIKE 'Concurrent SPELS %'").fetchall()
        self.assertEqual(len(rows),10)
        self.assertEqual(len({r[0] for r in rows}),10)

    def test_ten_simultaneous_coe_saves(self):
        def save(number):
            return self.client().post('/coe/new',data={'_csrf':'integration-token','source':'Walk-In','received_on':self.tracker.local_today().isoformat(),'eligible_name':f'Concurrent COE {number}','coe_copies':'1','auth_copies':'0','status':'Pending'}).status_code
        with ThreadPoolExecutor(max_workers=10) as pool:
            results=list(pool.map(save,range(10)))
        self.assertEqual(results,[302]*10)
        from coe_monitor import connect
        with connect(self.tracker.app.config['COE_DB']) as db:
            rows=db.execute("SELECT reference FROM coe_transactions WHERE eligible_name LIKE 'Concurrent COE %'").fetchall()
        self.assertEqual(len(rows),10)
        self.assertEqual(len({r[0] for r in rows}),10)

    def test_copi_history_and_generated_year(self):
        ident=self.record('PG-COPI')
        with self.tracker.conn() as db:
            db.execute("UPDATE transactions SET action='Pending',pending_status='For COPI' WHERE id=?",(ident,))
            self.assertEqual(db.execute('SELECT count(*) FROM copi_pauses WHERE transaction_id=? AND resumed_on IS NULL',(ident,)).fetchone()[0],1)
            db.execute("UPDATE transactions SET pending_status='For COPI' WHERE id=?",(ident,))
            self.assertEqual(db.execute('SELECT count(*) FROM copi_events WHERE transaction_id=?',(ident,)).fetchone()[0],1)
            db.execute("UPDATE transactions SET action='On Process',pending_status='' WHERE id=?",(ident,))
            self.assertIsNotNone(db.execute('SELECT resumed_on FROM copi_pauses WHERE transaction_id=?',(ident,)).fetchone()[0])
            db.execute("UPDATE transactions SET received_on='2025-01-01' WHERE id=?",(ident,))
            self.assertEqual(db.execute('SELECT reporting_year FROM transactions WHERE id=?',(ident,)).fetchone()[0],2025)
            db.execute("UPDATE transactions SET action='Approved',second_date='2025-01-03' WHERE id=?",(ident,))
            self.assertEqual(db.execute('SELECT acted_on FROM transactions WHERE id=?',(ident,)).fetchone()[0],'2025-01-03')

    def test_field_office_scope_and_guard(self):
        self.record('PG-ISA-VISIBLE','ISAFO')
        ident=self.record('PG-QFO-HIDDEN','QFO')
        client=self.client('pg-fo')
        response=client.get('/transactions?year=')
        self.assertEqual(response.status_code,200)
        html=response.get_data(as_text=True)
        self.assertIn('PG-ISA-VISIBLE',html);self.assertNotIn('PG-QFO-HIDDEN',html)
        self.assertEqual(client.get(f'/transactions/{ident}/edit').status_code,404)
        import database
        with self.tracker.app.test_request_context('/'):
            from flask import session
            session['username']='pg-fo'
            with self.assertRaises(database.IntegrityError):
                with self.tracker.conn() as db:
                    db.execute("UPDATE transactions SET remarks='unauthorized' WHERE id=?",(ident,))

    def test_review_resolution_keeps_history(self):
        import hashlib,json
        raw=json.dumps(['']*16)
        with self.tracker.conn() as db:
            db.execute('INSERT INTO import_review(source_key,sheet,row_number,reasons,raw_json) VALUES (?,?,?,?,?)',
                ('pg-review-source','Others 2026',999,'Synthetic review',raw))
        response=self.client().post('/review/pg-review-source',data={
            '_csrf':'integration-token','_source_digest':hashlib.sha256(raw.encode()).hexdigest(),
            'category':'Other','subtype':'BOE','source':'Walk-In','applicant':'PG REVIEW TEST',
            'received_on':self.tracker.local_today().isoformat(),'quantity':'1'})
        self.assertEqual(response.status_code,302)
        with self.tracker.conn() as db:
            self.assertIsNone(db.execute("SELECT 1 FROM import_review WHERE source_key='pg-review-source'").fetchone())
            self.assertIsNotNone(db.execute("SELECT transaction_id FROM import_history WHERE source_key='pg-review-source'").fetchone())
            self.assertEqual(db.execute("SELECT raw_json FROM import_resolutions WHERE source_key='pg-review-source'").fetchone()[0],raw)

    def test_same_record_concurrent_edits_reject_stale_version(self):
        from ro_accounts import fingerprint
        ident=self.record('PG-VERSION-CHECK')
        with self.tracker.conn() as db:
            row=dict(db.execute('SELECT * FROM transactions WHERE id=?',(ident,)).fetchone())
        version=fingerprint(row)
        def save(number):
            return self.client('pg-first').post(f'/work/spels/{ident}',data={
                '_csrf':'integration-token','version':version,'operation':'save',
                'first_action':'On Process','first_verifier_remarks':f'Review {number}'}).status_code
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(save,range(2)))
        self.assertEqual(sorted(results),[302,409])

    def test_migration_refuses_nonempty_destination(self):
        import sqlite3,tempfile
        from pathlib import Path
        from migrate_postgres import migrate
        with tempfile.TemporaryDirectory() as directory:
            main=Path(directory)/'main.db';coe=Path(directory)/'coe.db'
            with sqlite3.connect(main) as source:
                source.execute('CREATE TABLE transactions(id INTEGER PRIMARY KEY)')
            with sqlite3.connect(coe) as source:
                source.execute('CREATE TABLE coe_transactions(id INTEGER PRIMARY KEY)')
            with self.assertRaisesRegex(RuntimeError,'not empty'):
                migrate(main,coe)

    def test_rollback_and_failed_record_is_not_saved(self):
        with self.assertRaises(ValueError):
            with self.tracker.conn() as db:
                db.execute("INSERT INTO holidays(day,label) VALUES ('2099-01-01','Rollback test')")
                raise ValueError('Abort this transaction')
        with self.tracker.conn() as db:
            self.assertIsNone(db.execute("SELECT 1 FROM holidays WHERE day='2099-01-01'").fetchone())
        response=self.client().post('/transactions/new',data={'_csrf':'integration-token','category':'Other','subtype':'BOE','source':'Walk-In','received_on':'bad-date','applicant':'MUST NOT SAVE'})
        self.assertEqual(response.status_code,200)
        with self.tracker.conn() as db:
            self.assertIsNone(db.execute("SELECT 1 FROM transactions WHERE applicant='MUST NOT SAVE'").fetchone())


if __name__=='__main__':
    unittest.main()
