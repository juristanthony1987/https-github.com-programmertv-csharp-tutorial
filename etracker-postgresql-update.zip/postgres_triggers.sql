-- PostgreSQL equivalents of the application date, COPI, and office guards.
SET LOCAL search_path TO etracker_main, public;
CREATE OR REPLACE FUNCTION etracker_main.fo_normalize_office(value text) RETURNS text
LANGUAGE sql IMMUTABLE AS $$
 SELECT CASE lower(trim(coalesce(value,'')))
 WHEN 'isa' THEN 'ISAFO' WHEN 'isafo' THEN 'ISAFO' WHEN 'isabela' THEN 'ISAFO'
 WHEN 'nv' THEN 'NVFO' WHEN 'nvfo' THEN 'NVFO'
 WHEN 'qno' THEN 'QFO' WHEN 'qn' THEN 'QFO' WHEN 'qfo' THEN 'QFO' WHEN 'quirino' THEN 'QFO'
 WHEN 'bat' THEN 'BATFO' WHEN 'batfo' THEN 'BATFO' WHEN 'batanes' THEN 'BATFO'
 ELSE trim(coalesce(value,'')) END;
$$;
CREATE OR REPLACE FUNCTION etracker_main.fo_review_office(sheet text, raw_json text) RETURNS text
LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
 RETURN etracker_main.fo_normalize_office((raw_json::jsonb)->>(CASE WHEN sheet='Honor Grad 2026' THEN 4 ELSE 2 END));
EXCEPTION WHEN invalid_text_representation THEN RETURN '';
END;
$$;
CREATE OR REPLACE FUNCTION etracker_coe.fo_normalize_office(value text) RETURNS text
LANGUAGE sql IMMUTABLE AS $$ SELECT etracker_main.fo_normalize_office(value); $$;
CREATE OR REPLACE FUNCTION etracker_coe.fo_review_office(sheet text, raw_json text) RETURNS text
LANGUAGE sql IMMUTABLE AS $$ SELECT etracker_main.fo_review_office(sheet, raw_json); $$;
CREATE OR REPLACE FUNCTION etracker_main.guard_office_write() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE office text := current_setting('etracker.office', true);
BEGIN
 IF coalesce(office,'') <> '' THEN
  IF TG_OP <> 'INSERT' AND etracker_main.fo_normalize_office(OLD.source) <> office THEN
   RAISE EXCEPTION 'Field Office access denied' USING ERRCODE='23514';
  END IF;
  IF TG_OP <> 'DELETE' AND etracker_main.fo_normalize_office(NEW.source) <> office THEN
   RAISE EXCEPTION 'Field Office access denied' USING ERRCODE='23514';
  END IF;
 END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; ELSE RETURN NEW; END IF;
END;
$$;
CREATE TRIGGER fo_guard BEFORE INSERT OR UPDATE OR DELETE ON etracker_main.transactions
 FOR EACH ROW EXECUTE FUNCTION etracker_main.guard_office_write();
CREATE TRIGGER fo_guard BEFORE INSERT OR UPDATE OR DELETE ON etracker_coe.coe_transactions
 FOR EACH ROW EXECUTE FUNCTION etracker_main.guard_office_write();

CREATE OR REPLACE FUNCTION etracker_main.processor_dates() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  NEW.second_date := coalesce(nullif(NEW.second_date,''), nullif(NEW.acted_on,''));
 END IF;
 NEW.acted_on := CASE WHEN NEW.action IN ('','Received','Pending','FOR REVIEW','On Process','Return to FO')
  THEN NULL ELSE nullif(NEW.second_date,'') END;
 RETURN NEW;
END;
$$;
CREATE TRIGGER processor_dates BEFORE INSERT OR UPDATE OF second_date,action,acted_on ON etracker_main.transactions
 FOR EACH ROW EXECUTE FUNCTION etracker_main.processor_dates();

CREATE OR REPLACE FUNCTION etracker_main.copi_before() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE entering boolean := NEW.action='Pending' AND NEW.pending_status='For COPI';
BEGIN
 IF TG_OP='UPDATE' THEN
  entering := entering AND NOT (OLD.action='Pending' AND OLD.pending_status='For COPI');
 END IF;
 IF entering THEN
  NEW.copi_tagged_at := to_char(CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Manila','YYYY-MM-DD HH24:MI:SS');
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER copi_before BEFORE INSERT OR UPDATE OF action,pending_status ON etracker_main.transactions
 FOR EACH ROW EXECUTE FUNCTION etracker_main.copi_before();
CREATE OR REPLACE FUNCTION etracker_main.copi_history() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE
 entering boolean := NEW.action='Pending' AND NEW.pending_status='For COPI';
 leaving boolean := false;
 today text := to_char(CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Manila','YYYY-MM-DD');
BEGIN
 IF TG_OP='UPDATE' THEN
  entering := entering AND NOT (OLD.action='Pending' AND OLD.pending_status='For COPI');
  leaving := OLD.action='Pending' AND OLD.pending_status='For COPI' AND NOT (NEW.action='Pending' AND NEW.pending_status='For COPI');
 END IF;
 IF entering THEN
  INSERT INTO etracker_main.copi_events(transaction_id,tagged_at) VALUES(NEW.id,NEW.copi_tagged_at);
  INSERT INTO etracker_main.copi_pauses(transaction_id,started_on) VALUES(NEW.id,today);
  INSERT INTO etracker_main.audit(transaction_id,username,event)
   VALUES(NEW.id,'copi-clock','Counting paused - Undergoing COPI; tagging day counted: ' || today);
 ELSIF leaving THEN
  UPDATE etracker_main.copi_pauses SET resumed_on=greatest(started_on,today) WHERE transaction_id=NEW.id AND resumed_on IS NULL;
  INSERT INTO etracker_main.audit(transaction_id,username,event)
   VALUES(NEW.id,'copi-clock','Counting resumed - COPI tag removed: ' || today);
 END IF;
 RETURN NEW;
END;
$$;
CREATE TRIGGER copi_history AFTER INSERT OR UPDATE OF action,pending_status ON etracker_main.transactions
 FOR EACH ROW EXECUTE FUNCTION etracker_main.copi_history();
