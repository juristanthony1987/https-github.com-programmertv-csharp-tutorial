#!/usr/bin/env bash
# Local cloud development only: private Unix socket, no TCP database listener.
set -euo pipefail
project_root="/workspace/projects/etracker2026(New)"
pg_tools=/workspace/postgres-tools
pg_bin="$pg_tools/root/usr/lib/postgresql/17/bin"
pg_data=/workspace/postgres-data
pg_socket=/workspace/postgres-socket
if [ ! -x "$pg_bin/postgres" ]; then
  mkdir -p "$pg_tools/lists/partial" "$pg_tools/cache/archives/partial"
  cat > "$pg_tools/sources.list" <<'EOF'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
EOF
  apt_options=(-o Dir::Etc::main=/dev/null -o "Dir::Etc::parts=$pg_tools/no-config" -o "Dir::Etc::sourcelist=$pg_tools/sources.list" -o "Dir::Etc::sourceparts=$pg_tools/no-sources" -o "Dir::State::lists=$pg_tools/lists" -o "Dir::Cache=$pg_tools/cache")
  /usr/bin/apt-get "${apt_options[@]}" update
  (cd "$pg_tools" && /usr/bin/apt-get "${apt_options[@]}" download postgresql-17 postgresql-client-17)
  for package in "$pg_tools"/postgresql-17_*.deb "$pg_tools"/postgresql-client-17_*.deb; do
    dpkg-deb -x "$package" "$pg_tools/root"
  done
fi
mkdir -p "$pg_socket"
chmod 700 "$pg_socket"
if [ ! -f "$pg_data/PG_VERSION" ]; then
  "$pg_bin/initdb" -D "$pg_data" --auth-local=trust --auth-host=scram-sha-256 --no-locale -E UTF8
fi
if ! "$pg_bin/pg_ctl" -D "$pg_data" status >/dev/null 2>&1; then
  "$pg_bin/pg_ctl" -D "$pg_data" -l "$pg_data/server.log" -o "-k $pg_socket -p 55432 -c listen_addresses=" start
fi
if [ "$("$pg_bin/psql" -h "$pg_socket" -p 55432 -d postgres -tAc "SELECT count(*) FROM pg_roles WHERE rolname='etracker_dev_app'")" = 0 ]; then
  "$pg_bin/createuser" -h "$pg_socket" -p 55432 --no-superuser --no-createdb --no-createrole etracker_dev_app
fi
if [ "$("$pg_bin/psql" -h "$pg_socket" -p 55432 -d postgres -tAc "SELECT count(*) FROM pg_database WHERE datname='etracker_dev'")" = 0 ]; then
  "$pg_bin/createdb" -h "$pg_socket" -p 55432 -O etracker_dev_app etracker_dev
fi
pg_users_table=$("$pg_bin/psql" -h "$pg_socket" -p 55432 -U etracker_dev_app -d etracker_dev -tAc "SELECT to_regclass('etracker_main.users')")
pg_users=0
if [ -n "$pg_users_table" ]; then
  pg_users=$("$pg_bin/psql" -h "$pg_socket" -p 55432 -U etracker_dev_app -d etracker_dev -tAc 'SELECT count(*) FROM etracker_main.users')
fi
if [ "$pg_users" = 0 ]; then
  mkdir -p /workspace/etracker-runtime
  cd "$project_root"
  ETRACKER_DATABASE_URL='postgresql://etracker_dev_app@/etracker_dev?host=/workspace/postgres-socket&port=55432' \
    /workspace/etracker-venv/bin/python migrate_postgres.py --report /workspace/etracker-runtime/postgres-dev-migration-report.json
fi
