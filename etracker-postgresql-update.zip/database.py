"""Database boundary for legacy SQLite queries and native PostgreSQL connections.

Set ETRACKER_DATABASE_URL to select PostgreSQL. Without it, SQLite is unchanged.
Only the application's documented SQLite SQL forms are adapted; schema and
trigger definitions are maintained explicitly in postgres_*.sql.
"""
import os
import re
import sqlite3 as _sqlite
import threading
from pathlib import Path

Row = _sqlite.Row
Error = _sqlite.Error
try:
    import psycopg
except ImportError:
    psycopg = None
IntegrityError = psycopg.IntegrityError if psycopg and os.getenv('ETRACKER_DATABASE_URL') else _sqlite.IntegrityError
OperationalError = psycopg.OperationalError if psycopg and os.getenv('ETRACKER_DATABASE_URL') else _sqlite.OperationalError
_ready = set()
_setup_lock = threading.Lock()


def postgres_enabled():
    return bool(os.getenv('ETRACKER_DATABASE_URL'))


def ensure_initialized():
    """Install versioned schema once; never run the historical SQLite backfills."""
    if not postgres_enabled():
        return
    if psycopg is None:
        raise RuntimeError('Install PostgreSQL dependencies with pip install -r requirements.txt.')
    url = os.environ['ETRACKER_DATABASE_URL']
    with _setup_lock:
        if url in _ready:
            return
        with psycopg.connect(url, connect_timeout=10) as db:
            db.execute("SELECT pg_advisory_xact_lock(hashtext('etracker:schema:v1'))")
            exists = db.execute("SELECT to_regclass('etracker_main.schema_version')").fetchone()[0]
            if exists:
                version = db.execute('SELECT version FROM etracker_main.schema_version').fetchone()
                if not version or version[0] != 1:
                    raise RuntimeError('Unsupported PostgreSQL schema version; run the matching migration.')
            else:
                # Existing unversioned tables are not upgraded implicitly.
                if db.execute("SELECT to_regclass('etracker_main.transactions')").fetchone()[0]:
                    raise RuntimeError('Unversioned PostgreSQL schema found; use an empty dedicated database.')
                base = Path(__file__).resolve().parent
                db.execute((base / 'postgres_schema.sql').read_text(), prepare=False)
                db.execute((base / 'postgres_triggers.sql').read_text(), prepare=False)
                db.execute('CREATE TABLE etracker_main.schema_version(version INTEGER PRIMARY KEY)')
                db.execute('INSERT INTO etracker_main.schema_version VALUES (1)')
        _ready.add(url)


class Record:
    """Name and positional access, matching the SQLite Row API used by the app."""
    def __init__(self, names, values):
        self._names = names
        self._values = tuple(values)
    def keys(self):
        return self._names
    def __getitem__(self, key):
        return self._values[self._names.index(key)] if isinstance(key, str) else self._values[key]
    def __iter__(self):
        return iter(self._values)
    def __len__(self):
        return len(self._values)


class Cursor:
    def __init__(self, connection, raw=None, rows=None, names=(), rowcount=None, lastrowid=None):
        self.connection, self.raw = connection, raw
        self.rows = iter(rows) if rows is not None else None
        self.names = list(names) if rows is not None else [c.name for c in (raw.description or ())]
        self.rowcount = raw.rowcount if rowcount is None and raw else (rowcount or 0)
        self.lastrowid = lastrowid
    def fetchone(self):
        row = next(self.rows, None) if self.rows is not None else self.raw.fetchone()
        if row is None:
            return None
        return Record(self.names, row) if self.connection.row_factory else tuple(row)
    def fetchall(self):
        return list(self)
    def __iter__(self):
        while True:
            row = self.fetchone()
            if row is None:
                return
            yield row


class PostgresConnection:
    is_postgres = True
    def __init__(self, path, timeout=30):
        ensure_initialized()
        self.path = str(path)
        main = Path(os.getenv('ETRACKER_DB', str(Path(__file__).parent / 'etracker.db'))).resolve()
        coe = Path(os.getenv('COE_DB', str(Path(__file__).parent / 'coe.db'))).resolve()
        selected = Path(path).resolve()
        if selected not in (main, coe):
            raise RuntimeError('Unknown database path. Configure ETRACKER_DB / COE_DB logical database paths.')
        self.schema = 'etracker_coe' if selected == coe else 'etracker_main'
        self.raw = psycopg.connect(os.environ['ETRACKER_DATABASE_URL'], connect_timeout=10)
        self.raw.execute(f'SET search_path TO {self.schema}, public')
        self.raw.execute("SELECT set_config('lock_timeout', %s, false)", (str(int(timeout * 1000)),))
        self.raw.execute("SET statement_timeout TO '60s'")
        self.raw.execute("SET TIME ZONE 'UTC'")
        self.raw.commit()
        self.row_factory = None
        self._lastrowid = None
        self._write_transaction = False
        self._id_tables = {r[0] for r in self.raw.execute(
            "SELECT table_name FROM information_schema.columns WHERE table_schema=%s AND column_name='id' AND is_identity='YES'", (self.schema,))}
        self.raw.commit()
    def __enter__(self):
        return self
    def __exit__(self, kind, value, traceback):
        try:
            self.raw.rollback() if kind else self.raw.commit()
        finally:
            self.raw.close()
    def close(self):
        self.raw.close()
    def commit(self):
        self.raw.commit()
        self._write_transaction = False
    def rollback(self):
        self.raw.rollback()
        self._write_transaction = False
    def create_function(self, name, number, function):
        if name not in ('fo_normalize_office', 'fo_review_office'):
            raise NotImplementedError('Unsupported SQL function: ' + name)
        # Equivalent schema-local SQL functions are installed by schema migration.
    def guard_office(self, office):
        self.raw.execute("SELECT set_config('etracker.office', %s, true)", (office,))
    def reserve_category(self, category):
        self.raw.execute('INSERT INTO reference_counters(category,last_number) VALUES (%s,0) ON CONFLICT DO NOTHING', (category,))
        self.raw.execute('SELECT last_number FROM reference_counters WHERE category=%s FOR UPDATE', (category,)).fetchone()
    def execute(self, sql, parameters=()):
        text = sql.strip().rstrip(';')
        pragma = re.fullmatch(r'PRAGMA\s+table_(?:x?info)\((\w+)\)', text, re.I)
        if pragma:
            table = pragma[1]
            rows = self.raw.execute('''SELECT ordinal_position-1,column_name,data_type,
                CASE WHEN is_nullable='NO' THEN 1 ELSE 0 END,column_default,0,
                CASE WHEN is_generated='ALWAYS' THEN 2 ELSE 0 END
                FROM information_schema.columns WHERE table_schema=%s AND table_name=%s ORDER BY ordinal_position''', (self.schema, table)).fetchall()
            return Cursor(self, rows=rows, names=['cid','name','type','notnull','dflt_value','pk','hidden'])
        if text.upper() == 'PRAGMA DATABASE_LIST':
            return Cursor(self, rows=[(0, 'main', self.path)], names=['seq','name','file'])
        if text.upper() in ('PRAGMA FOREIGN_KEYS=ON','PRAGMA JOURNAL_MODE=WAL'):
            return Cursor(self, rows=[], names=[])
        if text.upper() == 'BEGIN IMMEDIATE':
            self._write_transaction = True
            return Cursor(self, rows=[], names=[])
        if text.lower() == 'select last_insert_rowid()':
            return Cursor(self, rows=[(self._lastrowid,)], names=['id'])
        if 'sqlite_master' in text:
            text = text.replace('sqlite_master', 'information_schema.tables')
            text = re.sub(r"type\s*=\s*'table'", 'table_schema=current_schema()', text)
            text = re.sub(r'\bname\b', 'table_name', text)
        text = text.replace('main.', self.schema + '.')
        text = re.sub(r'\s+COLLATE NOCASE', '', text, flags=re.I)
        text = re.sub(r"date\(stamp,\s*'\+8 hours'\)", "to_char(stamp::timestamp + interval '8 hours', 'YYYY-MM-DD')", text, flags=re.I)
        ignore = bool(re.match(r'INSERT OR IGNORE\b', text, re.I))
        if ignore:
            text = re.sub(r'^INSERT OR IGNORE', 'INSERT', text, flags=re.I) + ' ON CONFLICT DO NOTHING'
        # Parameterize outside string literals, preserving ? and % in stored text.
        parts = re.split(r"('(?:''|[^'])*')", text)
        text = ''.join(re.sub(r'\bLIKE\b', 'ILIKE', part, flags=re.I).replace('%','%%').replace('?', '%s') if i % 2 == 0 else part.replace('%','%%') for i, part in enumerate(parts))
        table = re.match(r'INSERT INTO\s+(\w+)\b', text, re.I)
        returning = table and table[1] in self._id_tables and 'RETURNING' not in text.upper()
        if returning:
            text += ' RETURNING id'
        if self._write_transaction and re.match(r'SELECT\s+\*\s+FROM\s+(transactions|coe_transactions)\s+WHERE\s+id\s*=', text, re.I):
            text += ' FOR UPDATE'
        cursor = self.raw.execute(text, parameters)
        last = None
        if returning:
            result = cursor.fetchone()
            last = result[0] if result else None
            self._lastrowid = last
            return Cursor(self, rows=[], names=[], rowcount=cursor.rowcount, lastrowid=last)
        return Cursor(self, raw=cursor)
    def executemany(self, sql, parameters):
        result = None
        for values in parameters:
            result = self.execute(sql, values)
        return result
    def executescript(self, sql):
        # Registration-time DDL is already installed in the canonical schema.
        # No trigger SQL or arbitrary SQLite script is silently ignored.
        if 'CREATE TRIGGER' in sql.upper() or 'PRAGMA' in sql.upper():
            raise NotImplementedError('Use the PostgreSQL schema migration for triggers.')
        for statement in sql.split(';'):
            if statement.strip():
                self.execute(statement)


def connect(path, timeout=30, **kwargs):
    if not postgres_enabled():
        return _sqlite.connect(path, timeout=timeout, **kwargs)
    return PostgresConnection(path, timeout=timeout)


def lock_record(db, table, ident):
    """Lock one record before the existing authorization/version checks."""
    columns = {'transactions': 'id', 'coe_transactions': 'id', 'import_review': 'source_key'}
    if table not in columns:
        raise ValueError('Unsupported record table.')
    if getattr(db, 'is_postgres', False):
        column = columns[table]
        db.raw.execute('SELECT '+column+' FROM '+db.schema+'.'+table+' WHERE '+column+'=%s FOR UPDATE', (ident,)).fetchone()
