from workflow_actions import received_action
"""Mga alert para sa FO records na hindi pa acknowledged ng RO."""
import calendar
import csv
import io
from datetime import date
from flask import abort, flash, redirect, render_template, request, Response, session, url_for
from fo_access import scoped_select, normalize_office, fo_office

LABEL = 'To Be Received by RO'

def needs_ro_receipt(row, cutoff=None):
    # BATFO at Walk-In ay walang applicable RO handoff dates sa kasalukuyang form.
    aliases = {'isa': 'isafo', 'isabela': 'isafo', 'nv': 'nvfo',
               'qn': 'qfo', 'qno': 'qfo', 'quirino': 'qfo'}
    source = str(row.get('source') or '').strip().casefold()
    source = aliases.get(source, source)
    explicit_bat = normalize_office(row.get('source')) == 'BATFO' and row.get('fo_transmitted_ro') == 'Yes'
    if source not in ('isafo', 'nvfo', 'qfo') and not explicit_bat:
        return False
    received = str(row.get('received_on') or '').strip()
    cutoff = cutoff or date.today().isoformat()
    if not received or received > cutoff:
        return False
    # Bagong FO workflow: Yes lang ang maaaring mag-trigger ng RO receipt alert.
    # Panatilihin ang dating behavior ng legacy records at COE.
    transmission = row.get('fo_transmitted_ro')
    if transmission:
        sent = str(row.get('fo_transmitted_ro_on') or '')
        if transmission != 'Yes' or not sent or sent > cutoff:
            return False
    acknowledged = str(row.get('received_ro_on') or '').strip()
    return not acknowledged or acknowledged > cutoff

def register_ro_receipt_alerts(app, main):
    today = main['local_today']

    @app.post('/ro-receipt-alerts/spels/<int:ident>/confirm')
    @main['login_required']
    def ro_receipt_confirm(ident):
        if not main['can_manage_ro']():
            abort(403, 'Only RO Admin can confirm receipt.')
        cutoff = main['local_today']().isoformat()
        with main['conn']() as db:
            db.execute('BEGIN IMMEDIATE')
            from database import lock_record
            lock_record(db, 'transactions', ident)
            row = db.execute('SELECT * FROM transactions WHERE id=?', (ident,)).fetchone()
            if row is None:
                abort(404)
            row = dict(row)
            if row.get('received_ro_on'):
                flash('RO receipt was already recorded. The original date and action are retained.')
            else:
                if not needs_ro_receipt(row, cutoff):
                    abort(409, 'This record is not awaiting receipt by RO.')
                # Panatilihin ang On Process, compliance, COPI at final decisions.
                action = received_action(row['action'])
                db.execute('UPDATE transactions SET received_ro_on=?,received_ro_by=?,action=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',
                           (cutoff, session['username'], action, ident))
                db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',
                           (ident, session['username'], 'RO receipt confirmed: ' + cutoff + '; Action: ' + action))
                flash('RO receipt confirmed. Date Received by RO: ' + cutoff + '. Action: ' + action)
        if request.form.get('open_record') == '1':
            return redirect(url_for('edit_transaction', ident=ident))
        return redirect(url_for('ro_receipt_records', system='spels'))

    def selected_records(system):
        if system == 'spels':
            report = main['build_report']()
            rows = report['received']
            cutoff = report['cutoff']
            period = report['period_display']
        elif system == 'coe':
            from coe_monitor import connect
            year = request.args.get('year', '')
            month = request.args.get('month', '')
            day = request.args.get('day', '')
            source = request.args.get('source', '')
            if year and (not year.isdigit() or not 1900 <= int(year) <= 9999):
                abort(400, 'Invalid year')
            if month and (not month.isdigit() or not 1 <= int(month) <= 12):
                abort(400, 'Invalid month')
            if day and (not day.isdigit() or not 1 <= int(day) <= 31):
                abort(400, 'Invalid day')
            if year and month and day:
                try:
                    date(int(year), int(month), int(day))
                except ValueError:
                    abort(400, 'Invalid date')
            if source and source not in ('Walk-In','ISAFO','NVFO','QFO','BATFO'):
                abort(400, 'Invalid source')
            cutoff = today().isoformat()
            with connect(app.config['COE_DB']) as db:
                rows = [dict(r) for r in scoped_select(db, 'SELECT * FROM coe_transactions WHERE received_on<=? ORDER BY received_on,id', (cutoff,))]
            rows = [r for r in rows if (not year or r['received_on'][:4] == year)
                    and (not month or r['received_on'][5:7] == month.zfill(2))
                    and (not day or r['received_on'][8:10] == day.zfill(2))
                    and (not source or normalize_office(r['source']) == source)]
            period = ' / '.join(x for x in (year, calendar.month_name[int(month)] if month else '', day) if x) or 'All dates'
        else:
            abort(404)
        rows = [dict(r) for r in rows if needs_ro_receipt(dict(r), cutoff)]
        for row in rows:
            row['receipt_alert'] = LABEL
            try:
                row['receipt_wait_days'] = max(0, (date.fromisoformat(cutoff) - date.fromisoformat(row['received_on'])).days)
            except ValueError:
                row['receipt_wait_days'] = None
        rows.sort(key=lambda r: (r['received_on'], r['id']))
        return rows, period, cutoff

    def total_for(system, rows):
        return sum(int(r.get('quantity') or 1) for r in rows) if system == 'spels' else len(rows)

    @app.context_processor
    def receipt_context():
        context = {'needs_ro_receipt': lambda row: needs_ro_receipt(dict(row), today().isoformat())}
        if session.get('username') and request.endpoint in ('dashboard', 'coe_dashboard'):
            system = 'coe' if request.endpoint == 'coe_dashboard' else 'spels'
            rows, period, cutoff = selected_records(system)
            args = request.args.to_dict()
            for key in ('page','q','download_csv'):
                args.pop(key, None)
            context['ro_receipt_card'] = dict(system=system, count=total_for(system, rows),
                records=len(rows), period=period, cutoff=cutoff,
                link=url_for('ro_receipt_records', system=system, **args))
        return context

    @app.get('/ro-receipt-alerts/<system>')
    @main['login_required']
    def ro_receipt_records(system):
        rows, period, cutoff = selected_records(system)
        q = request.args.get('q', '').strip()
        if q:
            rows = [r for r in rows if any(q.casefold() in str(r.get(k) or '').casefold()
                    for k in ('reference','applicant','eligible_name','source','category','remarks'))]
        total = total_for(system, rows)
        if request.args.get('download_csv'):
            keys = ['reference','applicant' if system=='spels' else 'eligible_name','source',
                    'received_on','received_ro_on','receipt_alert','receipt_wait_days']
            if system == 'spels':
                keys += ['category','quantity','action']
            else:
                keys += ['status','destination_fo']
            output = io.StringIO()
            writer = csv.writer(output)
            writer.writerow(keys)
            for r in rows:
                vals = [r.get(k, '') for k in keys]
                writer.writerow(["'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v for v in vals])
            return Response('\ufeff'+output.getvalue(), mimetype='text/csv',
                headers={'Content-Disposition': f'attachment; filename={system}-to-be-received-by-ro.csv'})
        try:
            page = max(1, int(request.args.get('page', 1)))
        except ValueError:
            abort(400, 'Invalid page')
        pages = max(1, (len(rows)+24)//25)
        page = min(page, pages)
        def link(**changes):
            args = request.args.to_dict()
            args.update(changes)
            return url_for('ro_receipt_records', system=system, **args)
        args = request.args.to_dict()
        for key in ('q','page','download_csv'):
            args.pop(key, None)
        back = url_for('dashboard' if system=='spels' else 'coe_dashboard', **args)
        return render_template('ro_receipt_records.html', system=system, rows=rows[(page-1)*25:page*25],
            period=period, cutoff=cutoff, total=total, records=len(rows), page=page, pages=pages,
            q=q, link=link, back=back,
            retained={k:v for k,v in args.items()}, csv_link=link(download_csv='1',page=1))
