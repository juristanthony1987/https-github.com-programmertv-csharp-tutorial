"""Copy both SQLite databases into an EMPTY dedicated PostgreSQL database.

Run with the app stopped and ETRACKER_DATABASE_URL set securely.
No SQLite files are modified. A nonempty destination is always refused.
"""
import argparse
import hashlib
import json
import os
import sqlite3
from contextlib import ExitStack
from pathlib import Path

import psycopg
from psycopg import sql
import database


def identifier(value):
    return sql.Identifier(value)


def digest_rows(rows):
    total = count = 0
    for row in rows:
        normalized = [v.hex() if isinstance(v, bytes) else v for v in row]
        payload = json.dumps(normalized, ensure_ascii=False, separators=(',', ':')).encode()
        total = (total + int.from_bytes(hashlib.sha256(payload).digest(), 'big')) % (1 << 256)
        count += 1
    return count, format(total, '064x')


def migrate(main_path, coe_path):
    if not database.postgres_enabled():
        raise RuntimeError('Set ETRACKER_DATABASE_URL before migration.')
    paths = [('etracker_main', Path(main_path).resolve()), ('etracker_coe', Path(coe_path).resolve())]
    if paths[0][1] == paths[1][1]:
        raise ValueError('SPELS and COE must use different SQLite source files.')
    # Open read-only snapshots before touching the target.
    with ExitStack() as stack:
        sources = []
        for schema, path in paths:
            if not path.is_file():
                raise FileNotFoundError('Missing SQLite source: ' + path.name)
            src = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
            stack.callback(src.close)
            src.execute('BEGIN')
            if src.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise RuntimeError('SQLite integrity check failed: ' + path.name)
            tables = [r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
            expected = 'transactions' if schema.endswith('main') else 'coe_transactions'
            if expected not in tables:
                raise RuntimeError('Wrong SQLite source database: ' + path.name)
            tables.sort(key=lambda n: (n not in ('transactions','coe_transactions'), n))
            sources.append((schema, src, tables))
        database.ensure_initialized()
        report = []
        with psycopg.connect(os.environ['ETRACKER_DATABASE_URL']) as dst:
            dst.execute("SELECT pg_advisory_xact_lock(hashtext('etracker:migration'))")
            existing = dst.execute("SELECT table_schema,table_name FROM information_schema.tables WHERE table_schema IN ('etracker_main','etracker_coe') AND table_type='BASE TABLE' AND table_name <> 'schema_version'").fetchall()
            for schema, table in sorted(existing):
                dst.execute(sql.SQL('LOCK TABLE {}.{} IN ACCESS EXCLUSIVE MODE').format(identifier(schema),identifier(table)))
                if dst.execute(sql.SQL('SELECT 1 FROM {}.{} LIMIT 1').format(identifier(schema),identifier(table))).fetchone():
                    raise RuntimeError('Destination is not empty. Use a new dedicated PostgreSQL database.')
            for schema, src, tables in sources:
                for table in tables:
                    qtable = sql.SQL('{}.{}').format(identifier(schema),identifier(table))
                    info = src.execute('PRAGMA table_xinfo(' + '"' + table.replace('"','""') + '"' + ')').fetchall()
                    columns = [r[1] for r in info if r[6] == 0]
                    available = {r[0] for r in dst.execute('SELECT column_name FROM information_schema.columns WHERE table_schema=%s AND table_name=%s', (schema,table))}
                    if not available:
                        # Preserve auxiliary/history tables without executing source DDL.
                        definitions = []
                        for col in info:
                            if col[6] != 0:
                                raise ValueError('Unsupported generated column in auxiliary table: ' + table)
                            kind = col[2].upper()
                            pgtype = 'BIGINT' if 'INT' in kind else 'DOUBLE PRECISION' if any(t in kind for t in ('REAL','FLOAT','DOUBLE')) else 'BYTEA' if 'BLOB' in kind else 'TEXT'
                            definitions.append(sql.SQL('{} {}').format(identifier(col[1]),sql.SQL(pgtype)))
                        primary = [r[1] for r in sorted(info, key=lambda c:c[5]) if r[5]]
                        if primary:
                            definitions.append(sql.SQL('PRIMARY KEY ({})').format(sql.SQL(',').join(map(identifier,primary))))
                        dst.execute(sql.SQL('CREATE TABLE {} ({})').format(qtable,sql.SQL(',').join(definitions)))
                        available = set(columns)
                    missing = set(columns) - available
                    if missing:
                        raise RuntimeError('Unsupported source columns in ' + table + ': ' + ', '.join(sorted(missing)))
                    dst.execute(sql.SQL('ALTER TABLE {} DISABLE TRIGGER USER').format(qtable))
                    # Retain IDs, password hashes, timestamps and complete audit histories.
                    select = 'SELECT ' + ','.join('"'+c.replace('"','""')+'"' for c in columns) + ' FROM "'+table.replace('"','""')+'"'
                    with dst.cursor().copy(sql.SQL('COPY {} ({}) FROM STDIN').format(qtable,sql.SQL(',').join(map(identifier,columns)))) as copy:
                        for row in src.execute(select):
                            copy.write_row(row)
                    dst.execute(sql.SQL('ALTER TABLE {} ENABLE TRIGGER USER').format(qtable))
                    # Verify every imported source field, including generated reporting years.
                    all_columns = [r[1] for r in info]
                    source_select = 'SELECT ' + ','.join('"'+c.replace('"','""')+'"' for c in all_columns) + ' FROM "'+table.replace('"','""')+'"'
                    original = digest_rows(src.execute(source_select))
                    imported = digest_rows(dst.execute(sql.SQL('SELECT {} FROM {}').format(sql.SQL(',').join(map(identifier,all_columns)),qtable)))
                    if original != imported:
                        raise RuntimeError('Data verification failed for ' + table)
                    identities = dst.execute("SELECT column_name FROM information_schema.columns WHERE table_schema=%s AND table_name=%s AND is_identity='YES'", (schema,table)).fetchall()
                    for (column,) in identities:
                        seq = dst.execute('SELECT pg_get_serial_sequence(%s,%s)', (schema+'.'+table,column)).fetchone()[0]
                        maximum = dst.execute(sql.SQL('SELECT max({}) FROM {}').format(identifier(column),qtable)).fetchone()[0]
                        dst.execute('SELECT setval(%s,%s,%s)', (seq,max(maximum or 1,1), maximum is not None))
                    report.append({'schema':schema,'table':table,'rows':original[0],'verified':True})
        return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sqlite-main', type=Path, default=Path(__file__).parent/'etracker.db')
    parser.add_argument('--sqlite-coe', type=Path, default=Path(__file__).parent/'coe.db')
    parser.add_argument('--report', type=Path, default=Path('postgres-migration-report.json'))
    args = parser.parse_args()
    if args.report.exists():
        parser.error('Report file exists; choose a new report filename.')
    try:
        report = migrate(args.sqlite_main,args.sqlite_coe)
    except Exception as error:
        # Avoid printing PostgreSQL diagnostics containing names or password hashes.
        print('Migration did not complete ('+type(error).__name__+'). No SQLite records were changed.')
        if isinstance(error,(RuntimeError,ValueError,FileNotFoundError)):
            print(str(error))
        raise SystemExit(1)
    args.report.write_text(json.dumps({'status':'verified','tables':report},indent=2))
    print('Migration committed. Verified',sum(r['rows'] for r in report),'rows across',len(report),'tables.')
    print('SQLite sources remain unchanged. Report:',args.report)


if __name__=='__main__':
    main()
