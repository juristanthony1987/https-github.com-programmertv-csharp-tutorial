"""Field Office access: scoped queries, guarded writes and admin-managed accounts."""
import json
import re
import database as sqlite3
from pathlib import Path
from flask import abort, current_app, g, has_request_context, request, session, flash, redirect, render_template, url_for
from werkzeug.security import generate_password_hash

OFFICES = ('ISAFO', 'NVFO', 'QFO', 'BATFO')
ALIASES = {'isa':'ISAFO','isafo':'ISAFO','isabela':'ISAFO','nv':'NVFO','nvfo':'NVFO',
           'qno':'QFO','qn':'QFO','qfo':'QFO','quirino':'QFO','bat':'BATFO','batfo':'BATFO','batanes':'BATFO'}

def normalize_office(value):
    return ALIASES.get(str(value or '').strip().casefold(), str(value or '').strip())

def review_office(sheet, raw_json):
    try:
        raw = json.loads(raw_json)
        idx = 4 if sheet == 'Honor Grad 2026' else 2
        return normalize_office(raw[idx])
    except (ValueError, TypeError, IndexError, KeyError):
        return ''  # Unattributed review rows remain with the Regional Office.

def fo_office():
    if not has_request_context() or not session.get('username'):
        return None
    if not hasattr(g, 'fo_office'):
        with sqlite3.connect(current_app.config['FO_MAIN_DB']) as db:
            row = db.execute('SELECT office_source FROM fo_accounts WHERE username=?', (session['username'],)).fetchone()
        g.fo_office = row[0] if row else None
        if g.fo_office and g.fo_office not in OFFICES:
            abort(403, 'Invalid Field Office assignment. Contact the Regional Office administrator.')
    return g.fo_office

def office_choices(values):
    office = fo_office()
    return (office,) if office else values

def scoped_select(db, sql, parameters=()):
    """Scope every record query before aggregating, searching or paginating.

    CTEs keep existing SQL aliases and bound parameters intact. RO queries are
    unchanged. Only trusted SELECT statements from the application call this.
    """
    office = fo_office()
    if not office:
        return db.execute(sql, parameters)
    if not sql.lstrip().upper().startswith('SELECT'):
        raise ValueError('scoped_select accepts SELECT statements only.')
    db.create_function('fo_normalize_office', 1, normalize_office)
    db.create_function('fo_review_office', 2, review_office)
    # office comes only from the database-backed whitelist above.
    definitions = {
        'transactions': f"SELECT * FROM main.transactions WHERE fo_normalize_office(source)='{office}'",
        'coe_transactions': f"SELECT * FROM main.coe_transactions WHERE fo_normalize_office(source)='{office}'",
        'import_review': f"SELECT * FROM main.import_review WHERE fo_review_office(sheet,raw_json)='{office}'",
        'import_resolutions': f"SELECT * FROM main.import_resolutions WHERE transaction_id IN (SELECT id FROM main.transactions WHERE fo_normalize_office(source)='{office}')",
        'import_history': f"SELECT * FROM main.import_history WHERE transaction_id IN (SELECT id FROM main.transactions WHERE fo_normalize_office(source)='{office}')",
        'exception_decisions': f"SELECT * FROM main.exception_decisions WHERE transaction_id IN (SELECT id FROM main.transactions WHERE fo_normalize_office(source)='{office}')",
    }
    used = [f'{table} AS ({body})' for table, body in definitions.items()
            if re.search(r'\b'+table+r'\b', sql, re.I)]
    return db.execute('WITH '+', '.join(used)+' '+sql if used else sql, parameters)

def guard_connection(db, table):
    office = fo_office()
    if not office:
        return db
    if getattr(db, 'is_postgres', False):
        db.guard_office(office)
        return db
    db.create_function('fo_normalize_office',1,normalize_office)
    # TEMP triggers exist only on the current application connection. Existing
    # SQLite triggers, reference counters and last_insert_rowid remain intact.
    for operation, condition in (
        ('INSERT',f"fo_normalize_office(NEW.source) != '{office}'"),
        ('UPDATE',f"fo_normalize_office(OLD.source) != '{office}' OR fo_normalize_office(NEW.source) != '{office}'"),
        ('DELETE',f"fo_normalize_office(OLD.source) != '{office}'")):
        db.execute(f'''CREATE TEMP TRIGGER IF NOT EXISTS fo_guard_{table}_{operation}
            BEFORE {operation} ON main.{table} WHEN {condition}
            BEGIN SELECT RAISE(ABORT,'Field Office access denied'); END''')
    return db

def register_fo_access(app, database_path, login_required, is_admin):
    app.config['FO_MAIN_DB'] = str(database_path)
    with sqlite3.connect(database_path) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS fo_accounts (
            username TEXT PRIMARY KEY COLLATE NOCASE,
            office_source TEXT NOT NULL CHECK(office_source IN ('ISAFO','NVFO','QFO','BATFO')),
            created_by TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')

    @app.before_request
    def enforce_fo_access():
        if request.endpoint == 'static': return
        office = fo_office()
        if not office: return
        if (request.path.startswith('/ipmr') or request.path.startswith('/holidays')
            or request.endpoint in ('coe_import_source','fo_accounts','exception_review','add_reporting_year','admin_logs')
            or (request.endpoint == 'dashboard_records' and (request.view_args or {}).get('metric') == 'holidays')):
            abort(403, 'This control is managed by the Regional Office.')
        if request.method == 'POST' and request.endpoint in ('new_transaction','edit_transaction','review_edit','coe_form'):
            submitted = request.form.get('source', '')
            if submitted and normalize_office(submitted) != office:
                abort(403, 'You can encode records only for your assigned Field Office.')
            data = request.form.to_dict(flat=False)
            data['source'] = [office]
            from werkzeug.datastructures import ImmutableMultiDict
            request.form = ImmutableMultiDict((k,v) for k,values in data.items() for v in values)
        if request.args.get('source') and normalize_office(request.args['source']) != office:
            abort(403, 'You can view records only for your assigned Field Office.')

    @app.context_processor
    def fo_context():
        office = fo_office()
        return {'fo_office':office}

    @app.route('/accounts/field-offices', methods=['GET','POST'])
    @login_required
    def fo_accounts():
        if fo_office() or not is_admin(): abort(403)
        if request.method == 'POST':
            username = request.form.get('username','').strip()
            password = request.form.get('password','')
            office = request.form.get('office_source','')
            action = request.form.get('action','create')
            if not re.fullmatch(r'[A-Za-z0-9_.-]{3,40}', username):
                flash('Use a username of 3–40 letters, digits, dots, underscores or hyphens.')
            elif len(password) < 8:
                flash('Use a password of at least 8 characters.')
            elif action not in ('create','reset'):
                abort(400)
            else:
                with sqlite3.connect(database_path) as db:
                    if action == 'reset':
                        exists = db.execute('SELECT 1 FROM fo_accounts WHERE username=?',(username,)).fetchone()
                        if not exists: abort(404)
                        db.execute('UPDATE users SET password_hash=? WHERE lower(username)=lower(?)', (generate_password_hash(password),username))
                        flash('Field Office password updated.')
                    elif office not in OFFICES:
                        flash('Choose a valid Field Office.')
                    elif db.execute('SELECT 1 FROM users WHERE lower(username)=lower(?)',(username,)).fetchone():
                        flash('Username already exists. Choose another username.')
                    else:
                        db.execute('INSERT INTO users(username,password_hash,role) VALUES (?,?,?)', (username,generate_password_hash(password),'staff'))
                        db.execute('INSERT INTO fo_accounts(username,office_source,created_by) VALUES (?,?,?)',(username,office,session['username']))
                        flash('Field Office account created.')
                return redirect(url_for('fo_accounts'))
        with sqlite3.connect(database_path) as db:
            db.row_factory = sqlite3.Row
            accounts = db.execute('SELECT username,office_source,created_at FROM fo_accounts ORDER BY office_source,username').fetchall()
        return render_template('fo_accounts.html', accounts=accounts, offices=OFFICES)
