"""Read-only, Admin-only audit history for SPELS and COE."""
import json
import database as sqlite3
from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo
from flask import abort, render_template, request, url_for
from fo_access import fo_office


def register_admin_logs(app, main):
    @app.get('/admin/logs')
    @main['login_required']
    def admin_logs():
        if fo_office() or not main['is_admin']():
            abort(403)
        system = request.args.get('system', 'spels')
        if system not in ('spels', 'coe'):
            abort(400)
        username = request.args.get('username', '').strip()
        query = request.args.get('q', '').strip()[:200]
        start, end = request.args.get('from', ''), request.args.get('to', '')
        for value in (start, end):
            if value:
                try: date.fromisoformat(value)
                except ValueError: abort(400, 'Invalid date filter.')
        if start and end and start > end: abort(400, 'Invalid date range.')
        try: page = max(1, int(request.args.get('page', 1)))
        except ValueError: abort(400)
        if system == 'spels':
            db = main['conn']()
            source = "SELECT a.id,a.transaction_id,a.username,a.event,a.happened_at AS stamp,t.reference,t.applicant AS applicant,'' AS old_json,'' AS new_json FROM audit a LEFT JOIN transactions t ON t.id=a.transaction_id"
        else:
            db = sqlite3.connect(app.config['COE_DB'])
            db.row_factory = sqlite3.Row
            source = 'SELECT a.id,a.transaction_id,a.username,a.event,a.created_at AS stamp,t.reference,t.eligible_name AS applicant,a.old_json,a.new_json FROM coe_audit a LEFT JOIN coe_transactions t ON t.id=a.transaction_id'
        where, args = [], []
        if username: where.append('username=?'); args.append(username)
        if query:
            where.append("(instr(lower(COALESCE(reference,'')),lower(?))>0 OR instr(lower(event),lower(?))>0 OR instr(lower(COALESCE(applicant,'')),lower(?))>0)")
            args.extend([query]*3)
        if start: where.append("date(stamp,'+8 hours')>=?"); args.append(start)
        if end: where.append("date(stamp,'+8 hours')<=?"); args.append(end)
        clause = ' WHERE '+' AND '.join(where) if where else ''
        try:
            users = [r[0] for r in db.execute('SELECT DISTINCT username FROM ('+source+') ORDER BY username')]
            total = db.execute('SELECT count(*) FROM ('+source+')'+clause, args).fetchone()[0]
            pages = max(1, (total+49)//50); page=min(page,pages)
            rows = [dict(r) for r in db.execute('SELECT * FROM ('+source+')'+clause+' ORDER BY stamp DESC,id DESC LIMIT 50 OFFSET ?', [*args,(page-1)*50])]
        finally: db.close()
        for row in rows:
            try:
                row['time_display'] = datetime.fromisoformat(row['stamp']).replace(tzinfo=timezone.utc).astimezone(ZoneInfo('Asia/Manila')).strftime('%b %d, %Y %I:%M:%S %p')
            except (ValueError,TypeError): row['time_display']=row['stamp'] or 'Unknown'
            row['changes']=[]
            row['event_label']=row['event'].split(':',1)[0]
            row['details']=row['event']
            try:
                if system == 'coe':
                    before=json.loads(row['old_json'] or '{}'); after=json.loads(row['new_json'] or '{}')
                    details={key:{'before':before.get(key),'after':value} for key,value in after.items() if before.get(key)!=value}
                else:
                    _, _, raw=row['event'].partition(': ')
                    details=json.loads(raw)
                labels={'fo_action':'First Processor Action','action':'Second Processor Action','first_date':'First Processor Date','second_date':'Second Processor Date','received_fo_by':'FO Receipt Account','received_ro_by':'RO Receipt Account'}
                for key, value in details.items():
                    change=value if isinstance(value,dict) and 'after' in value else {'before':None,'after':value}
                    if not isinstance(value,dict) and value in ('',None,0): continue
                    def display(v):
                        if key=='fo_action' and v=='Acted': return 'On Process'
                        return 'Blank' if v in ('',None) else str(v)
                    row['changes'].append({'field':labels.get(key,key.replace('_',' ').title()),'before':display(change.get('before')) if isinstance(value,dict) and 'before' in value else 'Not recorded','after':display(change.get('after'))})
                    if key in ('action','status') and change.get('after'):
                        row['event_label']+=' — '+str(change['after'])
                row['details']=''
            except (ValueError,TypeError,AttributeError): pass
        def link(number):
            params=request.args.to_dict();params['page']=number
            return url_for('admin_logs',**params)
        return render_template('admin_logs.html',rows=rows,system=system,users=users,username=username,query=query,start=start,end=end,total=total,page=page,pages=pages,previous=link(page-1),next_page=link(page+1))
