"""Merge authoritative references without deleting existing records or manual edits."""
import os as _database_environment
if _database_environment.getenv('ETRACKER_DATABASE_URL'):
    raise RuntimeError('This legacy maintenance tool is SQLite-only. Use a reviewed PostgreSQL migration; no records were changed.')
import json,re
from coe_monitor import connect,initialize,FIELDS,canonical_source

def lineage(r):
    key=r.get('source_key') or ''
    parts=key.rsplit(':',2)
    if len(parts)==3 and parts[1] in ('COEAUTH FROM FOs 2026','COEAUTH WALK-IN 2026') and parts[2].isdigit():return parts[1],int(parts[2])
    return None

def sync(baseline,target):
    initialize(target)
    with connect(baseline) as db:source=[dict(r) for r in db.execute('SELECT * FROM coe_transactions ORDER BY id')];sequences=list(db.execute('SELECT * FROM coe_sequences'))
    refs={r['reference']:r for r in source};by_lineage={lineage(r):r for r in source if lineage(r)}
    with connect(target) as db:
        db.execute('BEGIN IMMEDIATE');existing=[dict(r) for r in db.execute('SELECT * FROM coe_transactions')];matches={};used=set()
        for old in existing:
            candidate=refs.get(old.get('reference')) or by_lineage.get(lineage(old))
            if not candidate and old.get('updated_by')=='Excel import' and old.get('eligible_name'):
                candidates=[r for r in source if r['eligible_name']==old['eligible_name'] and r['source']==canonical_source(old['source']) and str(json.loads(r['source_json'])['values'][0]).zfill(5)==old['transaction_no'].zfill(5)]
                if len(candidates)==1:candidate=candidates[0]
            if not candidate:
                if old.get('source_key'):raise ValueError('Existing imported records cannot be matched safely. Nothing was changed. Send the current coe.db for reconciliation.')
                continue
            if candidate['id'] in used:raise ValueError('Multiple existing rows match one baseline row. Nothing was changed.')
            used.add(candidate['id']);matches[old['id']]=candidate
        changes=added=0
        for old in existing:
            candidate=matches.get(old['id'])
            if not candidate:continue
            clash=db.execute('SELECT id FROM coe_transactions WHERE reference=? AND id<>?',(candidate['reference'],old['id'])).fetchone()
            if clash:raise ValueError('Reference collision: '+candidate['reference'])
            # Imported records follow the supplied baseline. Manually edited fields are retained.
            if old.get('updated_by')=='Excel import':
                db.execute('UPDATE coe_transactions SET '+','.join(k+'=?' for k in FIELDS)+',source_key=?,source_json=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',[candidate[k] for k in FIELDS]+[candidate['source_key'],candidate['source_json'],old['id']])
            else:
                if old['received_on']!=candidate['received_on'] or canonical_source(old['source'])!=candidate['source']:raise ValueError('Manual source/date edit conflicts with baseline reference. Nothing was changed.')
                db.execute('UPDATE coe_transactions SET reference=? WHERE id=?',(candidate['reference'],old['id']))
            db.execute('INSERT INTO coe_audit(transaction_id,username,event,old_json,new_json) VALUES (?,?,?,?,?)',(old['id'],'Baseline update','Reference sync',json.dumps(old),json.dumps(candidate)))
            changes+=1
        for r in source:
            if r['id'] in used:continue
            cur=db.execute('INSERT INTO coe_transactions ('+','.join(FIELDS)+',source_key,source_json,updated_by) VALUES ('+','.join('?' for _ in range(len(FIELDS)+3))+')',[r[k] for k in FIELDS]+[r['source_key'],r['source_json'],'Excel import']);added+=1
        for r in sequences:db.execute('INSERT INTO coe_sequences VALUES (?,?,?) ON CONFLICT(source,year) DO UPDATE SET last_number=max(last_number,excluded.last_number)',tuple(r))
    return {'matched':changes,'added':added,'retained_manual':len(existing)-changes}
