"""Restricted receiving and verification accounts for the existing eTracker.

Legacy Admin/Chief/FO routes stay unchanged. Restricted accounts use explicit
allowlisted endpoints and partial, audited writes; hidden controls are not the
authorization boundary.
"""
import hashlib
import json
import re
import sqlite3
from receiver_monitoring import is_monitoring_receiver, register_receiver_monitoring
from datetime import date, datetime
from zoneinfo import ZoneInfo
from ui_labels import status_label

from flask import abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import generate_password_hash

ROLES = {'receiver': 'Receiver', 'first_verifier': '1st Verifier',
         'second_verifier': '2nd Verifier'}
VERIFIER_ACTIONS = ('On Process', 'Approved', 'Disapproved', 'Pending', 'Released', 'Other')
PENDING_CHOICES = ('For Compliance', 'For COPI')
SYSTEMS = {'spels': ('transactions', 'applicant', 'first_processor', 'first_date',
                     'second_processor', 'second_date'),
           'coe': ('coe_transactions', 'eligible_name', 'first_verifier', 'first_verified_on',
                   'second_verifier', 'second_verified_on')}


def migrate_role_schema(main_path, coe_path):
    with sqlite3.connect(main_path) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS ro_account_profiles (
            username TEXT PRIMARY KEY, display_name TEXT NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1, created_by TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
        db.execute('''CREATE TABLE IF NOT EXISTS ro_account_audit (
            id INTEGER PRIMARY KEY, username TEXT NOT NULL, event TEXT NOT NULL,
            happened_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
    for path, table in ((main_path, 'transactions'), (coe_path, 'coe_transactions')):
        with sqlite3.connect(path) as db:
            columns = {r[1] for r in db.execute(f'PRAGMA table_info({table})')}
            if not columns:
                continue  # Fresh SPELS database is initialized by app.init_db().
            fields = {'receiver_remarks': "TEXT NOT NULL DEFAULT ''",
                      'receiver_account': "TEXT NOT NULL DEFAULT ''",
                      'first_verifier_account': "TEXT NOT NULL DEFAULT ''",
                      'second_verifier_account': "TEXT NOT NULL DEFAULT ''"}
            for field in ('verifier_state', 'first_action', 'first_pending_status',
                          'first_verifier_remarks', 'first_submitted_at',
                          'second_verifier_remarks', 'second_reviewed_at', 'second_action', 'second_pending_status',
                          'verifier_return_remarks', 'verifier_returned_at', 'verifier_returned_by'):
                fields[field] = "TEXT NOT NULL DEFAULT ''"
            if table == 'coe_transactions':
                fields.update(first_verified_on='TEXT', second_verified_on='TEXT',
                              received_ro_by="TEXT NOT NULL DEFAULT ''")
            for field, definition in fields.items():
                if field not in columns:
                    db.execute(f'ALTER TABLE {table} ADD COLUMN {field} {definition}')


def fingerprint(row):
    return hashlib.sha256(json.dumps(dict(row), sort_keys=True, default=str).encode()).hexdigest()


def register_ro_accounts(app, main):
    main_path, coe_path = str(main['DB']), app.config['COE_DB']
    original_init = main['init_db']

    def initialize():
        original_init()
        migrate_role_schema(main_path, coe_path)

    main['init_db'] = initialize
    migrate_role_schema(main_path, coe_path)

    def current_account():
        if hasattr(g, 'ro_account'):
            return g.ro_account
        g.ro_account = None
        if session.get('username'):
            with sqlite3.connect(main_path) as db:
                db.row_factory = sqlite3.Row
                row = db.execute('''SELECT u.username,u.role,p.display_name,p.enabled
                    FROM users u LEFT JOIN ro_account_profiles p ON p.username=u.username
                    WHERE u.username=?''', (session['username'],)).fetchone()
            if row and row['role'] in ROLES:
                g.ro_account = dict(row)
        return g.ro_account

    @app.before_request
    def enforce_ro_role():
        account = current_account()
        if not account:
            return
        if not account['enabled'] or not account['display_name']:
            session.clear()
            abort(403, 'This account is disabled or incomplete. Contact Admin.')
        endpoint = request.endpoint
        if endpoint in ('dashboard', 'coe_dashboard') and request.method == 'GET':
            return redirect(url_for('receiver_dashboard' if is_monitoring_receiver(account) else 'role_work', system='coe' if endpoint == 'coe_dashboard' else 'spels'))
        allowed = {'static', 'login', 'logout', 'role_work', 'role_record', 'role_password', 'system_selector'}
        if account['role'] == 'receiver':
            allowed.add('role_new')
        if is_monitoring_receiver(account):
            allowed.update(('receiver_dashboard','receiver_release'))
        if endpoint not in allowed:
            abort(403, 'This account can use only its receiving or verification workspace.')

    @app.context_processor
    def role_context():
        account = current_account()
        return {'ro_account': account, 'receiver_monitoring': is_monitoring_receiver(account), 'ro_role_label': 'Receiving & Releasing' if is_monitoring_receiver(account) else ROLES.get(account['role']) if account else '',
                'ro_role_labels': ROLES, 'verifier_actions': VERIFIER_ACTIONS,
                'verifier_pending_choices': PENDING_CHOICES, 'verifier_subtypes': main['SUBTYPES']}

    def require_role(*roles):
        account = current_account()
        if not account or (roles and account['role'] not in roles):
            abort(403)
        return account

    def settings(system):
        if system not in SYSTEMS:
            abort(404)
        return SYSTEMS[system]

    def connection(system):
        settings(system)
        db = sqlite3.connect(main_path if system == 'spels' else coe_path, timeout=30)
        db.row_factory = sqlite3.Row
        return db

    def today():
        return main['local_today']().isoformat()

    def valid_day(value, minimum=None):
        try:
            if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value or ''):
                raise ValueError()
            value = date.fromisoformat(value).isoformat()
        except ValueError:
            raise ValueError('Enter a valid date in YYYY-MM-DD format.') from None
        if value > today() or (minimum and value < minimum):
            raise ValueError('Date must be on/after receipt or prior verification, and not in the future.')
        return value

    def has_value(value):
        return str(value or '').strip() not in ('', '-', '—')

    def received(row):
        if row.get('source') == 'Walk-In':
            return row.get('received_ro_on') or row.get('received_on')
        return row.get('received_ro_on')

    def on_hold(row, system):
        if system == 'spels':
            return row.get('action') not in ('', 'Received', 'On Process', 'FOR REVIEW') or bool(row.get('released_client_on') or row.get('ro_transmitted_fo') == 'Yes')
        return row.get('status') not in ('', 'Pending', 'Received', 'Received/Awaiting Processing', 'On Process', 'To be transmitted to ESD-ROII') or bool(row.get('released_client_on') or row.get('released_on'))

    def receipt_due(row, system):
        from ro_receipt_alerts import needs_ro_receipt
        return not row.get('received_ro_on') and needs_ro_receipt(row, today())

    def processing_blocked(row, system):
        # Only a pending status belonging to this account workflow can be resumed.
        # Releases, transmissions and external final decisions remain locked.
        if row.get('released_client_on') or row.get('ro_transmitted_fo') == 'Yes' or (system == 'coe' and row.get('released_on')):
            return True
        if not on_hold(row, system):
            return False
        if row.get('verifier_state') not in ('draft', 'submitted', 'returned'):
            return True
        prefix = 'second' if row.get('verifier_state') == 'submitted' and row.get('second_action') else 'first'
        action, pending = row.get(prefix + '_action'), row.get(prefix + '_pending_status')
        if system == 'spels':
            return not (row.get('action') == 'Pending' and action == 'Pending'
                        and row.get('pending_status') == pending)
        expected = 'COPI' if pending == 'For COPI' else 'For Compliance'
        return not (action == 'Pending' and row.get('status') == expected)

    def editable(row, system, account):
        _, _, first, first_day, second, second_day = settings(system)
        role = account['role']
        if role == 'receiver':
            return receipt_due(row, system)
        if not received(row) or received(row) > today() or processing_blocked(row, system):
            return False
        state = row.get('verifier_state') or ''
        if has_value(row.get(second)) or row.get(second_day) or state == 'verified':
            return False
        if role == 'first_verifier':
            if state not in ('', 'draft', 'returned'):
                return False
            if row.get('first_verifier_account'):
                return row['first_verifier_account'] == account['username']
            return not has_value(row.get(first)) and not row.get(first_day)
        return (state == 'submitted' and bool(row.get('first_submitted_at'))
                and has_value(row.get(first)) and bool(row.get(first_day))
                and row.get('second_verifier_account') in ('', account['username']))

    def stage(row, system):
        _, _, first, first_day, second, second_day = settings(system)
        if receipt_due(row, system):
            return 'Awaiting Regional Office receipt'
        if processing_blocked(row, system):
            return status_label(row.get('action' if system == 'spels' else 'status') or 'Pending')
        state = row.get('verifier_state')
        if state == 'returned':
            return 'Returned to 1st Verifier — For Compliance'
        if state == 'submitted':
            if row.get('second_action'):
                result = row.get('second_pending_status') if row['second_action'] == 'Pending' else row['second_action']
                return '2nd Verifier — ' + status_label(result) + ' (saved)'
            return 'For 2nd Verification'
        if has_value(row.get(second)) and row.get(second_day):
            return '2nd Verification Recorded' + (' — ' + status_label(row['second_action']) if row.get('second_action') else '')
        if has_value(row.get(first)):
            result = row.get('first_pending_status') if row.get('first_action') == 'Pending' else row.get('first_action')
            return '1st Verifier — ' + (status_label(result) if result else 'Draft saved') + ' (not submitted)'
        return 'Awaiting first verification' if received(row) else 'Awaiting Regional Office receipt'

    def corrections(db, system, row, name):
        """Allow receiving-data corrections, never receipt dates or audit identities."""
        fields = {name, 'source', 'receiver_remarks', 'remarks'}
        fields.update(('category', 'subtype', 'quantity') if system == 'spels' else ('coe_copies', 'auth_copies'))
        changes = {}
        for key in fields:
            if key not in request.form:
                continue
            value = request.form[key].strip()
            if key in ('quantity', 'coe_copies', 'auth_copies'):
                try:
                    value = int(value)
                except ValueError:
                    raise ValueError('Quantity and copies must be whole numbers.') from None
                lower, upper = (1, 99999) if key == 'quantity' else (0, 100000)
                if not lower <= value <= upper:
                    raise ValueError(f'{key}: enter a number from {lower} to {upper}.')
            elif len(value) > (5000 if key in ('remarks', 'receiver_remarks') else 500):
                raise ValueError('Name/details: maximum 500 characters; remarks: maximum 5,000.')
            if value != (row.get(key) if row.get(key) is not None else ''):
                changes[key] = value
        data = {**row, **changes}
        if not data[name]:
            raise ValueError('Enter the applicant / eligible name.')
        if 'source' in changes and data['source'] not in main['OFFICE_SOURCES']:
            raise ValueError('Choose a valid Office / Source.')
        if system == 'spels':
            if any(key in changes for key in ('category', 'subtype', 'quantity')):
                category, subtype = data['category'], data['subtype']
                if category not in main['CATEGORIES']:
                    raise ValueError('Choose a valid category.')
                choices = main['SUBTYPES'][category]
                if choices and subtype not in choices and not (category == 'CSE-PR' and not subtype):
                    raise ValueError('Choose a valid subtype for the category.')
                if not choices:
                    changes['subtype'] = ''
                if category != 'HGE' and data['quantity'] != 1:
                    raise ValueError('Only HGE may contain a batch quantity greater than 1.')
                if 'category' in changes or 'subtype' in changes:
                    changes['eligibility'] = subtype if category == 'Other' else ''
            if any(key in changes for key in ('source', 'category', 'quantity')):
                changes['reference'] = main['assign_reference'](db, {**data, **changes}, existing=row)
        elif 'source' in changes:
            from coe_monitor import reserve_reference
            changes['reference'] = reserve_reference(db, data['source'], row['received_on'])
            if row.get('transaction_no') == row.get('reference'):
                changes['transaction_no'] = changes['reference']
        return changes

    def processing_status(system, action, pending, remarks):
        # First-stage decisions stay separate from final disposition. Pending
        # uses existing report fields and the existing SPELS COPI pause triggers.
        if system == 'coe':
            return {'status': ('COPI' if pending == 'For COPI' else 'For Compliance')
                    if action == 'Pending' else 'On Process'}
        changes = {'action': 'Pending' if action == 'Pending' else 'On Process',
                   'pending_status': pending if action == 'Pending' else ''}
        if action == 'Pending':
            changes['copi_reason' if pending == 'For COPI' else 'compliance_comment'] = remarks
        return changes

    def audit(db, system, ident, before, changes):
        if system == 'spels':
            event = json.dumps({'role': current_account()['role'], 'changes': {
                key: {'before': before.get(key), 'after': value} for key, value in changes.items()}}, ensure_ascii=False)
            db.execute('INSERT INTO audit(transaction_id,username,event) VALUES (?,?,?)',
                       (ident, session['username'], event))
        else:
            db.execute('INSERT INTO coe_audit(transaction_id,username,event,old_json,new_json) VALUES (?,?,?,?,?)',
                       (ident, session['username'], ROLES[current_account()['role']],
                        json.dumps(before, ensure_ascii=False), json.dumps({**before, **changes}, ensure_ascii=False)))

    @app.route('/accounts/ro', methods=['GET', 'POST'])
    @main['login_required']
    def ro_accounts():
        if main['fo_office']() or not main['is_admin']():
            abort(403)
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            operation = request.form.get('operation', 'create')
            try:
                with sqlite3.connect(main_path) as db:
                    db.execute('BEGIN IMMEDIATE')
                    if operation == 'create':
                        role = request.form.get('role', '')
                        display = request.form.get('display_name', '').strip()
                        password = request.form.get('password', '')
                        if not re.fullmatch(r'[A-Za-z0-9_.-]{3,40}', username) or username.casefold() in ('admin', 'ajvtb'):
                            raise ValueError('Choose a username of 3–40 letters, digits, dots, underscores or hyphens.')
                        if role not in ROLES or not display or len(display) > 100:
                            raise ValueError('Choose a role and enter the actual staff name (maximum 100 characters).')
                        if len(password) < 5:
                            raise ValueError('Use a password of at least 10 characters.')
                        if db.execute('SELECT 1 FROM users WHERE lower(username)=lower(?)', (username,)).fetchone():
                            raise ValueError('Username already exists. Existing accounts are not replaced.')
                        db.execute('INSERT INTO users(username,password_hash,role) VALUES (?,?,?)',
                                   (username, generate_password_hash(password), role))
                        db.execute('INSERT INTO ro_account_profiles(username,display_name,created_by) VALUES (?,?,?)',
                                   (username, main['canonical_processor'](display), session['username']))
                    elif operation in ('reset', 'enable', 'disable'):
                        row = db.execute('SELECT u.role FROM users u JOIN ro_account_profiles p ON p.username=u.username WHERE u.username=?', (username,)).fetchone()
                        if not row or row[0] not in ROLES:
                            abort(404)
                        if operation == 'reset':
                            password = request.form.get('password', '')
                            if len(password) < 10:
                                raise ValueError('Use a password of at least 10 characters.')
                            db.execute('UPDATE users SET password_hash=? WHERE username=?', (generate_password_hash(password), username))
                        else:
                            db.execute('UPDATE ro_account_profiles SET enabled=? WHERE username=?', (int(operation == 'enable'), username))
                    else:
                        abort(400)
                    db.execute('INSERT INTO ro_account_audit(username,event) VALUES (?,?)',
                               (session['username'], json.dumps({'operation': operation, 'account': username})))
                flash('Account saved.')
                return redirect(url_for('ro_accounts'))
            except (ValueError, sqlite3.IntegrityError) as error:
                flash(str(error))
        with sqlite3.connect(main_path) as db:
            db.row_factory = sqlite3.Row
            accounts = db.execute('SELECT u.username,u.role,p.* FROM users u JOIN ro_account_profiles p ON p.username=u.username ORDER BY u.role,u.username').fetchall()
        return render_template('ro_accounts.html', accounts=accounts)

    @app.route('/work/password', methods=['GET', 'POST'])
    @main['login_required']
    def role_password():
        from werkzeug.security import check_password_hash
        account = require_role()
        if request.method == 'POST':
            with sqlite3.connect(main_path) as db:
                stored = db.execute('SELECT password_hash FROM users WHERE username=?', (account['username'],)).fetchone()[0]
                password = request.form.get('password', '')
                if not check_password_hash(stored, request.form.get('current_password', '')):
                    flash('Current password is incorrect.')
                elif len(password) < 10 or password != request.form.get('confirm_password'):
                    flash('New password must have at least 10 characters and match confirmation.')
                else:
                    db.execute('UPDATE users SET password_hash=? WHERE username=?', (generate_password_hash(password), account['username']))
                    flash('Password changed.')
                    return redirect(url_for('role_work', system='spels'))
        return render_template('role_password.html')

    @app.get('/work/<system>')
    @main['login_required']
    def role_work(system):
        account = require_role()
        table, name, first, first_day, second, second_day = settings(system)
        with connection(system) as db:
            rows = [dict(r) for r in db.execute(f'SELECT * FROM {table} ORDER BY received_on,id')]
        owner = {'receiver': 'receiver_account', 'first_verifier': 'first_verifier_account',
                 'second_verifier': 'second_verifier_account'}[account['role']]
        done_day = {'receiver': 'received_ro_on', 'first_verifier': first_day,
                    'second_verifier': second_day}[account['role']]
        mine = [r for r in rows if r.get(owner) == account['username']]
        waiting = [r for r in rows if editable(r, system, account)]
        view = request.args.get('view', 'waiting')
        if view not in ('waiting', 'mine'):
            abort(400)
        shown = mine if view == 'mine' else waiting
        q = request.args.get('q', '').strip()
        if q:
            shown = [r for r in shown if q.casefold() in ' '.join(str(r.get(k) or '') for k in ('reference', name, 'source')).casefold()]
        month = request.args.get('month', '')
        if month and not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])', month):
            abort(400)
        if month:
            shown = [r for r in shown if str(r.get(done_day if view == 'mine' else 'received_on') or '').startswith(month)]
        total = len(shown)
        try:
            page = min(max(1, int(request.args.get('page', 1))), max(1, (total+24)//25))
        except ValueError:
            abort(400)
        def link(**changes):
            return url_for('role_work', system=system, **{**request.args.to_dict(), **changes})
        return render_template('role_work.html', system=system, rows=shown[(page-1)*25:page*25],
            name_field=name, stage=lambda r: stage(r, system), view=view, q=q, month=month,
            waiting=len(waiting), mine=len(mine), this_month=sum(str(r.get(done_day) or '').startswith(today()[:7]) for r in mine),
            page=page, pages=max(1, (total+24)//25), total=total, link=link)

    @app.route('/work/<system>/<int:ident>', methods=['GET', 'POST'])
    @main['login_required']
    def role_record(system, ident):
        account = require_role()
        table, name, first, first_day, second, second_day = settings(system)
        with connection(system) as db:
            if request.method == 'POST':
                db.execute('BEGIN IMMEDIATE')
            raw = db.execute(f'SELECT * FROM {table} WHERE id=?', (ident,)).fetchone()
            if not raw:
                abort(404)
            row = dict(raw)
            owner = {'receiver': 'receiver_account', 'first_verifier': 'first_verifier_account',
                     'second_verifier': 'second_verifier_account'}[account['role']]
            can_edit = editable(row, system, account)
            if not can_edit and row.get(owner) != account['username']:
                abort(403, 'This record is not in your work queue or processed records.')
            if request.method == 'POST':
                if not can_edit:
                    abort(403, 'This stage is locked. Contact Admin for corrections.')
                if request.form.get('version') != fingerprint(row):
                    abort(409, 'Record changed. Reload before saving.')
                is_receiver = account['role'] == 'receiver'
                is_first = account['role'] == 'first_verifier'
                allowed = {'_csrf', 'version'}
                if is_receiver:
                    allowed.update(('date', 'receiver_remarks'))
                else:
                    allowed.update(('operation', name, 'source', 'receiver_remarks', 'remarks'))
                    allowed.update(('category', 'subtype', 'quantity') if system == 'spels' else ('coe_copies', 'auth_copies'))
                    allowed.update(('first_action', 'first_pending_status', 'first_verifier_remarks') if is_first
                                   else ('date', 'second_verifier_remarks', 'return_remarks', 'second_action', 'second_pending_status'))
                if set(request.form) - allowed or any(len(request.form.getlist(k)) != 1 for k in request.form):
                    abort(403, 'Fields outside your role cannot be changed. Receipt dates and first action date are locked.')
                try:
                    changes = {}
                    minimum = max(row.get('received_on') or '', received(row) or '')
                    if is_receiver:
                        minimum = max(row.get('received_on') or '', row.get('fo_transmitted_ro_on') or '')
                        day = valid_day(request.form.get('date', ''), minimum)
                        remarks = request.form.get('receiver_remarks', '').strip()
                        if len(remarks) > 5000:
                            raise ValueError('Receiving remarks: maximum 5,000 characters.')
                        changes.update(received_ro_on=day, received_ro_by=account['display_name'],
                                       receiver_account=account['username'], receiver_remarks=remarks)
                        if system == 'spels':
                            from workflow_actions import received_action
                            changes['action'] = received_action(row.get('action'))
                        elif row.get('status') in ('', 'Pending', 'To be transmitted to ESD-ROII'):
                            changes['status'] = 'Received/Awaiting Processing'
                        message = 'Receipt saved.'
                    else:
                        operation = request.form.get('operation', '')
                        valid_ops = ('save', 'submit') if is_first else ('save', 'complete', 'return')
                        if operation not in valid_ops:
                            raise ValueError('Choose Save, Submit, Complete or Return using the available buttons.')
                        now = datetime.now(ZoneInfo('Asia/Manila')).isoformat(timespec='seconds')
                        remarks_key = 'first_verifier_remarks' if is_first else 'second_verifier_remarks'
                        remarks = request.form.get(remarks_key, row.get(remarks_key) or '').strip()
                        if len(remarks) > 5000:
                            raise ValueError('Verification remarks: maximum 5,000 characters.')
                        changes.update({remarks_key: remarks, owner: account['username']})
                        if is_first:
                            action = request.form.get('first_action', '')
                            pending = request.form.get('first_pending_status', '') if action == 'Pending' else ''
                            if action not in VERIFIER_ACTIONS:
                                raise ValueError('Choose a First Verifier action.')
                            if action == 'Pending' and (pending not in PENDING_CHOICES or not remarks):
                                raise ValueError('For Pending, choose For Compliance or For COPI and enter the required remarks.')
                            # Keep the first-ever recorded day, including pre-update records.
                            day = row.get(first_day) or valid_day(today(), minimum)
                            changes.update({first: account['display_name'], first_day: day,
                                            'first_action': action, 'first_pending_status': pending,
                                            'verifier_state': 'submitted' if operation == 'submit' else
                                                ('returned' if row.get('verifier_state') == 'returned' else 'draft')})
                            if operation == 'submit':
                                changes['first_submitted_at'] = now
                                # A resubmission needs a fresh second-stage decision.
                                changes.update(second_action='', second_pending_status='')
                            changes.update(processing_status(system, action, pending, remarks))
                            message = 'Submitted to 2nd Verifier.' if operation == 'submit' else 'Saved. Record remains with 1st Verifier until Submit.'
                        else:
                            changes['second_reviewed_at'] = now
                            if operation != 'return':
                                action = request.form.get('second_action', '')
                                pending = request.form.get('second_pending_status', '') if action == 'Pending' else ''
                                if action not in VERIFIER_ACTIONS:
                                    raise ValueError('Choose a Second Verifier action.')
                                if action == 'Pending' and (pending not in PENDING_CHOICES or not remarks):
                                    raise ValueError('For Pending, choose For Compliance or For COPI and enter the required remarks.')
                                changes.update(second_action=action, second_pending_status=pending)
                                changes.update(processing_status(system, action, pending, remarks))
                            if operation == 'return':
                                reason = request.form.get('return_remarks', '').strip()
                                if not reason or len(reason) > 5000:
                                    raise ValueError('Enter return-for-compliance remarks (1–5,000 characters).')
                                if not row.get('first_verifier_account'):
                                    raise ValueError('No originating 1st Verifier account. Contact Admin.')
                                changes.update(verifier_state='returned', verifier_return_remarks=reason,
                                               verifier_returned_at=now, verifier_returned_by=account['display_name'],
                                               first_action='Pending', first_pending_status='For Compliance',
                                               second_action='Pending', second_pending_status='For Compliance',
                                               second_verifier_remarks=remarks or reason)
                                changes.update(processing_status(system, 'Pending', 'For Compliance', reason))
                                message = 'Returned to the original 1st Verifier for compliance.'
                            elif operation == 'complete':
                                if action == 'Pending':
                                    raise ValueError('Pending cannot be completed. Save or Return for Compliance, then choose the resolved action before completing.')
                                day = valid_day(request.form.get('date') or today(), max(minimum, row.get(first_day) or '', (row.get('first_submitted_at') or '')[:10]))
                                changes.update({second: account['display_name'], second_day: day, 'verifier_state': 'verified'})
                                message = '2nd verification recorded. The action taken follows the existing authorized workflow.'
                            else:
                                message = 'Review saved. Record remains with 2nd Verifier.'
                        changes.update(corrections(db, system, row, name))
                        if system == 'coe':
                            changes['updated_by'] = account['username']
                    db.execute(f'UPDATE {table} SET '+','.join(f'{k}=?' for k in changes)+',updated_at=CURRENT_TIMESTAMP WHERE id=?', (*changes.values(), ident))
                    audit(db, system, ident, row, changes)
                    flash(message)
                    return redirect(url_for('role_work', system=system, view='mine'))
                except (ValueError, sqlite3.IntegrityError) as error:
                    db.rollback()
                    flash(str(error) if isinstance(error, ValueError) else 'This correction conflicts with an existing record. No changes were saved.')
                    return render_template('role_record.html', system=system, row=row, name_field=name,
                        first=first, first_day=first_day, second=second, second_day=second_day,
                        can_edit=can_edit, version=fingerprint(row), stage=stage(row, system)), 400
        return render_template('role_record.html', system=system, row=row, name_field=name,
            first=first, first_day=first_day, second=second, second_day=second_day,
            can_edit=can_edit, version=fingerprint(row), stage=stage(row, system))

    @app.route('/work/<system>/new', methods=['GET', 'POST'])
    @main['login_required']
    def role_new(system):
        account = require_role('receiver')
        table, name, *_ = settings(system)
        if request.method == 'POST':
            allowed = {'_csrf', 'received_on', 'applicant', 'receiver_remarks'}
            if system == 'spels':
                allowed.update(('category', 'subtype', 'quantity'))
            else:
                allowed.update(('coe_copies', 'auth_copies'))
            if set(request.form) - allowed:
                abort(403, 'Fields outside your receiving role cannot be changed.')
            try:
                day = valid_day(request.form.get('received_on', ''))
                applicant = request.form.get('applicant', '').strip()
                remarks = request.form.get('receiver_remarks', '').strip()
                if not applicant or len(applicant) > 500 or len(remarks) > 5000:
                    raise ValueError('Enter the applicant name (maximum 500 characters) and concise remarks (maximum 5,000 characters).')
                data = {name: applicant, 'source': 'Walk-In', 'received_on': day,
                        'received_ro_on': day, 'received_ro_by': account['display_name'],
                        'receiver_account': account['username'], 'receiver_remarks': remarks}
                for field in (('coe_copies', 'auth_copies') if system == 'coe' else ()):
                    try:
                        data[field] = int(request.form.get(field, '0') or '0')
                    except ValueError:
                        raise ValueError('Copies must be whole numbers.') from None
                    if not 0 <= data[field] <= 100000:
                        raise ValueError('Copies must be between 0 and 100,000.')
                with connection(system) as db:
                    db.execute('BEGIN IMMEDIATE')
                    if system == 'spels':
                        category = request.form.get('category', '')
                        subtype = request.form.get('subtype', '').strip()
                        if category not in main['CATEGORIES']:
                            raise ValueError('Choose a category.')
                        choices = main['SUBTYPES'][category]
                        if choices and subtype not in choices and not (category == 'CSE-PR' and not subtype):
                            raise ValueError('Choose a valid subtype for the category.')
                        quantity = int(request.form.get('quantity', '1') or '1')
                        if quantity < 1 or (category != 'HGE' and quantity != 1):
                            raise ValueError('Only HGE may contain a batch quantity greater than 1.')
                        data.update(category=category, subtype=subtype if choices else '', quantity=quantity,
                                    eligibility=subtype if category == 'Other' else '', action='Received')
                        data['reference'] = main['assign_reference'](db, data)
                    else:
                        from coe_monitor import reserve_reference
                        data['reference'] = reserve_reference(db, 'Walk-In', day)
                        data['transaction_no'] = data['reference']
                        data['status'] = 'Received/Awaiting Processing'
                        data['updated_by'] = account['username']
                    cur = db.execute(f'INSERT INTO {table} ('+','.join(data)+') VALUES ('+','.join('?' for _ in data)+')', tuple(data.values()))
                    audit(db, system, cur.lastrowid, {}, data)
                flash('Walk-in application received. Reference: '+data['reference'])
                return redirect(url_for('role_work', system=system, view='mine'))
            except (ValueError, sqlite3.IntegrityError) as error:
                flash(str(error))
                return render_template('role_new.html', system=system), 400
        return render_template('role_new.html', system=system)

    register_receiver_monitoring(app, main, current_account, connection, settings, stage)
