"""Receiving/releasing regressions. Uses temporary SQLite databases only.
Run separately: python -m unittest test_receiver_monitoring -v
"""
import csv
import hashlib
import io
import json
import os
import secrets
import tempfile
import unittest
from datetime import date
from pathlib import Path
from unittest.mock import patch


class ReceivingMonitoringTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.environment = patch.dict(os.environ, {
            'ETRACKER_DATABASE_URL':'', 'ETRACKER_DB':str(Path(cls.temp.name)/'main.db'),
            'COE_DB':str(Path(cls.temp.name)/'coe.db'), 'ETRACKER_SECRET_KEY':secrets.token_urlsafe(32),
            'ETRACKER_ADMIN_PASSWORD':secrets.token_urlsafe(24)})
        cls.environment.start()
        import app
        cls.tracker = app
        app.local_today = lambda: date(2026,10,19)
        app.app.config['TESTING'] = True
        app.init_db()
        from werkzeug.security import generate_password_hash
        with app.conn() as db:
            for username,role in [('edbermelad','receiver'),('other-receiver','receiver'),('test-verifier','first_verifier')]:
                db.execute('INSERT INTO users(username,password_hash,role) VALUES (?,?,?)',
                           (username,generate_password_hash(secrets.token_urlsafe(20)),role))
                db.execute('INSERT INTO ro_account_profiles(username,display_name,created_by) VALUES (?,?,?)',
                           (username,username,'admin'))
        cls.sequence = 0

    @classmethod
    def tearDownClass(cls):
        cls.environment.stop()
        cls.temp.cleanup()

    def client(self, username='edbermelad'):
        client = self.tracker.app.test_client()
        with client.session_transaction() as s:
            s.update(username=username,csrf='test-token')
        return client

    def record(self, system='spels', **changes):
        type(self).sequence += 1
        ref = f'TEST-{system}-{self.sequence}'
        if system == 'spels':
            values = dict(reference=ref,applicant=ref,category='Other',subtype='BOE',source='Walk-In',
                          received_on='2026-09-30',received_ro_on='2026-09-30',receiver_account='other-receiver',
                          received_ro_by='other-receiver',first_processor='First Tester',first_date='2026-10-01',
                          second_processor='Second Tester',second_date='2026-10-02',action='Approved')
        else:
            values = dict(reference=ref,transaction_no=ref,eligible_name=ref,source='Walk-In',
                          received_on='2026-09-30',received_ro_on='2026-09-30',receiver_account='other-receiver',
                          received_ro_by='other-receiver',first_verifier='First Tester',first_verified_on='2026-10-01',
                          second_verifier='Second Tester',second_verified_on='2026-10-02',status='For Release')
        values.update(changes)
        from coe_monitor import connect
        db = self.tracker.conn() if system=='spels' else connect(self.tracker.app.config['COE_DB'])
        table = 'transactions' if system=='spels' else 'coe_transactions'
        with db:
            ident = db.execute(f'INSERT INTO {table} ('+','.join(values)+') VALUES ('+','.join('?' for _ in values)+')',tuple(values.values())).lastrowid
        return ident,ref

    def row(self, ident, system='spels'):
        from coe_monitor import connect
        db = self.tracker.conn() if system=='spels' else connect(self.tracker.app.config['COE_DB'])
        with db:
            return dict(db.execute('SELECT * FROM '+('transactions' if system=='spels' else 'coe_transactions')+' WHERE id=?',(ident,)).fetchone())

    def payload(self, ident, system='spels', **extra):
        from receiver_monitoring import record_version
        return {'_csrf':'test-token','version':record_version(self.row(ident,system)),
                'released_client_on':'2026-10-19',**extra}

    def test_monitoring_covers_all_ro_receivers_but_not_unreceived_fo(self):
        _,seen = self.record(applicant='SharedRO visible',source='ISAFO')
        _,hidden = self.record(applicant='SharedRO not received',source='QFO',received_ro_on=None)
        html = self.client().get('/monitoring/spels?q=SharedRO').get_data(as_text=True)
        self.assertIn(seen,html)
        self.assertNotIn(hidden,html)
        self.assertIn('other-receiver',html)
        self.assertIn('Total Acted Applications',html)
        self.assertNotIn('Switch Workspace',html)

    def test_separate_coe_and_spels_dashboards_and_landing(self):
        _,spels = self.record()
        _,coe = self.record('coe')
        client=self.client()
        html=client.get('/monitoring/coe').get_data(as_text=True)
        self.assertIn(coe,html);self.assertNotIn(spels,html)
        html=client.get('/monitoring/spels').get_data(as_text=True)
        self.assertIn(spels,html);self.assertNotIn(coe,html)
        self.assertIn('/monitoring/spels',client.get('/').location)
        self.assertIn('/monitoring/coe',client.get('/coe').location)

    def test_other_accounts_cannot_release_or_open_monitoring(self):
        ident,_=self.record()
        for username in ('other-receiver','test-verifier','admin'):
            client=self.client(username)
            self.assertEqual(client.get('/monitoring/spels').status_code,403)
            self.assertEqual(client.post(f'/releasing/spels/{ident}',data=self.payload(ident)).status_code,403)
        self.assertIsNone(self.row(ident)['released_client_on'])

    def test_release_is_audited_and_receipt_and_verification_are_preserved(self):
        ident,_=self.record()
        before=self.row(ident)
        import re
        client=self.client()
        html=client.get(f'/releasing/spels/{ident}').get_data(as_text=True)
        payload=self.payload(ident)
        payload['version']=re.search(r'name="version" value="([a-f0-9]+)"',html)[1]
        response=client.post(f'/releasing/spels/{ident}',data=payload)
        self.assertEqual(response.status_code,302)
        after=self.row(ident)
        self.assertEqual(after['released_client_on'],'2026-10-19')
        for key in ('received_on','received_ro_on','receiver_account','first_processor','first_date','second_processor','second_date','acted_on','action','reference'):
            self.assertEqual(after[key],before[key],key)
        with self.tracker.conn() as db:
            entry=db.execute("SELECT username,event FROM audit WHERE transaction_id=? AND event LIKE 'Client release recorded:%'",(ident,)).fetchone()
        self.assertEqual(entry['username'],'edbermelad')
        self.assertIn('2026-10-19',entry['event'])
        payload=self.payload(ident)
        payload['released_client_on']='2026-10-18'
        self.assertEqual(self.client().post(f'/releasing/spels/{ident}',data=payload).status_code,409)
        self.assertEqual(self.row(ident)['released_client_on'],'2026-10-19')

    def test_verified_action_is_used_without_allowing_arbitrary_decision(self):
        ident,_=self.record(action='On Process',verifier_state='verified',second_action='Approved')
        self.assertEqual(self.client().post(f'/releasing/spels/{ident}',data=self.payload(ident)).status_code,302)
        self.assertEqual(self.row(ident)['action'],'Approved')
        legacy,_=self.record(action='Released')
        self.assertEqual(self.client().post(f'/releasing/spels/{legacy}',data=self.payload(legacy)).status_code,302)
        self.assertEqual(self.row(legacy)['action'],'Released')
        blocked,_=self.record(action='Pending',pending_status='For Compliance',verifier_state='verified',second_action='Approved')
        self.assertEqual(self.client().post(f'/releasing/spels/{blocked}',data=self.payload(blocked)).status_code,409)

    def test_dates_csrf_and_unexpected_fields_are_rejected(self):
        ident,_=self.record()
        client=self.client()
        for day in ('','2026-99-01','2026-10-20','2026-10-01'):
            payload=self.payload(ident,released_client_on=day)
            self.assertEqual(client.post(f'/releasing/spels/{ident}',data=payload).status_code,400,day)
        self.assertEqual(client.post(f'/releasing/spels/{ident}',data=self.payload(ident,_csrf='wrong')).status_code,400)
        self.assertEqual(client.post(f'/releasing/spels/{ident}',data=self.payload(ident,action='Disapproved')).status_code,403)
        self.assertIsNone(self.row(ident)['released_client_on'])
        self.assertEqual(self.row(ident)['action'],'Approved')

    def test_stale_edits_missing_verification_and_unconfirmed_handoffs_are_blocked(self):
        ident,_=self.record()
        old=self.payload(ident)
        with self.tracker.conn() as db:
            db.execute("UPDATE transactions SET remarks='Changed by another user' WHERE id=?",(ident,))
        self.assertEqual(self.client().post(f'/releasing/spels/{ident}',data=old).status_code,409)
        for extra in ({'second_processor':''},{'second_date':None},{'ro_transmitted_fo':'Yes','received_back_ro_on':None}):
            ident,_=self.record(**extra)
            self.assertEqual(self.client().post(f'/releasing/spels/{ident}',data=self.payload(ident)).status_code,409)
            self.assertIsNone(self.row(ident)['released_client_on'])

    def test_coe_release_and_hold(self):
        ident,_=self.record('coe')
        self.assertEqual(self.client().post(f'/releasing/coe/{ident}',data=self.payload(ident,'coe')).status_code,302)
        after=self.row(ident,'coe')
        self.assertEqual(after['status'],'Released')
        self.assertEqual(after['released_client_on'],'2026-10-19')
        self.assertEqual(after['updated_by'],'edbermelad')
        self.assertEqual(after['received_ro_by'],'other-receiver')
        blocked,_=self.record('coe',status='COPI')
        self.assertEqual(self.client().post(f'/releasing/coe/{blocked}',data=self.payload(blocked,'coe')).status_code,409)
        from coe_monitor import connect
        with connect(self.tracker.app.config['COE_DB']) as db:
            audit=db.execute("SELECT username,new_json FROM coe_audit WHERE transaction_id=? AND event='Client release recorded'",(ident,)).fetchone()
        self.assertEqual(audit['username'],'edbermelad')
        self.assertEqual(json.loads(audit['new_json'])['released_client_on'],'2026-10-19')

    def test_acted_labels_in_all_report_periods_and_workflow_guides(self):
        client=self.client('admin')
        for query in ('scope=year&year=2026','scope=month&year=2026&month=10','scope=day&day=2026-10-19'):
            html=client.get('/?'+query).get_data(as_text=True)
            self.assertIn('Total Acted Applications',html)
            self.assertIn('ACTED WITHIN 20 WORKING DAYS',html)
            self.assertNotIn('DECIDED',html)
            self.assertNotIn('Final decisions',html)
            rows=list(csv.reader(io.StringIO(client.get('/report.csv?'+query).get_data(as_text=True))))
            header=next(r for r in rows if r and r[0]=='Category')
            self.assertTrue(any('Total Acted Applications' in value for value in header))
        html=self.client('test-verifier').get('/work/spels').get_data(as_text=True)
        self.assertIn('<b>Acted and release:</b>',html)
        self.assertNotIn('Final decision and release',html)


if __name__=='__main__':
    unittest.main()
